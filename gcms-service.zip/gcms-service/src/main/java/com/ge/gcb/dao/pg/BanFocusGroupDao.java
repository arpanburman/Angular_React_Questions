package com.ge.gcb.dao.pg;

import java.util.List;

public interface BanFocusGroupDao {

	void insertFocusGroup(List focusGroup, long banId);

	void deleteFocusGroupData(long banId);

	List getBanFocusGroupById(String banId);

	
}
