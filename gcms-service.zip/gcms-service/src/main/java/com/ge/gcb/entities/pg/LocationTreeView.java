package com.ge.gcb.entities.pg;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="v_location_tree_view")
public class LocationTreeView {

	@Id
	@Column(name="country_tree")
	private String countryTree;

	public String getCountryTree() {
		return countryTree;
	}

	public void setCountryTree(String countryTree) {
		this.countryTree = countryTree;
	}
	

}
