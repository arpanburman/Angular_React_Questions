package com.ge.gcb.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.BanDao;
import com.ge.gcb.dao.pg.BanFocusGroupDao;
import com.ge.gcb.dao.pg.BanProductDao;
import com.ge.gcb.dao.pg.BillingModelDao;
import com.ge.gcb.dao.pg.BillingModelTypeDao;
import com.ge.gcb.dto.BanDto;
import com.ge.gcb.dto.BanDwnDto;
import com.ge.gcb.dto.BanProductDto;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.BanProductMaster;
import com.ge.gcb.entities.pg.BillingModel;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.exception.GcbException;
import com.ge.gcb.services.BanService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Service
public class BanServiceImpl implements BanService {
	
	private static final Logger logger = LogManager.getLogger(BanServiceImpl.class);
	
	@Autowired
	BanDao banDao;
	
	@Autowired
	BanFocusGroupDao banFocusGroupDao;
	
	@Autowired
	BillingModelDao billingModelDao;
	
	@Autowired
	BanProductDao banProductDao;

	@Autowired
	BillingModelTypeDao billingModelTypeDao;
	
	@Override
	public List<BanDto> getAllBans() {
		logger.info("In BanCache Component..");
		logger.info("****Get Ban Service ****");
		return banDao.getAllBans();
	}

	@Override
	public List<BanDwnDto> downloadBanData() {
		logger.info("****Get Ban Download Service ****");
		return banDao.downloadBanData();
	}

	@Override
	public List<Ban> getBans() {
		return banDao.getBans();
	}

	@Override
	public List<BillingModel> getBillingModel() {
		logger.info("****Get Ban Service ****");
		return billingModelDao.getBillingModel();
	}
	
	@Override
	public Map<String, Object> saveOrUpdateBan(Ban banData, String sso) {
		logger.info("****Save or Update BAN Service ****");
		Map<String, Object> outMap = new HashMap<>();
		List focusGroup=banData.getFocusGroup();

		try {
			Ban banObj = banDao.getBanRecord(banData);
			if(banObj==null && !GcbUtil.isEmpty(banData.getBanId())) {
				outMap=banDao.updateBan(banData,sso);
				if(focusGroup!=null) {
					banFocusGroupDao.deleteFocusGroupData(banData.getBanId());
					banFocusGroupDao.insertFocusGroup(focusGroup,banData.getBanId());
					}
				logger.info("****update Ban Service ****");
			}
			else if (banObj == null || (banObj.getBanId() == banData.getBanId()))
			{
					outMap=banDao.saveBan(banData,sso);
					if(focusGroup!=null) {
					banFocusGroupDao.insertFocusGroup(focusGroup,banData.getBanId());
					}
					logger.info("****Save Ban Service ****");	
					
			}
			else {
				outMap.put("statusMessage", " Ban record with same VendorBan, Mode,Billing Process,Invoice name, Vendor paid by, Liquidated via, Tax_engine already exists");
				//outMap.put("banId", banData.getBanId());
				outMap.put(GcbConstants.ERROR, true);
			}
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return outMap;
	}


	@Override
	public Ban getBanById(String banId) {
		List<Long> focusGroup=banFocusGroupDao.getBanFocusGroupById(banId);	
		Ban banObj=banDao.getBanById(banId);
		banObj.setFocusGroup(focusGroup);
		return banObj;
	}
	
	@Override
	public Map<String, Object> upsertBanProductMaster(List<BanProductDto> banProductDataList, String banId, String sso) {
		logger.info("****Save or Update BAN Service ****");
		Map<String, Object> outMap = new HashMap<>();
		try {
			if(banProductDataList.size()>0) {
				outMap=banProductDao.saveBanProduct(banProductDataList, banId, sso);
			}
			else
			{
				outMap.put(GcbConstants.MESSAGE,GcbConstants.EMPTY_RECORDS);
				outMap.put(GcbConstants.ERROR, true);
			}
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put(GcbConstants.MESSAGE,GcbConstants.EMPTY_RECORDS);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	public List<BanProductDto> getBanProductById(Integer banId) throws GcbException {
		List<BanProductDto> banProdDtoObjList = new ArrayList<>();
		try {
			if(null != banId) {
				List<BanProductMaster> banProductMasterObjList = banProductDao.getBanProductById(banId);
				if(banProductMasterObjList.size()>0) {
					for(BanProductMaster banProdMastObj : banProductMasterObjList) {
						BanProductDto banProObj = new BanProductDto();
						
						banProObj.setBanId(banProdMastObj.getBanId());
						banProObj.setServiceTypeId(banProdMastObj.getServiceTypeId());
						banProObj.setOverrideErpPmtTerms(banProdMastObj.getOverrideErpPaymentTerms()!=null?banProdMastObj.getOverrideErpPaymentTerms():GcbConstants.EMPTY_STR);
						banProObj.setOverrideErpAwtGroupName(banProdMastObj.getOverrideErpAwtGroupName()!=null?banProdMastObj.getOverrideErpAwtGroupName():GcbConstants.EMPTY_STR);
						banProObj.setOverrideErpVatAwtGroupName(banProdMastObj.getOverrideVatPercent()!=null?banProdMastObj.getOverrideVatPercent():GcbConstants.EMPTY_STR);
						banProObj.setOverrideDirectOffsetBuc(banProdMastObj.getOverrideDirectOffsetBuc()!=null?banProdMastObj.getOverrideDirectOffsetBuc():GcbConstants.EMPTY_STR);
						banProObj.setOverrideIndirectOffsetBuc(banProdMastObj.getOverrideIndirectOffsetBuc()!=null?banProdMastObj.getOverrideIndirectOffsetBuc():GcbConstants.EMPTY_STR);
						banProObj.setOverrideUnspsc(banProdMastObj.getOverrideUnspsc()!=null?banProdMastObj.getOverrideUnspsc():GcbConstants.EMPTY_STR);
						banProObj.setOverrideOffsetCostCenter(banProdMastObj.getOverrideOffsetCostCenter()!=null?banProdMastObj.getOverrideOffsetCostCenter():GcbConstants.EMPTY_STR);
						banProObj.setUnspscOverrideFlag(banProdMastObj.getUnspscOverrideFlag()!=null?banProdMastObj.getUnspscOverrideFlag():false);
						banProObj.setCostCentreOverrideFlag(banProdMastObj.getCostCenterOverrideFlag()!=null?banProdMastObj.getCostCenterOverrideFlag():false);
						banProObj.setErpPmtOverrideFlag(banProdMastObj.getErpPaymentTermsOverrideFlag()!=null?banProdMastObj.getErpPaymentTermsOverrideFlag():false);
						banProObj.setErpAwtGroupNameOverrideFlag(banProdMastObj.getErpAwtGroupNameOverrideFlag()!=null?banProdMastObj.getErpAwtGroupNameOverrideFlag():false);
						banProObj.setErpVatAwtGroupOverrideFlag(banProdMastObj.getVatOverrideFlag()!=null?banProdMastObj.getVatOverrideFlag():false);
						banProObj.setDirectOffsetBucOverrideFlag(banProdMastObj.getDirectOffsetBucOverrideFlag()!=null?banProdMastObj.getDirectOffsetBucOverrideFlag():false);
						banProObj.setIndirectOffsetBucOverrideFlag(banProdMastObj.getIndirectOffsetBucOverrideFlag()!=null?banProdMastObj.getIndirectOffsetBucOverrideFlag():false);
						banProObj.setQstPercent(banProdMastObj.getQstPercent()!=null?banProdMastObj.getQstPercent():0);
						banProObj.setHstPercent(banProdMastObj.getHstPercent()!=null?banProdMastObj.getHstPercent():0);
						banProObj.setPstPercent(banProdMastObj.getPstPercent()!=null?banProdMastObj.getPstPercent():0);
						banProObj.setGstPercent(banProdMastObj.getGstPercent()!=null?banProdMastObj.getGstPercent():0);
						banProObj.setVatPercent(banProdMastObj.getVatPercent()!=null?banProdMastObj.getVatPercent():0);
						banProObj.setTpPercent(banProdMastObj.getTpPercent()!=null?banProdMastObj.getTpPercent():0);
						banProObj.setLiquidateBillRoutingId(banProdMastObj.getBillRoutingId()!=null?banProdMastObj.getBillRoutingId():GcbConstants.EMPTY_STR);
						
						banProdDtoObjList.add(banProObj);
					}
				}
				return banProdDtoObjList;
			}else {
				throw new GcbException(GcbConstants.EMPTY_RECORDS);
			}
		}catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			throw new GcbException(GcbConstants.EMPTY_RECORDS);
		}
	}

	@Override
	public BanProductDto fetchTargetServiceTypeDetails(ServiceType serviceTypeList, String banId) throws GcbException {
		BanProductDto banProObj = new BanProductDto();
		try {
			BanProductMaster banProdMastObj = new BanProductMaster();
			banProdMastObj=banProductDao.fetchTargetServiceTypeDetails(serviceTypeList, banId);
			
			banProObj.setBanId(banProdMastObj.getBanId());
			banProObj.setServiceTypeId(banProdMastObj.getServiceTypeId());
			banProObj.setOverrideErpPmtTerms(banProdMastObj.getOverrideErpPaymentTerms()!=null?banProdMastObj.getOverrideErpPaymentTerms():GcbConstants.EMPTY_STR);
			banProObj.setOverrideErpAwtGroupName(banProdMastObj.getOverrideErpAwtGroupName()!=null?banProdMastObj.getOverrideErpAwtGroupName():GcbConstants.EMPTY_STR);
			banProObj.setOverrideErpVatAwtGroupName(banProdMastObj.getOverrideVatPercent()!=null?banProdMastObj.getOverrideVatPercent():GcbConstants.EMPTY_STR);
			banProObj.setOverrideDirectOffsetBuc(banProdMastObj.getOverrideDirectOffsetBuc()!=null?banProdMastObj.getOverrideDirectOffsetBuc():GcbConstants.EMPTY_STR);
			banProObj.setOverrideIndirectOffsetBuc(banProdMastObj.getOverrideIndirectOffsetBuc()!=null?banProdMastObj.getOverrideIndirectOffsetBuc():GcbConstants.EMPTY_STR);
			banProObj.setOverrideUnspsc(banProdMastObj.getOverrideUnspsc()!=null?banProdMastObj.getOverrideUnspsc():GcbConstants.EMPTY_STR);
			banProObj.setOverrideOffsetCostCenter(banProdMastObj.getOverrideOffsetCostCenter()!=null?banProdMastObj.getOverrideOffsetCostCenter():GcbConstants.EMPTY_STR);
			banProObj.setUnspscOverrideFlag(banProdMastObj.getUnspscOverrideFlag()!=null?banProdMastObj.getUnspscOverrideFlag():false);
			banProObj.setCostCentreOverrideFlag(banProdMastObj.getCostCenterOverrideFlag()!=null?banProdMastObj.getCostCenterOverrideFlag():false);
			banProObj.setErpPmtOverrideFlag(banProdMastObj.getErpPaymentTermsOverrideFlag()!=null?banProdMastObj.getErpPaymentTermsOverrideFlag():false);
			banProObj.setErpAwtGroupNameOverrideFlag(banProdMastObj.getErpAwtGroupNameOverrideFlag()!=null?banProdMastObj.getErpAwtGroupNameOverrideFlag():false);
			banProObj.setErpVatAwtGroupOverrideFlag(banProdMastObj.getVatOverrideFlag()!=null?banProdMastObj.getVatOverrideFlag():false);
			banProObj.setDirectOffsetBucOverrideFlag(banProdMastObj.getDirectOffsetBucOverrideFlag()!=null?banProdMastObj.getDirectOffsetBucOverrideFlag():false);
			banProObj.setIndirectOffsetBucOverrideFlag(banProdMastObj.getIndirectOffsetBucOverrideFlag()!=null?banProdMastObj.getIndirectOffsetBucOverrideFlag():false);
			banProObj.setQstPercent(banProdMastObj.getQstPercent()!=null?banProdMastObj.getQstPercent():0);
			banProObj.setHstPercent(banProdMastObj.getHstPercent()!=null?banProdMastObj.getHstPercent():0);
			banProObj.setPstPercent(banProdMastObj.getPstPercent()!=null?banProdMastObj.getPstPercent():0);
			banProObj.setGstPercent(banProdMastObj.getGstPercent()!=null?banProdMastObj.getGstPercent():0);
			banProObj.setVatPercent(banProdMastObj.getVatPercent()!=null?banProdMastObj.getVatPercent():0);
			banProObj.setTpPercent(banProdMastObj.getTpPercent()!=null?banProdMastObj.getTpPercent():0);
			banProObj.setLiquidateBillRoutingId(banProdMastObj.getBillRoutingId()!=null?banProdMastObj.getBillRoutingId():GcbConstants.EMPTY_STR);
		
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			throw new GcbException(GcbConstants.EMPTY_RECORDS);
		}
		return banProObj;
	}	
	
	@Override
	public Map getBillingModelTypes() {
		Map billingModelTypes = billingModelTypeDao.getBillingModelTypes();
		return billingModelTypes;
	}

	@Override
	public Map getCloneBillingModelTypes(String banId) {
		Map billingModelTypes = billingModelTypeDao.getCloneBillingModelTypes(banId);
		return billingModelTypes;
	}

	@Override
	public Ban getProdMode(Ban banData) {
		logger.info("****Save or Update BAN Service ****");
		Ban banObj=banDao.getProdMode(banData);

		return banObj;
	}
}
