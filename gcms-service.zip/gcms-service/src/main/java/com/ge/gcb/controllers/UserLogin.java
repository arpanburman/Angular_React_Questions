package com.ge.gcb.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.entities.pg.User;
import com.ge.gcb.services.impl.UserServiceImpl;
import com.ge.gcb.utils.GcbUtil;

@RestController
public class UserLogin {
	
	private static final Logger logger = LogManager.getLogger(UserLogin.class);
	@Autowired
	private HttpServletRequest request;

	@Autowired
	private UserServiceImpl userServiceImpl;
 
	@CrossOrigin
	@RequestMapping(value = "/UserDetails/{sso}")
	public @ResponseBody Map<String, Object> getUserData(@PathVariable("sso") String sso)  {
		logger.info("INSIDE GCB getUserData Controller Method SSO:{} ",()->sso);
		Map<String, Object> map = new HashMap<String, Object>();
		User user = userServiceImpl.getUserDetails(sso);
		map.put("User", user);
		if (user != null) {
			map.put("status", "success");
		}else {
			map.put("status", "failed");
			map.put("message", "User not found");
		}
		return map;
	}

	@CrossOrigin
	@RequestMapping(value = "/UserDetails", method = RequestMethod.GET)
	public @ResponseBody Map<String, Object> saveUserData()  {
		
		logger.info("INSIDE GCB saveUserData Controller Method :");
		Map<String, Object> map = new HashMap<String, Object>();
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";

		
		if(!GcbUtil.isEmpty(sso)) {
			User user = userServiceImpl.getUserDetails(sso);
			if (user == null) {
				String usr_fname = request.getHeader("ge_firstname") != null ? request.getHeader("ge_firstname") : "Test";
				String usr_lname = request.getHeader("ge_lastname") != null ? request.getHeader("ge_lastname") : "User";
				String usr_email = request.getHeader("ge_email") != null ? request.getHeader("ge_email") : "User";
				String usr_role = request.getHeader("ge_role") != null ? request.getHeader("ge_role") : "1";
				int role = Integer.parseInt(usr_role); 
				
				User userData= new User();
				userData.setFirstName(usr_fname);
				userData.setLastName(usr_lname);
				userData.setSso(sso);
				userData.setEmailId(usr_email);
				userData.setRole(role);
				userData = userServiceImpl.saveUserDetails(userData);
				map.put("status", "success");
				map.put("User", userData);
				map.put("message", "User Details saved successfully");
			}
			else {
				map.put("status", "success");
				map.put("User", user);
				map.put("message", "User already exsits");
			}
		}else {
			map.put("status", "failed");
			map.put("User", null);
			map.put("message", "SSO is Blank");
		}
		
		 
		return map;
	
	}
	
	
	@CrossOrigin
	@RequestMapping(value = "/UserStatUpdate/{sso}")
	public @ResponseBody String updateUserStat (@PathVariable("sso") String sso)  {
		logger.info("INSIDE GCB UserStatUpdate Controller Method SSO:{} ",()->sso);		
		try {
		 userServiceImpl.updateUserStat(sso);
		 return "UserStat Updated Sucessfully";
		}
		 catch(Exception e) {
			 return "Error in updating UserStat";
		 }
	
}

}