package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.entities.pg.Unspsc;

public interface UnspscDao {

	List<Unspsc> getUnspsc();
	

}
