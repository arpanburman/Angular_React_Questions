package com.ge.gcb.services.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.BuyerTreeViewDao;
import com.ge.gcb.dao.pg.LocationTreeViewDao;
import com.ge.gcb.dao.pg.ProductTreeViewDao;
import com.ge.gcb.dao.pg.VendorTreeViewDao;
import com.ge.gcb.services.ChargeBackService;

@Service
public class ChargeBackServiceImpl implements ChargeBackService {

	private static final Logger logger = LogManager.getLogger(ChargeBackServiceImpl.class);
	
	@Autowired
	LocationTreeViewDao locationViewDao;
	
	@Autowired 
	ProductTreeViewDao productTreeViewDao;
	
	@Autowired 
	VendorTreeViewDao vendorTreeViewDao;
	
	@Autowired 
	BuyerTreeViewDao buyerTreeViewDao;
	
	@Override
	public String getLocationTree() {
		return locationViewDao.getLocation();
	}

	@Override
	public String getBillProcessTree() {
		return productTreeViewDao.getBillProcessesTree();
	}
	
	@Override
	public String getVendorTree() {
		return vendorTreeViewDao.getVendorTree();
	}
	
	@Override
	public String getBuyerTree() {
		return buyerTreeViewDao.getBuyerTree();
	}
	
	
}
