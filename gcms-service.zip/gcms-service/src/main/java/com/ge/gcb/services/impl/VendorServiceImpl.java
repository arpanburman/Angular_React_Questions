package com.ge.gcb.services.impl;

import java.util.HashMap;

/**
 * @author aburman 188058
 **/

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.HlVendorDao;
import com.ge.gcb.dao.pg.VendorDao;
import com.ge.gcb.dto.VendorDto;
import com.ge.gcb.entities.pg.HlVendor;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.services.VendorService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Service
public class VendorServiceImpl implements VendorService{
	
	private static final Logger logger = LogManager.getLogger(VendorServiceImpl.class);

	@Autowired
	VendorDao vendorDao;
	
	@Autowired
	HlVendorDao hlVendorDao;
	
	@Override
	public List<VendorDto> getAllVendors() {
		logger.info("****Get Vendor Service ****");
		return vendorDao.getAllVendor();
	}

	@Override
	public Map<String, Object> saveOrUpdateVendor(Vendor vendor, String sso) {
		logger.info("****Save or Update Vendor Service ****");
		Map<String, Object> outMap = new HashMap<>();
		try {
			if(!GcbUtil.isEmpty(vendor.getVendorEntityId())) {
				outMap=vendorDao.updateVendor(vendor, sso);
				logger.info("****update Vendor Service ****");
			}else {
				if(null != vendor.getVendorLegalEntityName()) {
					boolean flag = vendorDao.findVendorName(vendor.getVendorLegalEntityName());
					if(!flag) {
						outMap=vendorDao.saveVendor(vendor, sso);
						logger.info("****Save Vendor Service ****");
					}else {
						outMap.put(GcbConstants.MESSAGE, GcbConstants.RECORD_EXIST);
						outMap.put(GcbConstants.ERROR, true);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return outMap;
	}

	@Override
	public List<VendorDto> downloadVendorData() {
		return vendorDao.downloadVendorData();
	}

	@Override
	public List<HlVendor> getAllHlVendors() {
		logger.info("****Get Vendor HL Service ****");
		return hlVendorDao.getAllHlVendors();
	}
	
	@Override
	public List<VendorDto> AllVendorNames(){
		logger.info("****All Vendor Names ****");
		return vendorDao.AllVendorNames();
	}
	
}
