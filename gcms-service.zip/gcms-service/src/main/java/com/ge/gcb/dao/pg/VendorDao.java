package com.ge.gcb.dao.pg;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.VendorDto;
import com.ge.gcb.entities.pg.Vendor;

public interface VendorDao {
	
	List<VendorDto> getAllVendor();

	Map<String, Object> saveVendor(Vendor vendor, String sso);

	Map<String, Object> updateVendor(Vendor vendor, String sso);
	
	boolean findVendorName(String vendorName);

	List<VendorDto> downloadVendorData();
	
	List<VendorDto> AllVendorNames();

}
