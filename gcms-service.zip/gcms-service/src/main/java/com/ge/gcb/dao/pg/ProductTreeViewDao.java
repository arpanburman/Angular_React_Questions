package com.ge.gcb.dao.pg;

public interface ProductTreeViewDao {
	String getBillProcessesTree();
}
