package com.ge.gcb.dto;

public class BanDwnDto {
	private String vendorBan;
	private String vendorLegalEntityName;
	private String locationFromCtry;
	private String locationToCtry;
	private String erpBuyerLeName;
	private String invoiceName;
	private String vendorPaidBy;
	private String liquidatedVia;
	private String taxEngine;
	private String mode;
	public String getVendorBan() {
		return vendorBan;
	}
	public void setVendorBan(String vendorBan) {
		this.vendorBan = vendorBan;
	}
	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}
	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}
	public String getLocationFromCtry() {
		return locationFromCtry;
	}
	public void setLocationFromCtry(String locationFromCtry) {
		this.locationFromCtry = locationFromCtry;
	}
	public String getLocationToCtry() {
		return locationToCtry;
	}
	public void setLocationToCtry(String locationToCtry) {
		this.locationToCtry = locationToCtry;
	}
	public String getErpBuyerLeName() {
		return erpBuyerLeName;
	}
	public void setErpBuyerLeName(String erpBuyerLeName) {
		this.erpBuyerLeName = erpBuyerLeName;
	}
	public String getInvoiceName() {
		return invoiceName;
	}
	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}
	public String getVendorPaidBy() {
		return vendorPaidBy;
	}
	public void setVendorPaidBy(String vendorPaidBy) {
		this.vendorPaidBy = vendorPaidBy;
	}
	public String getLiquidatedVia() {
		return liquidatedVia;
	}
	public void setLiquidatedVia(String liquidatedVia) {
		this.liquidatedVia = liquidatedVia;
	}
	public String getTaxEngine() {
		return taxEngine;
	}
	public void setTaxEngine(String taxEngine) {
		this.taxEngine = taxEngine;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public BanDwnDto(String vendorBan, String vendorLegalEntityName, String locationFromCtry, String locationToCtry,
			String erpBuyerLeName, String invoiceName, String vendorPaidBy, String liquidatedVia, String taxEngine,
			String mode) {
		super();
		this.vendorBan = vendorBan;
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.locationFromCtry = locationFromCtry;
		this.locationToCtry = locationToCtry;
		this.erpBuyerLeName = erpBuyerLeName;
		this.invoiceName = invoiceName;
		this.vendorPaidBy = vendorPaidBy;
		this.liquidatedVia = liquidatedVia;
		this.taxEngine = taxEngine;
		this.mode = mode;
	}
	
	
}
