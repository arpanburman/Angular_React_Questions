package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="t_service_type")
public class ServiceType {
	
	@Id
	@Column(name="service_type_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long serviceTypeId;
	
	@Column(name="product_id")
	private long productId;
	
	@Transient
	private String productNm;
	
	@Transient
	private boolean unspscOverride;
	@Transient
	private String unspsc;
	@Column(name="billed_from_location_id")
	private long billedFromLocationId;
	
	@Transient
	private String billedFromLocation;
	
	@Transient
	private String processName;	

	@Transient
	private String billedToLocation;
	
	@Column(name="billed_to_location_id")
	private long billedToLocationId;
	
	@Column(name="service_type_name")
	private String serviceTypeName;
	
	@Column(name="legacy_service_type_name")
	private String legacyServiceTypeName;
	
	@Column(name="billing_basis")
	private String billingBasis;
	
	@Column(name="cost_center")
	private String costCenter;
	
	@Convert(converter = DateConverter.class)
	@Column(name="created")
	private String created;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Convert(converter = DateConverter.class)
	@Column(name="last_updated")
	private String lastUpdated;
	
	@Column(name="updated_by")
	private String updatedBy;

	public long getServiceTypeId() {
		return serviceTypeId;
	}

	public void setServiceTypeId(long serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public long getBilledFromLocationId() {
		return billedFromLocationId;
	}

	public void setBilledFromLocationId(long billedFromLocationId) {
		this.billedFromLocationId = billedFromLocationId;
	}

	public long getBilledToLocationId() {
		return billedToLocationId;
	}

	public void setBilledToLocationId(long billedToLocationId) {
		this.billedToLocationId = billedToLocationId;
	}

	public String getServiceTypeName() {
		return serviceTypeName;
	}

	public void setServiceTypeName(String serviceTypeName) {
		this.serviceTypeName = serviceTypeName;
	}

	public String getLegacyServiceTypeName() {
		return legacyServiceTypeName;
	}

	public void setLegacyServiceTypeName(String legacyServiceTypeName) {
		this.legacyServiceTypeName = legacyServiceTypeName;
	}

	public String getBillingBasis() {
		return billingBasis;
	}

	public void setBillingBasis(String billingBasis) {
		this.billingBasis = billingBasis;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getBilledFromLocation() {
		return billedFromLocation;
	}

	public void setBilledFromLocation(String billedFromLocation) {
		this.billedFromLocation = billedFromLocation;
	}

	public String getBilledToLocation() {
		return billedToLocation;
	}

	public void setBilledToLocation(String billedToLocation) {
		this.billedToLocation = billedToLocation;
	}

	

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}
	
	
	public ServiceType(long serviceTypeId, long productId,String processName, String productNm, long billedFromLocationId,
			String billedFromLocation, String billedToLocation, long billedToLocationId, String serviceTypeName,String legacyServiceTypeName,
			 String billingBasis, String costCenter, String unspsc,  String createdBy,String created, String updatedBy, String lastUpdated) {
		super();
		this.serviceTypeId = serviceTypeId;
		this.productId = productId;
		this.processName=processName;
		this.productNm = productNm;
		this.billedFromLocationId = billedFromLocationId;
		this.billedFromLocation = billedFromLocation;
		this.billedToLocation = billedToLocation;
		this.billedToLocationId = billedToLocationId;
		this.serviceTypeName = serviceTypeName;
		this.legacyServiceTypeName=legacyServiceTypeName;
		this.billingBasis = billingBasis;
		this.costCenter = costCenter;
		this.unspsc = unspsc;
		this.created = created;
		this.createdBy = createdBy;
		this.lastUpdated = lastUpdated;
		this.updatedBy = updatedBy;
	}
	
	public ServiceType() {
		
	}

	public String getProductNm() {
		return productNm;
	}

	public void setProductNm(String productNm) {
		this.productNm = productNm;
	}

	public String getUnspsc() {
		return unspsc;
	}

	public void setUnspsc(String unspsc) {
		this.unspsc = unspsc;
	}

	public boolean isUnspscOverride() {
		return unspscOverride;
	}

	public void setUnspscOverride(boolean unspscOverride) {
		this.unspscOverride = unspscOverride;
	}

	
}
