package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.dto.OtherServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeBanDto;
import com.ge.gcb.dto.ServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeDwnData;
import com.ge.gcb.entities.pg.ServiceType;

public interface ServiceTypeDao {

	ServiceType getServiceType(String suggestedServiceType);

	List<ServiceType> getAllServiceTypeData();

	String insertServiceType(ServiceType serviceType,String sso);

	String updateServiceType(ServiceType serviceTypeDto,String sso);

	List<ServiceTypeDwnData> downloadServiceTypeData();

	List<ServiceType> fetchServiceType(ServiceTypeBanDto serviceType);

	OtherServiceTypeDto getOtherServiceType(ServiceType serviceType);

	List<ServiceType> getTargetServiceType(String banId);

}
