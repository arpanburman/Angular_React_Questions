package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.OtherServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeBanDto;
import com.ge.gcb.dto.ServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeDwnData;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.entities.pg.FocusGroup;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.services.ServiceTypeService;
import com.ge.gcb.utils.GcbUtil;

import io.swagger.annotations.ApiOperation;

@RestController
public class ServiceTypeController {
	
	private static final Logger logger = LogManager.getLogger(ServiceTypeController.class);
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private ServiceTypeService serviceTypeService;
	

	@CrossOrigin
	@GetMapping(value = "/currencyCode")
	public @ResponseBody List<Currency> getCurrencyCode()  {		
		logger.info("INSIDE GCMS currencyCode Controller Method :");
		return serviceTypeService.getCurrencyCode();
	}
	
	@CrossOrigin
	@GetMapping(value = "/focusGroup")
	public @ResponseBody List<FocusGroup> getFocusGroup()  {		
		logger.info("INSIDE GCMS focusGroup Controller Method :");
		return serviceTypeService.getFocusGroup();
	}  
	
	@CrossOrigin
	@RequestMapping(value ="/serviceType", method = RequestMethod.POST)
	public @ResponseBody ServiceTypeDto getServiceType(@RequestBody ServiceTypeDto serviceTypeDto) {

		logger.info("***Controller Method getServiceType invoked ***");
		ServiceType serviceType = serviceTypeService.getServiceType(serviceTypeDto.getSuggestedServiceType());

		if (serviceType != null) {
			serviceTypeDto.setServiceTypeMessage("Already exists");
			return serviceTypeDto;
		}else {
			serviceTypeDto.setServiceTypeMessage("Does not exists");
			return serviceTypeDto;
		}
	}
	
	@CrossOrigin
	@RequestMapping(value ="/serviceTypesData")
	public @ResponseBody  ResponseEntity<List<ServiceType>> getServiceTypeData() {

		logger.info("***Controller Method getServiceType invoked ***");
		List<ServiceType> serviceDataLst = null;
		serviceDataLst = serviceTypeService.getServiceTypeData();
		if (!serviceDataLst.isEmpty())
			return ResponseEntity.status(HttpStatus.OK).body(serviceDataLst);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceDataLst);
		
	}
	
	@CrossOrigin
	@RequestMapping(value ="/serviceTypes", method = RequestMethod.POST)
	public @ResponseBody String upsertServiceType(@RequestBody ServiceType serviceTypeDto) {
		logger.info("***Controller Method upsertServiceType invoked ***");
		Map<String, Object> outputMap = new HashMap<String, Object>();
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		ServiceType serviceType = serviceTypeService.getServiceType(serviceTypeDto.getServiceTypeName());
		String message = "";
		boolean valid = false;
		if(serviceType==null && serviceTypeDto.getServiceTypeId()==0) {
			valid = true;
			message = serviceTypeService.insertServiceType(serviceTypeDto,sso);
		}else if(serviceType!=null && serviceType.getServiceTypeId()==serviceTypeDto.getServiceTypeId()){
			valid = true;
			message = serviceTypeService.updateServiceType(serviceTypeDto,sso);
		}else {
			valid = false;
			message = "Service type name cannot be modified";
		}
		outputMap.put("status", valid);
		outputMap.put("statusMessage", message);
		return GcbUtil.convertMapToJson(outputMap);
	}
	
	@CrossOrigin
	@RequestMapping(value ="/dwnServiceTypesData")
	public @ResponseBody  ResponseEntity<List<ServiceTypeDwnData>> downloadServiceTypeData() {

		logger.info("***Controller Method getServiceType invoked ***");
		List<ServiceTypeDwnData> serviceDataLst = null;
		serviceDataLst = serviceTypeService.downloadServiceTypeData();
		if (!serviceDataLst.isEmpty())
			return ResponseEntity.status(HttpStatus.OK).body(serviceDataLst);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceDataLst);
		
	}

	@CrossOrigin
	@ApiOperation(value = "Fetch Service Type", response = Map.class, notes="This method will fetch Service Type based on location and product")
	@PostMapping("/fetchServiceType")
	public @ResponseBody ResponseEntity<List<ServiceType>> fetchServiceType(@RequestBody ServiceTypeBanDto serviceType) throws Exception { 
		logger.info("********* Fetch Service type Controller************");
		List<ServiceType> serviceTypeList = new ArrayList<>();
		Optional<ServiceTypeBanDto> opServiceType = Optional.ofNullable(serviceType);
		try {
			serviceTypeList = serviceTypeService.fetchServiceType(opServiceType.get());
			if(serviceTypeList.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceTypeList);
			}
		} catch (Exception e) {
			logger.error("Error in fetchServiecType : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(serviceTypeList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(serviceTypeList);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Get other Service Type", response = Map.class, notes="This method will fetch Other Service Type on Ban screen")
	@PostMapping("/getOtherServiceType")
	public @ResponseBody ResponseEntity<OtherServiceTypeDto> getOtherServiceType(@RequestBody ServiceType serviceType) throws Exception { 
		logger.info("********* Get Other Service type Controller************");
		OtherServiceTypeDto otherServiceTypeObj = null;
		Optional<ServiceType> opServiceType = Optional.ofNullable(serviceType);
		try {
			otherServiceTypeObj = serviceTypeService.getOtherServiceType(opServiceType.get());
			if(null == otherServiceTypeObj) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(otherServiceTypeObj);
			}
		} catch (Exception e) {
			logger.error("Error in fetchServiecType : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(otherServiceTypeObj);
		}
		return ResponseEntity.status(HttpStatus.OK).body(otherServiceTypeObj);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Get Target Service Type", response = Map.class, notes="This method will fetch Target Service Type on Ban screen")
	@GetMapping("/getTargetServiceType/{banId}")
	public @ResponseBody ResponseEntity<List<ServiceType>> getTaregtServiceType(@PathVariable("banId") String banId) throws Exception { 
		logger.info("********* Fetch Service type Controller************");
		List<ServiceType> serviceTypeList = new ArrayList<>();
		try {
			serviceTypeList = serviceTypeService.fetchTargetServiceType(banId);
			if(serviceTypeList.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceTypeList);
			}
		} catch (Exception e) {
			logger.error("Error in fetchServiecType : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(serviceTypeList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(serviceTypeList);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Fetch Source Service Type", response = Map.class, notes="This method will fetch Source Service Type based on location and product")
	@PostMapping("/getSourceServiceType/{banId}")
	public @ResponseBody ResponseEntity<List<ServiceType>> getSourceServiceType(@RequestBody ServiceTypeBanDto serviceType, @PathVariable("banId") String banId) throws Exception { 
		logger.info("********* Fetch source Service type Controller************");
		List<ServiceType> serviceTypeList = new ArrayList<>();
		Optional<ServiceTypeBanDto> opServiceType = Optional.ofNullable(serviceType);
		try {
			serviceTypeList = serviceTypeService.getSourceServiceType(opServiceType.get(), banId);
			if(serviceTypeList.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceTypeList);
			}
		} catch (Exception e) {
			logger.error("Error in fetchServiecType : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(serviceTypeList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(serviceTypeList);
	}
}