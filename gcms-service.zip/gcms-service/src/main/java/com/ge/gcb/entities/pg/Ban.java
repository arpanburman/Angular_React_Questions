package com.ge.gcb.entities.pg;


import java.util.List;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="t_ban")
public class Ban {
	
	@Id
	@Column(name="ban_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long banId;
	
	@Column(name="vendor_ban")
	private String vendorBan;
	
	@Column(name="vendor_config_id")
	private long vendorConfigId;
	
	@Column(name="vendor_friendly_name")
	private String vendorFriendlyName;
	
	@Column(name="buyer_id")
	private long buyerId;
	
	@Column(name="bill_process_id")
	private long billProcessId;
	
	@Column(name="active")
	private Boolean active;	
	
	@Column(name="active_to")
	@Convert(converter = DateConverter2.class)
	private String activeTo;
	
	@Column(name="gold_id_override_flag")		
	private Boolean goldIdOverrideFlag;		
			
	@Column(name="override_gold_id")		
	private String overrideGoldId;
	
	@Column(name="sez")	
	private Boolean sez;
	
	@Column(name="is_equipment")	
	private Boolean isEquipment;	
	
	@Column(name="liquidate_bill_routing_id")
	private Long liquidateBillRoutingId;
	
//	@Column(name="billing_model")
//	private String  billingModel;
	
	@Column(name="erp_system")		
	private String erpSystem;		
			
	@Column(name="erp_name")		
	private String erpName;
	
	@Column(name="mode")
	private String mode;

	@Column(name="invoice_name")		
	private String invoiceName;
	
	@Column(name="vendor_paid_by")		
	private String vendorPaidBy;
	
	@Column(name="liquidated_via")		
	private String liquidatedVia;
	
	@Column(name="tax_engine")		
	private String taxEngine;
	
	@Column(name="clone_of_id")
	private Long cloneOfId;
	
	@Transient
	private boolean cloneFlag;
	
	@Transient
	private List focusGroup;
	
	public List getFocusGroup() {
		return focusGroup;
	}

	public void setFocusGroup(List focusGroup) {
		this.focusGroup = focusGroup;
	}
	
	@Column(name="direct_offset_buc")
	private String directOffsetBuc;
	
	@Column(name="indirect_offset_buc")
	private String indirectOffsetBuc;
	
	@Column(name="invoice_buyer_le_name")
	private String invoiceBuyerLeName;
	
	@Column(name="erp_project")
	private String erpProject;
	
	@Column(name="erp_task")
	private String erpTask;
	
	@Column(name="erp_awt_group_name")
	private String erpAwtGroupName;
	
	@Column(name="erp_vat_awt_group_name")
	private String erpVatAwtGroupName;
	
	@Column(name="erp_vendor_gsl")
	private String erpVendorGsl;
	
	@Column(name="erp_vendor_site_code")
	private String erpVendorSiteCode;
	
	@Column(name="erp_payment_terms")
	private String erpPaymentTerms;
	
	@Column(name="erp_gui_dff")
	private String erpGuiDiff;
	
	@Column(name="erp_cust_reg_number")
	private String erpCustRegNumber;
	
	@Column(name="vat_unspsc")
	private String vatUnspsc;
	
	@Column(name="ship_from_address")
	private String shipFromAddress;
	
	@Column(name="buyer_contact_sso")
	private String buyerContactSso;	
	
	@Column(name="buyer_payment_approval_email")	
	private String 	buyerPaymentApprovalEmail;
	
	@Column(name="ship_to_country")
	private String shipToCountry;
	
	@Column(name="ship_to_province")
	private String shipToProvince;
	
	@Column(name="ship_to_state")
	private String shipToState;
	
	@Column(name="ship_to_city")
	private String shipToCity;
	
	@Column(name="ship_to_zip_4")
	private String shipToZip4;
	
	@Column(name="ship_to_zip_5")
	private String shipToZip5;
	
	@Column(name="add_country_iso_to_vendor_name")
	private Boolean addCountryISOtoVendorName;
	
	@Column(name="use_asset_file_vendor_name")
	private Boolean useAssetFileVendorName;
	
	@Column(name="created" , updatable=false)
	@Convert(converter = DateConverter.class)
	private String created;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdated;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendor_config_id",referencedColumnName="vendor_config_id",nullable=false, insertable=false, updatable=false) 
	private VendorConfig vendorConfig;
	
	/*@JsonIgnore
	@OneToMany(cascade=CascadeType.ALL)
    @JoinTable(name="t_ban_focus_group", joinColumns={@JoinColumn(name="ban_id", referencedColumnName="ban_id")}
    , inverseJoinColumns={@JoinColumn(name="focus_group_id", referencedColumnName="focus_group_id")})
    private Set<FocusGroup> focusGroup;*/
	
//	@JsonIgnore
//	@OneToMany(cascade=CascadeType.ALL)
//	@JoinColumns({@JoinColumn(name = "ban_id",referencedColumnName = "ban_id")})
//	private Set<BanFocusGroup> banFocusGroup;
//	
	/*@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "vendor_config_id",referencedColumnName="vendor_config_id",nullable=false, insertable=false, updatable=false) 
	private VendorConfig vendorConfig;
	
	@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "buyer_id",referencedColumnName="buyer_id",nullable=false, insertable=false, updatable=false) 
	private Buyer buyer;
	
	@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "ship_to_country",referencedColumnName="location_id",nullable=false, insertable=false, updatable=false) 
	private Location shipToCountryLocation;*/
	
//	@JsonIgnore
//	@OneToMany(cascade=CascadeType.ALL)
//    @JoinColumn(name="ban_id")
//    private List<BanProductMaster> banProductMaster;
	
	
	public long getBanId() {
		return banId;
	}

	public void setBanId(long banId) {
		this.banId = banId;
	}

	public String getVendorBan() {
		return vendorBan;
	}

	public void setVendorBan(String vendorBan) {
		this.vendorBan = vendorBan;
	}

	public long getVendorConfigId() {
		return vendorConfigId;
	}

	public void setVendorConfigId(long vendorConfigId) {
		this.vendorConfigId = vendorConfigId;
	}

	public long getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(long buyerId) {
		this.buyerId = buyerId;
	}

	public Long getLiquidateBillRoutingId() {
		return liquidateBillRoutingId;
	}

	public void setLiquidateBillRoutingId(Long liquidateBillRoutingId) {
		this.liquidateBillRoutingId = liquidateBillRoutingId;
	}
	

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getDirectOffsetBuc() {
		return directOffsetBuc;
	}

	public void setDirectOffsetBuc(String directOffsetBuc) {
		this.directOffsetBuc = directOffsetBuc;
	}

	public String getIndirectOffsetBuc() {
		return indirectOffsetBuc;
	}

	public void setIndirectOffsetBuc(String indirectOffsetBuc) {
		this.indirectOffsetBuc = indirectOffsetBuc;
	}

	public String getInvoiceBuyerLeName() {
		return invoiceBuyerLeName;
	}

	public void setInvoiceBuyerLeName(String invoiceBuyerLeName) {
		this.invoiceBuyerLeName = invoiceBuyerLeName;
	}

	public String getErpProject() {
		return erpProject;
	}

	public void setErpProject(String erpProject) {
		this.erpProject = erpProject;
	}

	public String getErpTask() {
		return erpTask;
	}

	public void setErpTask(String erpTask) {
		this.erpTask = erpTask;
	}

	public String getErpAwtGroupName() {
		return erpAwtGroupName;
	}

	public void setErpAwtGroupName(String erpAwtGroupName) {
		this.erpAwtGroupName = erpAwtGroupName;
	}

	public String getErpVatAwtGroupName() {
		return erpVatAwtGroupName;
	}

	public void setErpVatAwtGroupName(String erpVatAwtGroupName) {
		this.erpVatAwtGroupName = erpVatAwtGroupName;
	}

	public String getErpVendorGsl() {
		return erpVendorGsl;
	}

	public void setErpVendorGsl(String erpVendorGsl) {
		this.erpVendorGsl = erpVendorGsl;
	}

	public String getErpVendorSiteCode() {
		return erpVendorSiteCode;
	}

	public void setErpVendorSiteCode(String erpVendorSiteCode) {
		this.erpVendorSiteCode = erpVendorSiteCode;
	}

	public String getErpPaymentTerms() {
		return erpPaymentTerms;
	}

	public void setErpPaymentTerms(String erpPaymentTerms) {
		this.erpPaymentTerms = erpPaymentTerms;
	}

	public String getErpGuiDiff() {
		return erpGuiDiff;
	}

	public void setErpGuiDiff(String erpGuiDiff) {
		this.erpGuiDiff = erpGuiDiff;
	}

	

	public String getVatUnspsc() {
		return vatUnspsc;
	}

	public void setVatUnspsc(String vatUnspsc) {
		this.vatUnspsc = vatUnspsc;
	}

	public String getShipFromAddress() {
		return shipFromAddress;
	}

	public void setShipFromAddress(String shipFromAddress) {
		this.shipFromAddress = shipFromAddress;
	}


	public String getShipToCountry() {
		return shipToCountry;
	}

	public void setShipToCountry(String shipToCountry) {
		this.shipToCountry = shipToCountry;
	}

	public String getShipToProvince() {
		return shipToProvince;
	}

	public void setShipToProvince(String shipToProvince) {
		this.shipToProvince = shipToProvince;
	}

	public String getShipToState() {
		return shipToState;
	}

	public void setShipToState(String shipToState) {
		this.shipToState = shipToState;
	}

	public String getShipToCity() {
		return shipToCity;
	}

	public void setShipToCity(String shipToCity) {
		this.shipToCity = shipToCity;
	}

	public String getShipToZip4() {
		return shipToZip4;
	}

	public void setShipToZip4(String shipToZip4) {
		this.shipToZip4 = shipToZip4;
	}

	public String getShipToZip5() {
		return shipToZip5;
	}

	public void setShipToZip5(String shipToZip5) {
		this.shipToZip5 = shipToZip5;
	}


	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public long getBillProcessId() {
		return billProcessId;
	}

	public void setBillProcessId(long billProcessId) {
		this.billProcessId = billProcessId;
	}

	public String getVendorFriendlyName() {
		return vendorFriendlyName;
	}

	public void setVendorFriendlyName(String vendorFriendlyName) {
		this.vendorFriendlyName = vendorFriendlyName;
	}
	

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getActiveTo() {
		return activeTo;
	}

	public void setActiveTo(String activeTo) {
		this.activeTo = activeTo;
	}

	public Boolean getGoldIdOverrideFlag() {
		return goldIdOverrideFlag;
	}

	public void setGoldIdOverrideFlag(Boolean goldIdOverrideFlag) {
		this.goldIdOverrideFlag = goldIdOverrideFlag;
	}

	public String getOverrideGoldId() {
		return overrideGoldId;
	}

	public void setOverrideGoldId(String overrideGoldId) {
		this.overrideGoldId = overrideGoldId;
	}

	public Boolean getSez() {
		return sez;
	}

	public void setSez(Boolean sez) {
		this.sez = sez;
	}

	public Boolean getIsEquipment() {
		return isEquipment;
	}

	public void setIsEquipment(Boolean isEquipment) {
		this.isEquipment = isEquipment;
	}

	public String getErpSystem() {
		return erpSystem;
	}

	public void setErpSystem(String erpSystem) {
		this.erpSystem = erpSystem;
	}

	public String getErpName() {
		return erpName;
	}

	public void setErpName(String erpName) {
		this.erpName = erpName;
	}

	public String getErpCustRegNumber() {
		return erpCustRegNumber;
	}

	public void setErpCustRegNumber(String erpCustRegNumber) {
		this.erpCustRegNumber = erpCustRegNumber;
	}

	public String getBuyerContactSso() {
		return buyerContactSso;
	}

	public void setBuyerContactSso(String buyerContactSso) {
		this.buyerContactSso = buyerContactSso;
	}

	public String getBuyerPaymentApprovalEmail() {
		return buyerPaymentApprovalEmail;
	}

	public void setBuyerPaymentApprovalEmail(String buyerPaymentApprovalEmail) {
		this.buyerPaymentApprovalEmail = buyerPaymentApprovalEmail;
	}

	public Boolean getAddCountryISOtoVendorName() {
		return addCountryISOtoVendorName;
	}

	public void setAddCountryISOtoVendorName(Boolean addCountryISOtoVendorName) {
		this.addCountryISOtoVendorName = addCountryISOtoVendorName;
	}

	public Boolean getUseAssetFileVendorName() {
		return useAssetFileVendorName;
	}

	public void setUseAssetFileVendorName(Boolean useAssetFileVendorName) {
		this.useAssetFileVendorName = useAssetFileVendorName;
	}

	public String getInvoiceName() {
		return invoiceName;
	}

	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}

	public String getVendorPaidBy() {
		return vendorPaidBy;
	}

	public void setVendorPaidBy(String vendorPaidBy) {
		this.vendorPaidBy = vendorPaidBy;
	}

	public String getLiquidatedVia() {
		return liquidatedVia;
	}

	public void setLiquidatedVia(String liquidatedVia) {
		this.liquidatedVia = liquidatedVia;
	}

	public String getTaxEngine() {
		return taxEngine;
	}

	public void setTaxEngine(String taxEngine) {
		this.taxEngine = taxEngine;
	}

	public Long getCloneOfId() {
		return cloneOfId;
	}

	public void setCloneOfId(Long cloneOfId) {
		this.cloneOfId = cloneOfId;
	}

	public boolean isCloneFlag() {
		return cloneFlag;
	}

	public void setCloneFlag(boolean cloneFlag) {
		this.cloneFlag = cloneFlag;
	}

	public VendorConfig getVendorConfig() {
		return vendorConfig;
	}

	public void setVendorConfig(VendorConfig vendorConfig) {
		this.vendorConfig = vendorConfig;
	}

//	public List<BanProductMaster> getBanProductMaster() {
//		return banProductMaster;
//	}
//
//	public void setBanProductMaster(List<BanProductMaster> banProductMaster) {
//		this.banProductMaster = banProductMaster;
//	}
//
//	public Set<BanFocusGroup> getBanFocusGroup() {
//		return banFocusGroup;
//	}
//
//	public void setBanFocusGroup(Set<BanFocusGroup> banFocusGroup) {
//		this.banFocusGroup = banFocusGroup;
//	}
	
}
