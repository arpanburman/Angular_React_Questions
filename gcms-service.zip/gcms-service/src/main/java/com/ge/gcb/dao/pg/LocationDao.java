package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.dto.CountryDto;

public interface LocationDao {

	public List<CountryDto> getCountry();
}
