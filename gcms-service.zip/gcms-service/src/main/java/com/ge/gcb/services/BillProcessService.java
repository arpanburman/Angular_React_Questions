package com.ge.gcb.services;

import java.util.List;

import com.ge.gcb.entities.pg.BillProcess;

public interface BillProcessService {

	public List<BillProcess> getBillProcess(); 
}
