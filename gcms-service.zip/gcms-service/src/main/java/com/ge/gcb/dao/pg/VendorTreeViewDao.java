package com.ge.gcb.dao.pg;

public interface VendorTreeViewDao {

	public String getVendorTree();
	
}
