package com.ge.gcb.services;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.ProductDto;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.entities.pg.Unspsc;

public interface ProductService {

	List<ProductDto> getProductDetails();

	List<Product> getProduct();
	
	Product getProductById(String productId);

	Map<String, Object> saveOrUpdateProduct(Product product, String sso);

	List<Unspsc> getUnspsc();
}
