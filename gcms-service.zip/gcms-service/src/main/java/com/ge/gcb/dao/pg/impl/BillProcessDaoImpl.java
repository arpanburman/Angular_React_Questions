package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BillProcessDao;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class BillProcessDaoImpl extends JpaCrudRepositoryPgImpl<BillProcess, String> implements BillProcessDao {
	private static final Logger logger = LogManager.getLogger(BillProcessDaoImpl.class);

	@Override
	public List<BillProcess> getBillProcess() {		
		List<BillProcess> lst=findAll();
		//List<BillProcessDto> billProcessDto = ObjectMapperUtils.mapAll(lst, BillProcessDto.class);
		return lst;
	}
		
}
