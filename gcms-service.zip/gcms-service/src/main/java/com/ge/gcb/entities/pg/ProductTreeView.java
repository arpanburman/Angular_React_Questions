package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="v_product_tree_view")
public class ProductTreeView {

	@Id
	@Column(name="bill_processes")
	private String billProcesses;

	public String getBillProcesses() {
		return billProcesses;
	}

	public void setBillProcesses(String billProcesses) {
		this.billProcesses = billProcesses;
	}
	
	
}