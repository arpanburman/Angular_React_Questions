package com.ge.gcb.services;

import java.util.List;

import com.ge.gcb.dto.OtherServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeBanDto;
import com.ge.gcb.dto.ServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeDwnData;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.entities.pg.FocusGroup;
import com.ge.gcb.entities.pg.ServiceType;

public interface ServiceTypeService {

	List<Currency> getCurrencyCode();

	List<FocusGroup> getFocusGroup();

	ServiceType getServiceType(String suggestedServiceType);
	
	String insertServiceType(ServiceType serviceTypeDto,String sso);

	String updateServiceType(ServiceType serviceTypeDto,String sso);

	List<ServiceType> getServiceTypeData();

	boolean updateUnspsc(Long productId, String unspsc,String sso);

	List<ServiceTypeDwnData> downloadServiceTypeData();

	List<ServiceType> fetchServiceType(ServiceTypeBanDto serviceType);

	OtherServiceTypeDto getOtherServiceType(ServiceType serviceType);

	List<ServiceType> fetchTargetServiceType(String banId);

	List<ServiceType> getSourceServiceType(ServiceTypeBanDto serviceTypeBanDto, String banId);
}
