package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.entities.pg.HlVendor;

public interface HlVendorDao {

	List<HlVendor> getAllHlVendors();
}
