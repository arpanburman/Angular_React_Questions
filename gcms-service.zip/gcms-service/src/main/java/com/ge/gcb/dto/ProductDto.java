package com.ge.gcb.dto;

import java.util.Date;

public class ProductDto {
	
	private int productId;
	
	private int billProcessId;
	
	private String billProcessName;
	
	private String productName;
	
	private String productCode;	
	
	private String unspsc;
	
	private String lastUpdated;
	
	private String updatedBy;
	
	private String created;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getBillProcessName() {
		return billProcessName;
	}

	public void setBillProcessName(String billProcessName) {
		this.billProcessName = billProcessName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	
	public String getUnspsc() {
		return unspsc;
	}

	public void setUnspsc(String unspsc) {
		this.unspsc = unspsc;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}		
	

	public int getBillProcessId() {
		return billProcessId;
	}

	public void setBillProcessId(int billProcessId) {
		this.billProcessId = billProcessId;
	}

	
	public ProductDto() {
	}

	public ProductDto(int productId,int billProcessId, String billProcessName, String productName, String productCode,
			 String unspsc,String created, String lastUpdated,
			String updatedBy) {
		super();
		this.productId = productId;
		this.billProcessId=billProcessId;
		this.billProcessName = billProcessName;
		this.productName = productName;
		this.productCode = productCode;
		this.unspsc = unspsc;
		this.created=created;
		this.lastUpdated = lastUpdated;
		this.updatedBy = updatedBy;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}
	
	

}
