package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.entities.pg.BillingModel;

public interface BillingModelDao {
	
	List<BillingModel> getBillingModel();

	List<BillingModel> getCloneBillingModel(Long cbId);
	
}
