package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.LocationTreeViewDao;
import com.ge.gcb.entities.pg.LocationTreeView;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
@Repository
public class LocationTreeViewDaoImpl extends JpaCrudRepositoryPgImpl<LocationTreeView, String> implements LocationTreeViewDao {

	private static final Logger logger = LogManager.getLogger(LocationTreeViewDaoImpl.class);

	@Override
	public String getLocation() {
		List<LocationTreeView> locationObj = findAll();
		if(locationObj!=null) {
			return locationObj.get(0).getCountryTree();
		}
		return null;
	}

}
