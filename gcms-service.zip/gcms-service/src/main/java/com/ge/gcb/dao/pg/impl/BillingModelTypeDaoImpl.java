package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BillingModelTypeDao;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.entities.pg.BillingModelType;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class BillingModelTypeDaoImpl extends JpaCrudRepositoryPgImpl<BillingModelType, Long> implements BillingModelTypeDao{

	@Autowired
	private Environment env;
	
	@Override
	public Map getBillingModelTypes() {
		List<BillingModelType> billingModelTypes = findAll();
		Map<String,List<Map<String,String>>> respMap = new HashMap();
		for (BillingModelType obj : billingModelTypes) {
			List<Map<String,String>> arr = new ArrayList();
			if(respMap.containsKey(obj.getBillingType())) {
				arr = (List) respMap.get(obj.getBillingType());
			}
			Map<String,String> baseArr= new HashMap<>();
			baseArr.put("label", obj.getBillingModelDesc());
			baseArr.put("value", obj.getBillingModelDesc());			
			arr.add(baseArr);
			respMap.put(obj.getBillingType(), arr);
			
		}
		return respMap;
	}


	@Override
	public Map getCloneBillingModelTypes(String banId) {
		Map respMap = new HashMap();

		try {
			String schema_name = env.getProperty("spring.datasource.gcb.schema");
		      
			StoredProcedureQuery query = getEntityManager()
				    .createStoredProcedureQuery(schema_name+".billingmodelTypes",BillingModelType.class)
				    .registerStoredProcedureParameter(1, 
					        Integer.class, ParameterMode.IN)
				    .setParameter(1, Integer.parseInt(banId));
			List<BillingModelType> billingModelTypes=(List<BillingModelType>) query.getResultList();
			for (BillingModelType obj : billingModelTypes) {
				List arr = new ArrayList();
				if(respMap.containsKey(obj.getBillingType())) {
					arr = (List) respMap.get(obj.getBillingType());
				}
				Map baseArr= new HashMap<>();
				baseArr.put("label", obj.getBillingModelDesc());
				baseArr.put("value", obj.getBillingModelDesc());			
				arr.add(baseArr);
				respMap.put(obj.getBillingType(), arr);
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respMap;	
		
		
	}

}
