package com.ge.gcb.dao.pg;

import java.util.Map;

public interface BillingModelTypeDao {

	Map getBillingModelTypes();

	Map getCloneBillingModelTypes(String banId);
	
	
	
}
