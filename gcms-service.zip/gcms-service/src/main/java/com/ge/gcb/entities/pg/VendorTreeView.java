package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="v_vendor_tree_view")
public class VendorTreeView {

	@Id
	@Column(name="vendor")
	String vendorTree;

	public String getVendorTree() {
		return vendorTree;
	}

	public void setVendorTree(String vendorTree) {
		this.vendorTree = vendorTree;
	}
}
