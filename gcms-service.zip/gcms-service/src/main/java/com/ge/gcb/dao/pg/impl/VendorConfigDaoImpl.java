package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.VendorConfigDao;
import com.ge.gcb.dto.VendorConfigDetailsDto;
import com.ge.gcb.dto.VendorConfigDownloadDto;
import com.ge.gcb.dto.VendorConfigDto;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.entities.pg.VendorConfig;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class VendorConfigDaoImpl extends JpaCrudRepositoryPgImpl<VendorConfig, Long> implements VendorConfigDao {

	private static final Logger logger = LogManager.getLogger(VendorConfigDaoImpl.class);
	
	@Override
	public List<VendorConfigDto> getVendorConfig() {
		
		CriteriaBuilder cBuilder  = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorConfigDto> cQuery = cBuilder.createQuery(VendorConfigDto.class);
		Root<VendorConfig> venConf =cQuery.from(VendorConfig.class );
		Join<VendorConfig,Location> locBillFrm = venConf.join("locationFromCtry",JoinType.INNER);
		Join<VendorConfig,Location> locBillTo = venConf.join("locationToCtry",JoinType.INNER);
		Join<VendorConfig,Vendor> vendor = venConf.join("vendor",JoinType.INNER);
		
		final TypedQuery tq = getEntityManager().createQuery(
				cQuery.multiselect(
						          venConf.<Long>get("vendorConfigId"),
						          venConf.<Long>get("vendorEntityId"),
						          vendor.<String>get("vendorLegalEntityName"),
						          venConf.<String>get("vendorCode"),
						          locBillFrm.<String>get("locationName"),
						          locBillTo.<String>get("locationName"),
						          venConf.<String>get("currencyCode")
						          ) 
				      .where(cBuilder.and(cBuilder.equal(venConf.get("active"),true))
				    		  ).orderBy(cBuilder.asc(venConf.get("vendorLegalEntityName")))
				);

		List<VendorConfigDto> VendorConfigDtoList = tq.getResultList();
		
		return VendorConfigDtoList;
	}
	
	@Override
	public List<VendorConfigDetailsDto> getVendorConfigDetails()
	{
		CriteriaBuilder cBuilder  = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorConfigDetailsDto> cQuery = cBuilder.createQuery(VendorConfigDetailsDto.class);
		Root<VendorConfig> venConf =cQuery.from(VendorConfig.class );
		Join<VendorConfig,Location> locBillFrm = venConf.join("locationFromCtry",JoinType.INNER);
		Join<VendorConfig,Location> locBillTo = venConf.join("locationToCtry",JoinType.INNER);
		Join<VendorConfig,Vendor> vendor = venConf.join("vendor",JoinType.INNER);

		final TypedQuery tq = getEntityManager().createQuery(
				cQuery.multiselect(
						          venConf.<Long>get("vendorConfigId"),
						          venConf.<Long>get("vendorEntityId"),
						          vendor.<String>get("vendorLegalEntityName"),
						          venConf.<String>get("vendorCode"),
						          locBillFrm.<String>get("locationName"),
						          locBillFrm.<String>get("locationCode"),
						          venConf.<String>get("billedFromLocationId"),
						          locBillTo.<String>get("locationName"),
						          locBillTo.<String>get("locationCode"),
						          venConf.<String>get("billedToLocationId"),
						          venConf.<String>get("currencyCode"),
						          venConf.<Boolean>get("active"),
						          venConf.<String>get("dateFormat"),
						          venConf.<Boolean>get("lldCoeFlag"),
						          venConf.<String>get("exchangeRateType"),
						          venConf.<String>get("vendorContactEmail"),
						          venConf.<String>get("paymentApprovalEmail"),
						          venConf.<String>get("expectedFeedDate"),
						          venConf.<String>get("finalInvoiceDate"),
						          //venConf.<String>get("reportingSecurityDl"),
						          venConf.<String>get("created"),
						          venConf.<String>get("createdBy"),
						          venConf.<String>get("lastUpdated"),
						          venConf.<String>get("updatedBy")
						          ) 
				      .orderBy(cBuilder.asc(vendor.get("vendorLegalEntityName")))
				);

		List<VendorConfigDetailsDto> VendorConfigDetailsDtoList = tq.getResultList();
		
		return VendorConfigDetailsDtoList;
		
	}


	@Override
	public VendorConfigDetailsDto checkVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto) {
		
		CriteriaBuilder cBuilder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorConfigDetailsDto> cQuery = cBuilder.createQuery(VendorConfigDetailsDto.class);
		Root<VendorConfig> vcon = cQuery.from(VendorConfig.class);
		Join<VendorConfig,Location> locBillFrm = vcon.join("locationFromCtry",JoinType.INNER);
		Join<VendorConfig,Location> locBillTo = vcon.join("locationToCtry",JoinType.INNER);
		
		List<Predicate> criteria = new ArrayList<>();

			ParameterExpression<String> p2 = cBuilder.parameter(String.class, "vendorCode");
			ParameterExpression<String> p3 = cBuilder.parameter(String.class, "currencyCode");
			ParameterExpression<Long> p4 = cBuilder.parameter(Long.class, "billedToLocationId");
			ParameterExpression<Long> p5 = cBuilder.parameter(Long.class, "billedFromLocationId");

			criteria.add(cBuilder.equal(vcon.<String>get("vendorCode"),p2));
			criteria.add(cBuilder.equal(vcon.<String>get("currencyCode"),p3));
			criteria.add(cBuilder.equal(vcon.<Long>get("billedToLocationId"),p4));
			criteria.add(cBuilder.equal(vcon.<Long>get("billedFromLocationId"),p5));

	if (!criteria.isEmpty())
				cQuery.where(cBuilder.and(criteria.toArray(new Predicate[0])));
			
		final TypedQuery tq = getEntityManager().createQuery(
				cQuery.multiselect(
						vcon.<String>get("vendorCode"),
						locBillFrm.<String>get("locationName"),
						locBillTo.<String>get("locationName"),
						vcon.<String>get("currencyCode"),
						vcon.<Long>get("vendorConfigId")
						
				          ));

		tq.setParameter("vendorCode", vendorConfigDetailsDto.getVendorCode().toUpperCase().trim());
		tq.setParameter("currencyCode", vendorConfigDetailsDto.getCurrencyCode().toUpperCase().trim());
		tq.setParameter("billedToLocationId", vendorConfigDetailsDto.getBilledToLocationId());
		tq.setParameter("billedFromLocationId", vendorConfigDetailsDto.getBilledFromLocationId());
		
	    List<VendorConfigDetailsDto> vendorCodeList = tq.getResultList();
		
	    if (!vendorCodeList.isEmpty())
		return vendorCodeList.get(0);
	    else
	    	return null;
	    	
	}
	

	@Override
	@Transactional
	public   Map<String, Object> insertVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto,String sso){
		
		logger.info("**insert vendor config dao Impl**");
		Map<String, Object> outMap = new HashMap<>();
		try {
			VendorConfig venCon = new VendorConfig();

			venCon.setVendorEntityId(vendorConfigDetailsDto.getVendorEntityId());
			venCon.setVendorCode(vendorConfigDetailsDto.getVendorCode().toUpperCase().trim());
			venCon.setBilledFromLocationId(vendorConfigDetailsDto.getBilledFromLocationId());
			venCon.setBilledToLocationId(vendorConfigDetailsDto.getBilledToLocationId());
			venCon.setCurrencyCode(vendorConfigDetailsDto.getCurrencyCode().toUpperCase().trim());
			venCon.setActive(vendorConfigDetailsDto.isActive());
			venCon.setDateFormat(vendorConfigDetailsDto.getDateFormat().toUpperCase().trim());
			venCon.setLldCoeFlag(vendorConfigDetailsDto.getLldCoeFlag()!=null?vendorConfigDetailsDto.getLldCoeFlag():GcbConstants.EMPTY_STR);
			venCon.setExchangeRateType(vendorConfigDetailsDto.getExchangeRateType()!=null?vendorConfigDetailsDto.getExchangeRateType().toUpperCase().trim():GcbConstants.EMPTY_STR);
			venCon.setVendorContactEmail(vendorConfigDetailsDto.getVendorContactEmail()!=null?vendorConfigDetailsDto.getVendorContactEmail().toUpperCase().trim():GcbConstants.EMPTY_STR);
			venCon.setPaymentApprovalEmail(vendorConfigDetailsDto.getPaymentApprovalEmail()!=null?vendorConfigDetailsDto.getPaymentApprovalEmail().toUpperCase().trim():GcbConstants.EMPTY_STR);
			venCon.setExpectedFeedDate(GcbUtil.convertStringtoDate2(vendorConfigDetailsDto.getExpectedFeedDate()));
			venCon.setFinalInvoiceDate(GcbUtil.convertStringtoDate2(vendorConfigDetailsDto.getFinalInvoiceDate()));
			//venCon.setReportingSecurityDl(vendorConfigDetailsDto.getReportingSecurityDl().toUpperCase().trim());
			venCon.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			venCon.setCreatedBy(sso);			
			venCon.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			venCon.setUpdatedBy(sso);
			
			save(venCon);
			
			outMap.put(GcbConstants.ERROR, false);
			outMap.put(GcbConstants.PK_ID, venCon.getVendorConfigId());
		
		} catch (Exception e) {
			logger.error("Error : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	@Transactional
	public   Map<String, Object> updateVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto,String sso){
		
		logger.info("**update vendor config dao Impl**");
		Map<String, Object> outMap = new HashMap<>();
		try {
//			VendorConfig venCon = new VendorConfig();
//
//			venCon.setVendorEntityId(vendorConfigDetailsDto.getVendorEntityId());
//			venCon.setVendorCode(vendorConfigDetailsDto.getVendorCode());
//			venCon.setBilledFromLocationId(vendorConfigDetailsDto.getBilledFromLocationId());
//			venCon.setBilledToLocationId(vendorConfigDetailsDto.getBilledToLocationId());
//			venCon.setCurrencyCode(vendorConfigDetailsDto.getCurrencyCode());
//			venCon.setActive(vendorConfigDetailsDto.isActive());
//			venCon.setDateFormat(vendorConfigDetailsDto.getDateFormat());
//			venCon.setLldCoeFlag(vendorConfigDetailsDto.isLldCoeFlag());
//			venCon.setExchangeRateType(vendorConfigDetailsDto.getExchangeRateType());
//			venCon.setVendorContactEmail(vendorConfigDetailsDto.getVendorContactEmail());
//			venCon.setExpectedFeedDate(vendorConfigDetailsDto.getExpectedFeedDate());
//			venCon.setFinalInvoiceDate(vendorConfigDetailsDto.getFinalInvoiceDate());
//			venCon.setReportingSecurityDl(vendorConfigDetailsDto.getReportingSecurityDl());
//			venCon.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
//			venCon.setCreatedBy(vendorConfigDetailsDto.getCreatedBy());			
//			venCon.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
//			venCon.setUpdatedBy(vendorConfigDetailsDto.getUpdatedBy());
//			
//			//saveOrUpdate(venCon);
//			update(venCon);
//			

			CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
			CriteriaUpdate<VendorConfig> updateQuery = builder.createCriteriaUpdate(VendorConfig.class);
			Root<VendorConfig> serviceType = updateQuery.from(VendorConfig.class);

			updateQuery.set("vendorCode", vendorConfigDetailsDto.getVendorCode().toUpperCase().trim());
			updateQuery.set("billedFromLocationId", vendorConfigDetailsDto.getBilledFromLocationId());
			updateQuery.set("billedToLocationId", vendorConfigDetailsDto.getBilledToLocationId());
			updateQuery.set("currencyCode", vendorConfigDetailsDto.getCurrencyCode().toUpperCase().trim());
			updateQuery.set("active", vendorConfigDetailsDto.isActive());
			updateQuery.set("dateFormat", vendorConfigDetailsDto.getDateFormat().toUpperCase().trim());
			updateQuery.set("lldCoeFlag", vendorConfigDetailsDto.getLldCoeFlag().toUpperCase().trim());
			updateQuery.set("exchangeRateType", vendorConfigDetailsDto.getExchangeRateType().toUpperCase().trim());
			updateQuery.set("vendorContactEmail", vendorConfigDetailsDto.getVendorContactEmail().toUpperCase().trim());
			updateQuery.set("paymentApprovalEmail", vendorConfigDetailsDto.getPaymentApprovalEmail().toUpperCase().trim());
			updateQuery.set("expectedFeedDate",GcbUtil.convertStringtoDate2(vendorConfigDetailsDto.getExpectedFeedDate()));
			updateQuery.set("finalInvoiceDate", GcbUtil.convertStringtoDate2(vendorConfigDetailsDto.getFinalInvoiceDate()));
			//updateQuery.set("reportingSecurityDl", vendorConfigDetailsDto.getReportingSecurityDl().toUpperCase().trim());
			updateQuery.set("lastUpdated", GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			updateQuery.set("updatedBy", sso);
			updateQuery.where(
					builder.and(builder.equal(serviceType.get("vendorConfigId"), vendorConfigDetailsDto.getVendorConfigId())));

			int count = getEntityManager().createQuery(updateQuery).executeUpdate();
			
			outMap.put(GcbConstants.ERROR, false);
			outMap.put(GcbConstants.PK_ID, vendorConfigDetailsDto.getVendorConfigId());
		
		} catch (Exception e) {
			logger.error("Error : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.INSERT_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	public List<VendorConfigDownloadDto> getDwnVendorConfig() {
		CriteriaBuilder cBuilder  = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorConfigDownloadDto> cQuery = cBuilder.createQuery(VendorConfigDownloadDto.class);
		Root<VendorConfig> venConf =cQuery.from(VendorConfig.class );
		Join<VendorConfig,Location> locBillFrm = venConf.join("locationFromCtry",JoinType.INNER);
		Join<VendorConfig,Location> locBillTo = venConf.join("locationToCtry",JoinType.INNER);
		Join<VendorConfig,Vendor> vendor = venConf.join("vendor",JoinType.INNER);

		final TypedQuery tq = getEntityManager().createQuery(
				cQuery.multiselect(
								vendor.<String>get("vendorLegalEntityName"),
								venConf.<String>get("currencyCode"),
								locBillFrm.<String>get("locationName"),
								locBillTo.<String>get("locationName"),
								venConf.<String>get("vendorCode"),
								venConf.<String>get("updatedBy"),
								venConf.<String>get("lastUpdated")
						          ) 
				      .orderBy(cBuilder.asc(vendor.get("vendorLegalEntityName")))
				);

		List<VendorConfigDownloadDto> VendorConfigDetailsDtoList = tq.getResultList();
		
		return VendorConfigDetailsDtoList;
	}


}
