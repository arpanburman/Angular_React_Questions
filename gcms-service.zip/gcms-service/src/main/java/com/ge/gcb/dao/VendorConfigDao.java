package com.ge.gcb.dao;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.VendorConfigDetailsDto;
import com.ge.gcb.dto.VendorConfigDownloadDto;
import com.ge.gcb.dto.VendorConfigDto;

public interface VendorConfigDao {

	public List<VendorConfigDto> getVendorConfig();
	
	public List<VendorConfigDetailsDto> getVendorConfigDetails();
	
	public VendorConfigDetailsDto checkVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto);

	public Map<String, Object> insertVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto,String sso);
	
	public Map<String, Object> updateVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto,String sso);

	public List<VendorConfigDownloadDto> getDwnVendorConfig();
	
}
