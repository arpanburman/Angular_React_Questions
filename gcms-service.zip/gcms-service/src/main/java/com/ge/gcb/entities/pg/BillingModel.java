package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblbilling_model")
public class BillingModel {
	
	@Id
	@Column(name="billing_model_id")
	private String billingModelId;
	
	@Column(name="billing_model_description")
	private String billingModelDesc;

	public String getBillingModelId() {
		return billingModelId;
	}

	public void setBillingModelId(String billingModelId) {
		this.billingModelId = billingModelId;
	}

	public String getBillingModelDesc() {
		return billingModelDesc;
	}

	public void setBillingModelDesc(String billingModelDesc) {
		this.billingModelDesc = billingModelDesc;
	}
	
}
