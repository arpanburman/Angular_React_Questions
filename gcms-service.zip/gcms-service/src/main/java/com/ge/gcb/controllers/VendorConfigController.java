package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.VendorConfigDetailsDto;
import com.ge.gcb.dto.VendorConfigDownloadDto;
import com.ge.gcb.dto.VendorConfigDto;
import com.ge.gcb.services.VendorConfigService;

@RestController
public class VendorConfigController {

	private static final Logger logger = LogManager.getLogger(VendorConfigController.class);
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	VendorConfigService vendorConfigService;
	
	@CrossOrigin
	@RequestMapping("/vendorconfig")
	public ResponseEntity<List<VendorConfigDto>> getVendorConfig()
	{
		logger.info("*******VendorConfigController : getVendorConfig()");
		List<VendorConfigDto> vendorConfigDtoList =new ArrayList<>();
		try {
			vendorConfigDtoList=vendorConfigService.getVendorConfig();
		}catch(Exception e)
		{
			logger.error("Error in getVendorConfig() : {}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorConfigDtoList);	
		}
		 
		return ResponseEntity.status(HttpStatus.OK).body(vendorConfigDtoList);		
		}
	
	@CrossOrigin
	@RequestMapping("/vendorconfig-details")
	public ResponseEntity<List<VendorConfigDetailsDto>> getVendorConfigDetails()
	{
		logger.info("*******VendorConfigController : getVendorConfigDetails()");
		List<VendorConfigDetailsDto> vendorConfigDetailsDtoList =new ArrayList<>();
		try {
			vendorConfigDetailsDtoList=vendorConfigService.getVendorConfigDetails();
		}catch(Exception e)
		{
			logger.error("Error in getVendorConfigDetails() : {}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorConfigDetailsDtoList);	
		}
		 
		return ResponseEntity.status(HttpStatus.OK).body(vendorConfigDetailsDtoList);		
		}
	
	@CrossOrigin
	@RequestMapping(value="/vendorconfig",method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Map<String, Object>> upsertVendorConfig(@RequestBody VendorConfigDetailsDto userVenConf )
	{   
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();
		logger.info("****VendorConfigController : checkVendorConfig()");
		try {
			outMap=vendorConfigService.upsertVendorConfig(userVenConf,sso);
		}
		catch(Exception e)
		{
			logger.error("Error in checkVendorConfig() : {}",e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(outMap);
		}
	 	return ResponseEntity.status(HttpStatus.OK).body(outMap);
		
	}
	
	@CrossOrigin
	@RequestMapping("/dwnVendorConfig")
	public ResponseEntity<List<VendorConfigDownloadDto>> dwnVendorConfig()
	{
		logger.info("*******VendorConfigController : getVendorConfigDetails()");
		List<VendorConfigDownloadDto> vendorConfigDetailsDtoList =new ArrayList<>();
		try {
			vendorConfigDetailsDtoList=vendorConfigService.getDwnVendorConfig();
		}catch(Exception e)
		{
			logger.error("Error in getVendorConfigDetails() : {}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorConfigDetailsDtoList);	
		}
		 
		return ResponseEntity.status(HttpStatus.OK).body(vendorConfigDetailsDtoList);		
		}
	
}
