package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BuyerTreeViewDao;
import com.ge.gcb.entities.pg.BuyerTreeView;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class BuyerTreeViewDaoImpl extends JpaCrudRepositoryPgImpl<BuyerTreeView, String>  implements BuyerTreeViewDao {

	@Override
	public String getBuyerTree() {
		List<BuyerTreeView> buyerObj = findAll();
		if(buyerObj!=null) {
			return buyerObj.get(0).getBuyerTree();
		}
		return null;
	}

}
