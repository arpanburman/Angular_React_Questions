package com.ge.gcb.dao.pg.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.ProductDao;
import com.ge.gcb.dto.ProductDto;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class ProductDaoImpl extends JpaCrudRepositoryPgImpl<Product, Integer>  implements ProductDao {
	private static final Logger logger = LogManager.getLogger(ProductDaoImpl.class);
	
	

	@Override
	public List<ProductDto> getProductDetails() {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<ProductDto> criteriaQuery = builder.createQuery(ProductDto.class);
		Root<Product> product = criteriaQuery.from(Product.class);
		Root<BillProcess> billProcess = criteriaQuery.from(BillProcess.class);
		final TypedQuery<ProductDto> query = getEntityManager()
				.createQuery(criteriaQuery.multiselect(
						product.<Integer>get("productId"),	
						product.<Integer>get("billProcessId"),
						billProcess.get("processName"),
						product.get("productName"),
						product.get("productCode"),						
						product.get("unspsc"),
						product.<String>get("created"),
						product.<String>get("lastUpdated"),
						product.get("updatedBy"))
						.where(builder.equal(product.get("billProcessId"), billProcess.get("billProcessId")))
						         .orderBy(builder.asc(product.get("productName"))));

		List<ProductDto> productList = query.getResultList();
		return productList;
	}




	@Override
	public List<Product> getProduct() {
		return findAll();
	}



//	@Override
//	@Transactional
//	public boolean updateUnspsc(Long productId, String unspsc,String sso) {
//		long millis = System.currentTimeMillis();
//		Date date = new Date(millis);
//		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
//		CriteriaUpdate<Product> updateQuery = builder.createCriteriaUpdate(Product.class);
//		Root<Product> serviceType = updateQuery.from(Product.class);
//		updateQuery.set("unspsc", unspsc);
//		updateQuery.set("lastUpdated", date);
//		updateQuery.set("updatedBy", sso);
//		updateQuery.where(
//				builder.and(builder.equal(serviceType.<Integer>get("productId"), productId.intValue())));
//
//		int count = getEntityManager().createQuery(updateQuery).executeUpdate();
//		return true;
//
//	}
		
	
	@Override
	public Product getProductById(String productId) {
		int id=Integer.parseInt(productId);
		return findById(id);
	}




	@Transactional
	@Override
	public Map<String, Object> updateProduct(Product productData,String sso) {
		logger.info("**update product Dao**");
		Map<String, Object> outMap = new HashMap<>();	

		try {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<Product> updateQuery = builder.createCriteriaUpdate(Product.class);
		Root<Product> product = updateQuery.from(Product.class);
		updateQuery.set("billProcessId", productData.getBillProcessId());
		updateQuery.set("productName", productData.getProductName().toUpperCase().trim());
		updateQuery.set("productCode",productData.getProductCode().toUpperCase().trim());
		updateQuery.set("unspsc", productData.getUnspsc().toUpperCase().trim());
		updateQuery.set("lastUpdated", GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
		updateQuery.set("updatedBy", sso);
		updateQuery.where(
				builder.and(builder.equal(product.get("productId"), productData.getProductId())));
		int count = getEntityManager().createQuery(updateQuery).executeUpdate();		
		outMap.put("statusMessage","Product was successfully updated ");
		outMap.put(GcbConstants.ERROR, false);
		}
		catch (Exception e){
			logger.error("Error : {}", e.getMessage());
			outMap.put("statusMessage","Update Fail");
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	
	}




	@Override
	@Transactional
	public Map<String, Object> saveProduct(Product product,String sso) {
		logger.info("**insert product Dao**");
		Map<String, Object> outMap = new HashMap<>();
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		try {
			product.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			product.setCreatedBy(sso);
			product.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			product.setUpdatedBy(sso);
			product.setProductName(product.getProductName().toUpperCase().trim());
			product.setProductCode(product.getProductCode().toUpperCase().trim());
			product.setUnspsc(product.getUnspsc().toUpperCase().trim());
			save(product);
			outMap.put("statusMessage", "Product was successfully created ");
			outMap.put(GcbConstants.ERROR, false);
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put("statusMessage","Insert Fail");
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	public Product getProduct(String productCode,String productName) {
		try {
			CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
			CriteriaQuery<Product> criteriaQuery = builder.createQuery(Product.class);
			Root<Product> product = criteriaQuery.from(Product.class);

			final TypedQuery<Product> query = getEntityManager()
					.createQuery(criteriaQuery.select(product).where(
							builder.or(builder.equal(product.get("productCode"), productCode.toUpperCase().trim()),
									   builder.equal(product.get("productName"), productName.toUpperCase().trim()))));			
			
		
			List<Product> methodList = query.getResultList();
			if (!methodList.isEmpty())
				return methodList.get(0);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}



	@Override
	public boolean updateUnspsc(Long productId, String unspsc, String sso) {
		return false;
	}
}
