package com.ge.gcb.services;

import java.util.List;

import com.ge.gcb.entities.pg.Currency;

public interface CurrencyService {

	public List<Currency> getCurrencyList();
	
}
