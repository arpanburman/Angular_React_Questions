package com.ge.gcb.services;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.VendorDto;
import com.ge.gcb.entities.pg.HlVendor;
import com.ge.gcb.entities.pg.Vendor;

public interface VendorService {
	
	public List<VendorDto> getAllVendors();

	public Map<String, Object> saveOrUpdateVendor(Vendor vendor, String sso);

	public List<VendorDto> downloadVendorData();

	public List<HlVendor> getAllHlVendors();

	public List<VendorDto> AllVendorNames();
}
