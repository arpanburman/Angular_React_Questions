package com.ge.gcb.dao.pg.impl;
/**
 * @author aburman 188058
 **/

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ge.gcb.dao.pg.VendorDao;
import com.ge.gcb.dto.VendorDto;
import com.ge.gcb.entities.pg.HlVendor;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class VendorDaoImpl extends JpaCrudRepositoryPgImpl<Vendor, String> implements VendorDao {
	
	private static final Logger logger = LogManager.getLogger(VendorDaoImpl.class);

	@Override
	public List<VendorDto> getAllVendor() {
		logger.info("**Get All vendors**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorDto> criteriaQuery = builder.createQuery(VendorDto.class);
		Root<Vendor> vendorType = criteriaQuery.from(Vendor.class);
		Root<HlVendor> vendorHlType = criteriaQuery.from(HlVendor.class);
		List<VendorDto> vendorLst = null;
		try {
			final TypedQuery<VendorDto> query = getEntityManager()
					.createQuery(
							criteriaQuery.multiselect(vendorHlType.get("hlVendorName"),vendorHlType.<Integer>get("hlvendorId"),
									vendorType.get("vendorLegalEntityName"),vendorType.<Integer>get("vendorEntityId"),vendorType.get("active"),
							vendorType.get("updatedBy"),vendorType.get("lastUpdatedDate")
							).where(builder.and(builder.equal(vendorType.<Integer>get("hlVendorId"), vendorHlType.<Integer>get("hlvendorId"))))
							.orderBy(builder.asc(vendorType.get("vendorLegalEntityName")))
							);

			vendorLst = query.getResultList();
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return vendorLst;
	}

	@Override
	@Transactional
	public  Map<String, Object> updateVendor(Vendor vendor, String sso) {
		logger.info("**update vendors Dao**");
		Map<String, Object> outMap = new HashMap<>();
		try {
			//vendor.setCreatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			vendor.setLastUpdatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			vendor.setUpdatedBy(sso);
			saveOrUpdate(vendor);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_SUCCESS);
			outMap.put(GcbConstants.ERROR, false);
			outMap.put(GcbConstants.PK_ID, vendor.getVendorEntityId());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}
	
	@Override
	@Transactional
	public Map<String, Object> saveVendor(Vendor vendor, String sso) {
		logger.info("**Save vendors Dao**");
		Map<String, Object> outMap = new HashMap<>();
		try {
			vendor.setCreatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			vendor.setLastUpdatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			vendor.setUpdatedBy(sso);
			vendor.setCreatedBy(sso);
			//save(vendor);
			saveOrUpdate(vendor);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_SUCCESS);
			outMap.put(GcbConstants.ERROR, false);
			outMap.put(GcbConstants.PK_ID, vendor.getVendorEntityId());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	public boolean findVendorName(String vendorName) {
		List<Vendor> vendorLst = null;
		boolean flag = false;
		try {
			CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
			CriteriaQuery<Vendor> criteriaQuery = builder.createQuery(Vendor.class);
			Root<Vendor> fromVendorDetails = criteriaQuery.from(Vendor.class);
			final TypedQuery<Vendor> query = getEntityManager().createQuery(criteriaQuery.select(fromVendorDetails)
					.where(builder.and(builder.equal(builder.upper(fromVendorDetails.<String>get(GcbConstants.VENDOR_NAME_ET)), 
							vendorName.trim().toUpperCase())

			)));
			vendorLst = query.getResultList();
			int vendorSize=vendorLst.size();
			logger.info("***Vendor Size*** {}",vendorSize);
			if (vendorSize>0)
				flag = true;
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}

		return flag;
	}
	
	@Override
	public List<VendorDto> downloadVendorData() {
		logger.info("**Get All vendors**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorDto> criteriaQuery = builder.createQuery(VendorDto.class);
		Root<Vendor> vendorType = criteriaQuery.from(Vendor.class);
		Root<HlVendor> vendorHlType = criteriaQuery.from(HlVendor.class);
		List<VendorDto> vendorLst = null;
		try {
			final TypedQuery<VendorDto> query = getEntityManager()
					.createQuery(
							criteriaQuery.multiselect(vendorHlType.get("hlVendorName"),vendorType.get("vendorLegalEntityName"),vendorType.get("active"),
							vendorType.get("updatedBy"),vendorType.get("lastUpdatedDate")
							).where(builder.and(builder.equal(vendorType.<Integer>get("hlVendorId"), vendorHlType.<Integer>get("hlvendorId"))))
							.orderBy(builder.asc(vendorHlType.get("hlVendorName")))
							);

			vendorLst = query.getResultList();
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return vendorLst;
	}
	
	@Override
	public List<VendorDto> AllVendorNames() {
		logger.info("**Get All vendors**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<VendorDto> criteriaQuery = builder.createQuery(VendorDto.class);
		Root<Vendor> vendorType = criteriaQuery.from(Vendor.class);
		Root<HlVendor> vendorHlType = criteriaQuery.from(HlVendor.class);
		List<VendorDto> vendorLst = null;
		try {
			final TypedQuery<VendorDto> query = getEntityManager()
					.createQuery(
							criteriaQuery.multiselect(vendorType.get("vendorEntityId"),vendorHlType.get("hlVendorName"),
									vendorType.get("vendorLegalEntityName"),vendorType.get("active"),
							vendorType.get("updatedBy"),vendorType.get("lastUpdatedDate")
							).where(builder.and(builder.equal(vendorType.<Integer>get("hlVendorId"), vendorHlType.<Integer>get("hlvendorId"))))
							.orderBy(builder.asc(vendorType.get("vendorLegalEntityName")))
							);

			vendorLst = query.getResultList();
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return vendorLst;
	}
}
