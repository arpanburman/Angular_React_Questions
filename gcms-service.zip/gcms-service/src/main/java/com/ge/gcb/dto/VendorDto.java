package com.ge.gcb.dto;

import javax.persistence.Convert;
import com.ge.gcb.entities.pg.DateConverter;

public class VendorDto {
	
	private int hlVendorId;
	
	private int vendorEntityId;
	
	private String hlVendorName;
	
	private String vendorLegalEntityName; 
	
	private boolean active;
	
	@Convert(converter = DateConverter.class)
	private String lastUpdatedDate;
	
	private String updatedBy;

	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}

	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getHlVendorName() {
		return hlVendorName;
	}

	public void setHlVendorName(String hlVendorName) {
		this.hlVendorName = hlVendorName;
	}
	public int getVendorEntityId() {
		return vendorEntityId;
	}

	public void setVendorEntityId(int vendorEntityId) {
		this.vendorEntityId = vendorEntityId;
	}
	//for screen
	public VendorDto(int vendorEntityId,String hlVendorName, String vendorLegalEntityName, boolean active, 
			String updatedBy,String lastUpdatedDate) {
		super();
		this.vendorEntityId=vendorEntityId;
		this.hlVendorName = hlVendorName;
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.active = active;
		this.lastUpdatedDate = lastUpdatedDate;
		this.updatedBy = updatedBy;
	}
//for download
	public VendorDto(String hlVendorName, String vendorLegalEntityName, boolean active,
			String updatedBy, String lastUpdatedDate) {
		super();
		this.hlVendorName = hlVendorName;
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.active = active;
		this.lastUpdatedDate = lastUpdatedDate;
		this.updatedBy = updatedBy;
	}
	//for vendor LOVs
	public VendorDto(String hlVendorName,int hlVendorId, String vendorLegalEntityName,int vendorEntityId, boolean active,
			String updatedBy, String lastUpdatedDate) {
		super();
		this.hlVendorName = hlVendorName;
        this.hlVendorId=hlVendorId;
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.vendorEntityId=vendorEntityId;
		this.active = active;
		this.lastUpdatedDate = lastUpdatedDate;
		this.updatedBy = updatedBy;
	}

	public int gethlVendorId() {
		return hlVendorId;
	}

	public void sethlVendorId(int hlVendorId) {
		this.hlVendorId = hlVendorId;
	}


	

}
