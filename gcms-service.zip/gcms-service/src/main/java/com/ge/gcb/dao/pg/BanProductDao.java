package com.ge.gcb.dao.pg;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.BanProductDto;
import com.ge.gcb.entities.pg.BanProductMaster;
import com.ge.gcb.entities.pg.ServiceType;

public interface BanProductDao {

	Map<String, Object> saveBanProduct(List<BanProductDto> banProductDataList, String banId, String sso);

	List<BanProductMaster> getBanProductById(Integer banId);

	BanProductMaster fetchTargetServiceTypeDetails(ServiceType serviceTypeList, String banId);

}
