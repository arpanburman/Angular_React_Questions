package com.ge.gcb.dto;

public class VendorConfigDownloadDto {

	private String vendorLegalEntityName;
	private String currencyCode;
	private String billedFromCountry;
	private String billedToCountry;
	private String vendorCode;
	private String updatedBy;
	private String lastUpdated;
	
	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}
	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public String getBilledFromCountry() {
		return billedFromCountry;
	}
	public void setBilledFromCountry(String billedFromCountry) {
		this.billedFromCountry = billedFromCountry;
	}
	public String getBilledToCountry() {
		return billedToCountry;
	}
	public void setBilledToCountry(String billedToCountry) {
		this.billedToCountry = billedToCountry;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public VendorConfigDownloadDto(String vendorLegalEntityName, String currencyCode, String billedFromCountry,
			String billedToCountry, String vendorCode, String updatedBy, String lastUpdated) {
		super();
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.currencyCode = currencyCode;
		this.billedFromCountry = billedFromCountry;
		this.billedToCountry = billedToCountry;
		this.vendorCode = vendorCode;
		this.updatedBy = updatedBy;
		this.lastUpdated = lastUpdated;
	}
	
	
}
