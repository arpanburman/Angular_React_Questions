package com.ge.gcb.entities.pg;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/*@Entity
@IdClass(BanFocusGroup.class)
@Table(name="t_ban_focus_group")*/
@Embeddable
class BanFocusGroupIdentity implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//@Id
	@Column(name="focus_group_id")
	private int focusGroupId	;
	
	//@Id
	@Column(name="ban_id")
	private long banId;

	public int getFocusGroupId() {
		return focusGroupId;
	}

	public void setFocusGroupId(int focusGroupId) {
		this.focusGroupId = focusGroupId;
	}

	public long getBanId() {
		return banId;
	}

	public void setBanId(long banId) {
		this.banId = banId;
	}
	
	

}
