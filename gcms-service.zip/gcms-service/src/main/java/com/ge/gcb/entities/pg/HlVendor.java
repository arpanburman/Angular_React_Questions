package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name="t_hl_vendor")
public class HlVendor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="hl_vendor_id")
	private int hlvendorId;
	
	@ApiModelProperty(notes = "The Vendor HL Name")
	@Column(name="hl_vendor_name")
	private String hlVendorName;
	
	@ApiModelProperty(notes = "The Vendor Created Date")
	@Column(name="created", updatable=false)
	@Convert(converter = DateConverter.class)
	private String createdDate;
	
	@ApiModelProperty(notes = "The Vendor Created By")
	@Column(name="created_by", updatable=false)
	private String createdBy;
	
	@ApiModelProperty(notes = "The Vendor Data Last updated Date")
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdatedDate;
	
	@ApiModelProperty(notes = "The Vendor Data Updated By")
	@Column(name="updated_by")
	private String updatedBy;

	public int getHlvendorId() {
		return hlvendorId;
	}

	public void setHlvendorId(int hlvendorId) {
		this.hlvendorId = hlvendorId;
	}

	public String getHlVendorName() {
		return hlVendorName;
	}

	public void setHlVendorName(String hlVendorName) {
		this.hlVendorName = hlVendorName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
