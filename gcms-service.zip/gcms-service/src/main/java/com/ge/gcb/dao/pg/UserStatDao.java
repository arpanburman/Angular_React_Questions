package com.ge.gcb.dao.pg;

import java.util.Date;
import java.util.List;

import com.ge.gcb.entities.pg.UserStat;

public interface UserStatDao {

	/**
	 * @param sso
	 * @return
	 */
	public UserStat checkUserEntry(String sso);

	/**
	 * @param last_login_time
	 * @param noOfLogin
	 * @param sso
	 * @return
	 */
	int updateUserData(int noOfLogin, String sso);

	/**
	 * @param sso
	 */
	public void insertUserData(String sso);
	
}
