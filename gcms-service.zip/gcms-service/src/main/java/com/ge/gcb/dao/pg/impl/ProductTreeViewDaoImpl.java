package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.ProductTreeViewDao;
import com.ge.gcb.entities.pg.ProductTreeView;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class ProductTreeViewDaoImpl extends JpaCrudRepositoryPgImpl<ProductTreeView, String> implements ProductTreeViewDao   {

	private static final Logger logger = LogManager.getLogger(ProductTreeViewDaoImpl.class);

	@Override
	public String getBillProcessesTree() {

		logger.info("ProductTreeViewDaoImpl : billProcess()");
		List<ProductTreeView> billProcessData= findAll();
		if(billProcessData!=null) {
			return billProcessData.get(0).getBillProcesses();
		}
		else {
			return null;
		}
	}

	
}
