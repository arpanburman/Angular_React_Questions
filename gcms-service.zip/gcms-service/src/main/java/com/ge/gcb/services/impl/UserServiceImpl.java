package com.ge.gcb.services.impl;

import java.sql.SQLException;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ge.gcb.dao.pg.UserStatDao;
import com.ge.gcb.dao.pg.impl.UserDaoImpl;
import com.ge.gcb.entities.pg.User;
import com.ge.gcb.entities.pg.UserStat;
import com.ge.gcb.services.UserService;
import com.ge.gcb.utils.GcbUtil;

@Service
public class UserServiceImpl implements UserService {
	private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);
	@Autowired
	UserDaoImpl userDaoImpl;
	
	@Autowired
	UserStatDao userStatDao;
	
	@Override
	public User getUserDetails(String sso) {
		logger.info("INSIDE GCB UserServiceImpl Method :");
		return userDaoImpl.getUserDetails(sso);
	}

	@Override
	public User saveUserDetails(User user) {

		logger.info("INSIDE GCB UserServiceImpl Method :");
		try {
			userDaoImpl.saveUserDetails(user);
			logger.info("User Details Saved successfully");
		}
		catch(SQLException e) {
			logger.error("Error Saving Data : " ,e.getMessage());
			return userDaoImpl.getUserDetails(user.getSso());
		}
		catch(DataIntegrityViolationException e) {
			logger.error("Error Saving Data : " ,e.getMessage());
			return userDaoImpl.getUserDetails(user.getSso());
		}
		catch (Exception e) {
			logger.error("Error Saving Data : " ,e);
			return null;
		}
		return user;
	}

	/**
	 * @param sso
	 * @return
	 */
	@Transactional
	public void updateUserStat(String sso) {

		Date today = new java.util.Date();
		String currentDate = GcbUtil.convertDateToStringMMDDYYYY(today);
		int noOfLogin = 0;	
		UserStat userlist = userStatDao.checkUserEntry(sso);
		if(userlist!=null) {
			String lastLoginTime = GcbUtil.getDateMMddYYYY(userlist.getLastLogin().toString());
			String lastlogintime = GcbUtil.getDateDifference(lastLoginTime, currentDate);
			if (!GcbUtil.isEmpty(lastlogintime)) {
				if (lastlogintime.equalsIgnoreCase("greater")) {
					noOfLogin = userlist.getNumberOfLogins() + 1;
				} else {
					noOfLogin =userlist.getNumberOfLogins();
				}
			}		
			int count=userStatDao.updateUserData(noOfLogin, sso);			
			   logger.info("User Record Updated Count:{} ",()->count);		

		}
		else {
			userStatDao.insertUserData(sso);
		}
	}

	@Override
	public boolean isUserExist(String sso) {
		User user = userDaoImpl.findById(sso);
		if(user!=null) {
			return true;
		}
		else {
			return false;
		}
	}

	
	
}
