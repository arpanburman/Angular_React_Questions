package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BanDao;
import com.ge.gcb.dto.BanDto;
import com.ge.gcb.dto.BanDwnDto;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.Buyer;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.entities.pg.VendorConfig;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class BanDaoImpl extends JpaCrudRepositoryPgImpl<Ban, Long> implements BanDao{

	private static final Logger logger = LogManager.getLogger(BanDaoImpl.class);
	
	@Override
	@Cacheable("banDetails")
	public List<BanDto> getAllBans() {
		logger.info("**Get All Ban**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<BanDto> criteriaQuery = builder.createQuery(BanDto.class);
		Root<Ban> banType = criteriaQuery.from(Ban.class);
		Root<VendorConfig> vendorConfigType = criteriaQuery.from(VendorConfig.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<Buyer> buyerType = criteriaQuery.from(Buyer.class);
		List<BanDto> banLst = null;
		try {
			final TypedQuery<BanDto> query = getEntityManager()
					.createQuery(criteriaQuery.multiselect(
							banType.<Long>get("banId"), 
							banType.get("vendorBan"),
							banType.<Long>get("vendorConfigId"),
							vendorConfigType.get("vendorCode"),
							vendorConfigType.get("locationFromCtry").get("locationName"),
							vendorConfigType.get("locationToCtry").get("locationName"),
							vendorConfigType.get("vendor").get("vendorLegalEntityName"),
							banType.get("invoiceName"),
							banType.get("vendorPaidBy"),
							banType.get("liquidatedVia"),
							banType.get("taxEngine"),
							serviceType.<Long>get("serviceTypeId"), 
							serviceType.get("serviceTypeName"),
							banType.<Long>get("buyerId"),
							buyerType.get("erpBuyerLeName"),
							banType.<Long>get("liquidateBillRoutingId"),
							banType.get("mode"),
							banType.get("lastUpdated"),
							banType.get("updatedBy"))
							.where(
									builder.and(builder.equal(banType.<Long>get("vendorConfigId"), vendorConfigType.<Long>get("vendorConfigId"))),
									builder.and(builder.equal(banType.<Long>get("billProcessId"), serviceType.<Long>get("serviceTypeId"))),
									builder.and(builder.equal(banType.<Long>get("buyerId"), buyerType.<Long>get("buyerId"))))
							.orderBy(builder.asc(banType.get("banId"))));

			banLst = query.getResultList();
			logger.info("**Get All Bans count {} **",banLst.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return banLst;
	}

	@Override
	public List<BanDwnDto> downloadBanData() {
		logger.info("**Get All Ban Download data**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<BanDwnDto> criteriaQuery = builder.createQuery(BanDwnDto.class);
		Root<Ban> banType = criteriaQuery.from(Ban.class);
		Root<VendorConfig> vendorConfigType = criteriaQuery.from(VendorConfig.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<Buyer> buyerType = criteriaQuery.from(Buyer.class);
		List<BanDwnDto> banLst = null;
		try {
			final TypedQuery<BanDwnDto> query = getEntityManager()
					.createQuery(criteriaQuery.multiselect(banType.get("vendorBan"),
							vendorConfigType.get("vendor").get("vendorLegalEntityName"),
							vendorConfigType.get("locationFromCtry").get("locationName"),
							vendorConfigType.get("locationToCtry").get("locationName"),
							buyerType.get("erpBuyerLeName"),
							banType.get("invoiceName"),
							banType.get("vendorPaidBy"),
							banType.get("liquidatedVia"),
							banType.get("taxEngine"),
							banType.get("mode")
							)
							.where(
									builder.and(builder.equal(banType.<Long>get("vendorConfigId"), vendorConfigType.<Long>get("vendorConfigId"))),
									builder.and(builder.equal(banType.<Long>get("billProcessId"), serviceType.<Long>get("serviceTypeId"))),
									builder.and(builder.equal(banType.<Long>get("buyerId"), buyerType.<Long>get("buyerId"))))
							.orderBy(builder.asc(banType.get("banId"))));

			banLst = query.getResultList();
			logger.info("**Get All Bans count {} **",banLst.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return banLst;
	}

	@Override
	public List<Ban> getBans() {
		logger.info("**Get All Ban**");
		List<Ban> banList = null;
		try {
			banList = new ArrayList<>();
			banList = findAll();
			logger.info("**Get All Ban count {} **",banList.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return banList;
	}
	
	@Override
	@Transactional
	@CachePut(value="banDetails")
	public Map<String, Object> updateBan(Ban banData, String sso) {
		logger.info("**update Ban Dao**");
		Map<String, Object> outMap = new HashMap<>();
		try {
			banData.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			banData.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			banData.setActiveTo(GcbUtil.convertStringtoDate2(banData.getActiveTo()));
			banData.setUpdatedBy(sso);
			Map<String, Object> modeMap = changeMode(banData, sso);
			if(modeMap.get("Status").equals("SUCCESS")) {
				saveOrUpdate(banData);
			}
			else {
				return modeMap;
			}
			outMap.put(GcbConstants.ERROR, false);
			outMap.put("banId", banData.getBanId());
			outMap.put("statusMessage","Ban was successfully updated ");
			outMap.put("banId", banData.getBanId());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put("statusMessage","Update Fail");
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Transactional
	@Override
	@CachePut(value="banDetails")
	public Map<String, Object> saveBan(Ban banData, String sso) {
		logger.info("**insert Ban Dao**");
		Map<String, Object> outMap = new HashMap<>();		
		try {
			banData.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			banData.setCreatedBy(sso);
			banData.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
			banData.setActiveTo(GcbUtil.convertStringtoDate2(banData.getActiveTo()));
			banData.setSez(false);
			Map<String, Object> modeMap = changeMode(banData, sso);
			if(modeMap.get("Status").equals("SUCCESS")) {
				save(banData);
				outMap.put("statusMessage", " Ban was successfully created ");
				outMap.put("banId", banData.getBanId());
				outMap.put(GcbConstants.ERROR, false);
			}
			else {
				outMap.put("statusMessage", modeMap.get("statusMessage"));
				outMap.put(GcbConstants.ERROR, true);
			}
			
			
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put("statusMessage","Insert Fail");
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	public Ban getBanById(String banId) {
		long id=Integer.parseInt(banId);
		return findById(id);
	}

	public Map<String, Object> changeMode(Ban banData, String sso) {
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		Map<String, Object> outMap = new HashMap<>();		

		if (banData.getMode() != null
				&& banData.getMode().equalsIgnoreCase(GcbConstants.BAN_PROD_MODE)) {
			try {
				CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
				CriteriaUpdate<Ban> updateQuery = builder.createCriteriaUpdate(Ban.class);
				Root<Ban> cbObj = updateQuery.from(Ban.class);
				updateQuery.set("mode", GcbConstants.BAN_TEST_MODE);
				updateQuery.set("lastUpdated", GcbUtil.convertDateToStringMMDDYYYY(date));
				updateQuery.set("updatedBy", sso);
				updateQuery.where(builder.and(builder.or(builder.equal(cbObj.get("banId"), banData.getCloneOfId()),
						builder.equal(cbObj.get("cloneOfId"), banData.getBanId()),
						builder.equal(cbObj.get("cloneOfId"), banData.getCloneOfId())),
								builder.notEqual(cbObj.get("banId"), banData.getBanId())));
				getEntityManager().createQuery(updateQuery).executeUpdate();
				outMap.put("Status","SUCCESS");
			}catch (Exception e) {
				logger.error("Error : {}", e.getMessage());
				outMap.put("statusMessage","Ban Production to Test Fail, Ban record with same Details already exists");
				outMap.put(GcbConstants.ERROR, true);
				outMap.put("Status","FAIL");
			}
			return outMap;
		}
		else {
			outMap.put("Status","SUCCESS");
		}
		return outMap;
	}

	@Override
	public Ban getBanRecord(Ban banData) {
		// TODO Auto-generated method stub
		//Long id = banData.getBanId() != null ? banData.getBanId() : 0;
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<Ban> criteriaQuery = builder.createQuery(Ban.class);
		Root<Ban> ban = criteriaQuery.from(Ban.class);

		final TypedQuery<Ban> query = getEntityManager()
				.createQuery(
						criteriaQuery.select(ban).where(
								builder.and(builder.and(builder.equal(ban.get("vendorBan"), banData.getVendorBan()),
										builder.equal(ban.get("billProcessId"),banData.getBillProcessId()),
										builder.equal(ban.get("mode"), banData.getMode()),
										builder.equal(ban.get("invoiceName"), banData.getInvoiceName()),
										builder.equal(ban.get("vendorPaidBy"), banData.getVendorPaidBy()),
										builder.equal(ban.get("liquidatedVia"), banData.getLiquidatedVia()),
										builder.equal(ban.get("taxEngine"), banData.getTaxEngine()))),
								builder.notEqual(ban.get("banId"), banData.getBanId())));

		List<Ban> methodList = query.getResultList();
		if (!methodList.isEmpty())
			return methodList.get(0);
		return null;
	}

	@Override
	public Ban getProdMode(Ban banData) {
		if (banData.getMode() != null
				&& banData.getMode().equalsIgnoreCase(GcbConstants.BAN_PROD_MODE)) {
			try {
				CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
				CriteriaQuery<Ban> criteriaQuery = builder.createQuery(Ban.class);
				Root<Ban> ban = criteriaQuery.from(Ban.class);

				final TypedQuery<Ban> query = getEntityManager()
						.createQuery(
								criteriaQuery.select(ban).where(builder.and(builder.or(builder.equal(ban.get("banId"), banData.getCloneOfId()),
										builder.equal(ban.get("cloneOfId"), banData.getBanId()),
										builder.equal(ban.get("cloneOfId"), banData.getCloneOfId())),
										builder.equal(ban.get("mode"), GcbConstants.BAN_PROD_MODE),
										builder.equal(ban.get("vendorBan"), banData.getVendorBan()),
												builder.notEqual(ban.get("banId"), banData.getBanId()))));
				List<Ban> methodList = query.getResultList();
				if (!methodList.isEmpty())
					return methodList.get(0);
			}catch (Exception e) {
				logger.error("Error : {}", e.getMessage());
			}
		}
		return null;
	}

}
