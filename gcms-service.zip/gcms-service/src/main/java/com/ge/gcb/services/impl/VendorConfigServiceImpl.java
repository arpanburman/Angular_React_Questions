package com.ge.gcb.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ge.gcb.dao.VendorConfigDao;
import com.ge.gcb.dto.VendorConfigDetailsDto;
import com.ge.gcb.dto.VendorConfigDownloadDto;
import com.ge.gcb.dto.VendorConfigDto;
import com.ge.gcb.services.VendorConfigService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Service
public class VendorConfigServiceImpl implements VendorConfigService {

	private static final Logger logger = LogManager.getLogger(VendorConfigServiceImpl.class);
	
	@Autowired
	VendorConfigDao vendorConfigDao;
	
	@Override
	public List<VendorConfigDto> getVendorConfig() {
		return vendorConfigDao.getVendorConfig();
	}
	
	@Override
	public List<VendorConfigDetailsDto>  getVendorConfigDetails(){
		return vendorConfigDao.getVendorConfigDetails();
	}
	
	@Override
	public Map<String, Object> upsertVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto, String sso)
	{
		Map<String, Object> outMap = new HashMap<>();
		VendorConfigDetailsDto vendorConfig;

		vendorConfig = vendorConfigDao.checkVendorConfig(vendorConfigDetailsDto);
		if (vendorConfig != null) {
			if (!GcbUtil.isEmpty(vendorConfigDetailsDto.getVendorConfigId())) {
				if (vendorConfigDetailsDto.getVendorConfigId() == vendorConfig.getVendorConfigId()) {
					outMap = vendorConfigDao.updateVendorConfig(vendorConfigDetailsDto,sso);
					logger.info("****insert VendorConfig Service ****");
					outMap.put(GcbConstants.MESSAGE,
							"VendorConfig was updated successfully.");
				} else {
					outMap.put(GcbConstants.MESSAGE,
							"VendorConfig already exists for the provided combination");
//							of "
//									+ vendorConfig.getVendorCode() + "|"
//									+ vendorConfig.getBilledFromCountryCode() + "|"
//									+ vendorConfig.getBilledToCountry() + "|"
//									+ vendorConfig.getCurrencyCode() + ". Vendor Config Id :"
//									+ vendorConfig.getVendorConfigId());
				}
			}else {
				outMap.put(GcbConstants.MESSAGE,
						"VendorConfig already exists for the provided combination");
				//+ "of "
//								+ vendorConfig.getVendorCode() + "|"
//								+ vendorConfig.getBilledFromCountryCode() + "|"
//								+ vendorConfig.getBilledToCountryCode() + "|"
//								+ vendorConfig.getCurrencyCode() + ". Vendor Config Id :"
//								+ vendorConfig.getVendorConfigId());
			}
		} else {
			if (GcbUtil.isEmpty(vendorConfigDetailsDto.getVendorConfigId())) {
				outMap = vendorConfigDao.insertVendorConfig(vendorConfigDetailsDto,sso);
				logger.info("****insert VendorConfig Service ****");
				if(outMap.get(GcbConstants.ERROR).equals(false))
				outMap.put(GcbConstants.MESSAGE,
						"VendorConfig was created successfully");
				else
					outMap.put(GcbConstants.MESSAGE,
							"VendorConfig was not created due to an error.");
					
			} else {
				outMap = vendorConfigDao.updateVendorConfig(vendorConfigDetailsDto,sso);
				logger.info("****insert VendorConfig Service ****");
				outMap.put(GcbConstants.MESSAGE,
						"VendorConfig was updated successfully.");
			}
		}
		return outMap;
	}

	@Override
	public List<VendorConfigDownloadDto> getDwnVendorConfig() {
		return vendorConfigDao.getDwnVendorConfig();
	}

}
