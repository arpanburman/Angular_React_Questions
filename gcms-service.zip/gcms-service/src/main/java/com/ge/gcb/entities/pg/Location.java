package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_location")
public class Location {
	
	@Id
	@Column(name="location_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long locationId;
	
	@Column(name="location_code")
	private String locationCode;
	
	@Column(name="location_name")
	private String locationName;
	
	@Column(name="parent_location_id")
	private long parentLocationId;
	
	@Column(name="location_type")
	private String locationType;
	
	@Column(name="location_full_code")
	private String locationFullCode;
	
	@Column(name="sez")
	private boolean sez;
	
	@Column(name="pdf_mandate")
	private boolean pdfMandate;
	
	@Column(name="division_flag")
	private boolean divisionFlag;

	public long getLocationId() {
		return locationId;
	}

	public void setLocationId(long locationId) {
		this.locationId = locationId;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public long getParentLocationId() {
		return parentLocationId;
	}

	public void setParentLocationId(long parentLocationId) {
		this.parentLocationId = parentLocationId;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public String getLocationFullCode() {
		return locationFullCode;
	}

	public void setLocationFullCode(String locationFullCode) {
		this.locationFullCode = locationFullCode;
	}

	public boolean isSez() {
		return sez;
	}

	public void setSez(boolean sez) {
		this.sez = sez;
	}

	public boolean isPdfMandate() {
		return pdfMandate;
	}

	public void setPdfMandate(boolean pdfMandate) {
		this.pdfMandate = pdfMandate;
	}

	public boolean isDivisionFlag() {
		return divisionFlag;
	}

	public void setDivisionFlag(boolean divisionFlag) {
		this.divisionFlag = divisionFlag;
	}

}
