package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_buyer")
public class Buyer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="buyer_id")	
	private int buyerId;
	
	@Column(name="erp_buyer_le_name")
	private String erpBuyerLeName;
	
	@Column(name="erp_ou_number")
	private String erpOuNumber;
	
	@Column(name="erp_ou_entity_name")
	private String erpOuEntityName;
	
	@Column(name="buyer_info")
	private String buyerInfo;
	
	@Column(name="buyer_location_id")
	private Long buyerLocationId;
	
	@Column(name="gold_id")
	private String goldId;
	
//	@Column(name="goldnet_name")
//	private String goldNetName;
	
	@Column(name="created", updatable=false)
	@Convert(converter = DateConverter.class)
	private String createdDate;
	
	@Column(name="created_by", updatable=false)
	private String createdBy;
	
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdatedDate;
	
	@Column(name="updated_by")
	private String updatedBy;


	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getErpBuyerLeName() {
		return erpBuyerLeName;
	}

	public void setErpBuyerLeName(String erpBuyerLeName) {
		this.erpBuyerLeName = erpBuyerLeName;
	}

	public String getErpOuNumber() {
		return erpOuNumber;
	}

	public void setErpOuNumber(String erpOuNumber) {
		this.erpOuNumber = erpOuNumber;
	}

	public String getErpOuEntityName() {
		return erpOuEntityName;
	}

	public void setErpOuEntityName(String erpOuEntityName) {
		this.erpOuEntityName = erpOuEntityName;
	}

	public String getBuyerInfo() {
		return buyerInfo;
	}

	public void setBuyerInfo(String buyerInfo) {
		this.buyerInfo = buyerInfo;
	}

	public Long getBuyerLocationId() {
		return buyerLocationId;
	}

	public void setBuyerLocationId(Long buyerLocationId) {
		this.buyerLocationId = buyerLocationId;
	}

	public String getGoldId() {
		return goldId;
	}

	public void setGoldId(String goldId) {
		this.goldId = goldId;
	}

//	public String getGoldNetName() {
//		return goldNetName;
//	}
//
//	public void setGoldNetName(String goldNetName) {
//		this.goldNetName = goldNetName;
//	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Buyer(int buyerId, String erpBuyerLeName, String erpOuNumber, String erpOuEntityName, String buyerInfo,
			Long buyerLocationId, String goldId,  String createdDate, String createdBy,
			String lastUpdatedDate, String updatedBy) {
		super();
		this.buyerId = buyerId;
		this.erpBuyerLeName = erpBuyerLeName;
		this.erpOuNumber = erpOuNumber;
		this.erpOuEntityName = erpOuEntityName;
		this.buyerInfo = buyerInfo;
		this.buyerLocationId = buyerLocationId;
		this.goldId = goldId;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.updatedBy = updatedBy;
	}

	public Buyer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
