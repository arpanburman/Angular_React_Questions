package com.ge.gcb.dto;

import java.io.Serializable;

public class BanDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9067508830572965748L;
	private long banId;
	private String vendorBan;
	private long vendorConfigId;
	private String vendorCode;
	private long serviceTypeId;
	private String serviceTypeName;
	private long buyerId;
	private String erpBuyerLeName;
	private Long liquidateBillRoutingId;
	private String locationFromCtry;
	private String locationToCtry;
	private String vendorLegalEntityName;		
	private String invoiceName;		
	private String vendorPaidBy;		
	private String liquidatedVia;	
	private String taxEngine;
	private String mode;
	private String lastUpdated;
	private String updatedBy;
	
	
	public long getBanId() {
		return banId;
	}
	public void setBanId(long banId) {
		this.banId = banId;
	}
	public String getVendorBan() {
		return vendorBan;
	}
	public void setVendorBan(String vendorBan) {
		this.vendorBan = vendorBan;
	}
	public long getVendorConfigId() {
		return vendorConfigId;
	}
	public void setVendorConfigId(long vendorConfigId) {
		this.vendorConfigId = vendorConfigId;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public long getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(long buyerId) {
		this.buyerId = buyerId;
	}
	public String getErpBuyerLeName() {
		return erpBuyerLeName;
	}
	public void setErpBuyerLeName(String erpBuyerLeName) {
		this.erpBuyerLeName = erpBuyerLeName;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public long getServiceTypeId() {
		return serviceTypeId;
	}
	public void setServiceTypeId(long serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}
	public String getServiceTypeName() {
		return serviceTypeName;
	}
	public void setServiceTypeName(String serviceTypeName) {
		this.serviceTypeName = serviceTypeName;
	}
	
	public Long getLiquidateBillRoutingId() {
		return liquidateBillRoutingId;
	}
	public void setLiquidateBillRoutingId(Long liquidateBillRoutingId) {
		this.liquidateBillRoutingId = liquidateBillRoutingId;
	}
	public BanDto(long banId, String vendorBan, long vendorConfigId, String vendorCode, String locationFromCtry, String locationToCtry,
			String vendorLegalEntityName,String invoiceName,String vendorPaidBy,String liquidatedVia,String taxEngine,long serviceTypeId,
			String serviceTypeName, long buyerId, String erpBuyerLeName, Long liquidateBillRoutingId,String mode,
			String lastUpdated, String updatedBy) {
		super();
		this.banId = banId;
		this.vendorBan = vendorBan;
		this.vendorConfigId = vendorConfigId;
		this.vendorCode = vendorCode;
		this.locationFromCtry=locationFromCtry;
		this.locationToCtry=locationToCtry;
		this.vendorLegalEntityName=vendorLegalEntityName;
		this.invoiceName=invoiceName;
		this.vendorPaidBy=vendorPaidBy;
		this.liquidatedVia=liquidatedVia;
		this.taxEngine=taxEngine;
		this.serviceTypeId = serviceTypeId;
		this.serviceTypeName = serviceTypeName;
		this.buyerId = buyerId;
		this.erpBuyerLeName = erpBuyerLeName;
		this.liquidateBillRoutingId = liquidateBillRoutingId;
		this.mode=mode;
		this.lastUpdated = lastUpdated;
		this.updatedBy = updatedBy;
	}
	public String getLocationFromCtry() {
		return locationFromCtry;
	}
	public void setLocationFromCtry(String locationFromCtry) {
		this.locationFromCtry = locationFromCtry;
	}
	public String getLocationToCtry() {
		return locationToCtry;
	}
	public void setLocationToCtry(String locationToCtry) {
		this.locationToCtry = locationToCtry;
	}
	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}
	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}
	public String getInvoiceName() {
		return invoiceName;
	}
	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}
	public String getVendorPaidBy() {
		return vendorPaidBy;
	}
	public void setVendorPaidBy(String vendorPaidBy) {
		this.vendorPaidBy = vendorPaidBy;
	}
	public String getLiquidatedVia() {
		return liquidatedVia;
	}
	public void setLiquidatedVia(String liquidatedVia) {
		this.liquidatedVia = liquidatedVia;
	}
	public String getTaxEngine() {
		return taxEngine;
	}
	public void setTaxEngine(String taxEngine) {
		this.taxEngine = taxEngine;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
}
