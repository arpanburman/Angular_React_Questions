package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BanProductDao;
import com.ge.gcb.dto.BanProductDto;
import com.ge.gcb.entities.pg.BanProductMaster;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class BanProductDaoImpl extends JpaCrudRepositoryPgImpl<BanProductMaster, Long> implements BanProductDao{

	private static final Logger logger = LogManager.getLogger(BanProductDaoImpl.class);
	
	@Override
	@Transactional
	public Map<String, Object> saveBanProduct(List<BanProductDto> banProductDataList, String banId, String sso) {
		Map<String, Object> outMap = new HashMap<>();	
		List<Object> outputList = new ArrayList<>();
		try {
			if(banProductDataList.size()>0) {
				boolean dltFlag=this.deleteBanproduct(banId);
				if(dltFlag) {
					logger.info("**insert Ban Product Dao**");
					BanProductMaster banProductMasterobj = null;
					for(BanProductDto banProductDtoObj: banProductDataList) {
						banProductMasterobj = new BanProductMaster();
						banProductMasterobj.setBanId(Integer.parseInt(banId));
						banProductMasterobj.setServiceTypeId(banProductDtoObj.getServiceTypeId());
						banProductMasterobj.setBillRoutingId(banProductDtoObj.getLiquidateBillRoutingId()!=null?banProductDtoObj.getLiquidateBillRoutingId():GcbConstants.EMPTY_STR);
						if(banProductDtoObj.isUnspscOverrideFlag()) {
							banProductMasterobj.setUnspscOverrideFlag(banProductDtoObj.isUnspscOverrideFlag());
							banProductMasterobj.setOverrideUnspsc(banProductDtoObj.getOverrideUnspsc()!=null?banProductDtoObj.getOverrideUnspsc():GcbConstants.EMPTY_STR);
						}
						if(banProductDtoObj.isErpPmtOverrideFlag()) {
							banProductMasterobj.setErpPaymentTermsOverrideFlag(banProductDtoObj.isErpPmtOverrideFlag());
							banProductMasterobj.setOverrideErpPaymentTerms(banProductDtoObj.getOverrideErpPmtTerms()!=null?banProductDtoObj.getOverrideErpPmtTerms():GcbConstants.EMPTY_STR);
						}
						if(banProductDtoObj.isCostCentreOverrideFlag()) {
							banProductMasterobj.setCostCenterOverrideFlag(banProductDtoObj.isCostCentreOverrideFlag());
							banProductMasterobj.setOverrideOffsetCostCenter(banProductDtoObj.getOverrideOffsetCostCenter()!=null?banProductDtoObj.getOverrideOffsetCostCenter():GcbConstants.EMPTY_STR);
						}
						if(null != banProductDtoObj.getQstPercent()) {
							banProductMasterobj.setQstPercent(banProductDtoObj.getQstPercent());
						}
						if(null != banProductDtoObj.getHstPercent()) {
							banProductMasterobj.setHstPercent(banProductDtoObj.getHstPercent());
						}
						if(null != banProductDtoObj.getPstPercent()) {
							banProductMasterobj.setPstPercent(banProductDtoObj.getPstPercent());
						}
						if(null != banProductDtoObj.getGstPercent()) {
							banProductMasterobj.setGstPercent(banProductDtoObj.getGstPercent());
						}
						if(null != banProductDtoObj.getVatPercent()) {
							banProductMasterobj.setVatPercent(banProductDtoObj.getVatPercent());
						}
						if(null != banProductDtoObj.getTpPercent()) {
							banProductMasterobj.setTpPercent(banProductDtoObj.getTpPercent());
						}
						if(banProductDtoObj.isErpAwtGroupNameOverrideFlag()) {
							banProductMasterobj.setErpAwtGroupNameOverrideFlag(banProductDtoObj.isErpAwtGroupNameOverrideFlag());
							banProductMasterobj.setOverrideErpAwtGroupName(banProductDtoObj.getOverrideErpAwtGroupName()!=null?banProductDtoObj.getOverrideErpAwtGroupName():GcbConstants.EMPTY_STR);
						}
						if(banProductDtoObj.isErpVatAwtGroupOverrideFlag()) {
							banProductMasterobj.setVatOverrideFlag(banProductDtoObj.isErpVatAwtGroupOverrideFlag());
							banProductMasterobj.setOverrideVatPercent(banProductDtoObj.getOverrideErpVatAwtGroupName()!=null?banProductDtoObj.getOverrideErpVatAwtGroupName():GcbConstants.EMPTY_STR);
						}
						if(banProductDtoObj.isDirectOffsetBucOverrideFlag()) {
							banProductMasterobj.setDirectOffsetBucOverrideFlag(banProductDtoObj.isDirectOffsetBucOverrideFlag());
							banProductMasterobj.setOverrideDirectOffsetBuc(banProductDtoObj.getOverrideIndirectOffsetBuc()!=null?banProductDtoObj.getOverrideIndirectOffsetBuc():GcbConstants.EMPTY_STR);
						}
						if(banProductDtoObj.isIndirectOffsetBucOverrideFlag()) {
							banProductMasterobj.setIndirectOffsetBucOverrideFlag(banProductDtoObj.isIndirectOffsetBucOverrideFlag());
							banProductMasterobj.setOverrideIndirectOffsetBuc(banProductDtoObj.getOverrideIndirectOffsetBuc()!=null?banProductDtoObj.getOverrideIndirectOffsetBuc():GcbConstants.EMPTY_STR);
						}	
						banProductMasterobj.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
						banProductMasterobj.setCreatedBy(sso!=null?sso:GcbConstants.EMPTY_STR);
						banProductMasterobj.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
						banProductMasterobj.setUpdatedBy(sso!=null?sso:GcbConstants.EMPTY_STR);
						saveNewTransaction(banProductMasterobj);
						outputList.add(banProductMasterobj.getServiceTypeId());
					}
					logger.info("List Size: ",outputList.size());
					if(outputList.size()>0) {
						outMap.put("serviceKey",outputList);
						outMap.put(GcbConstants.MESSAGE, GcbConstants.INSERT_SUCCESS);
						outMap.put(GcbConstants.ERROR, false);
					}
				}
			}
			
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put(GcbConstants.MESSAGE,GcbConstants.INSERT_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	private boolean deleteBanproduct(String banId) {
		logger.info("**Delete All ban product for**",banId);
		int count=0;
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaDelete<BanProductMaster> delete = builder.createCriteriaDelete(BanProductMaster.class);
		Root<BanProductMaster> banProductType = delete.from(BanProductMaster.class);
		try {
			delete.where(builder.and(builder.equal(banProductType.get("banId"), banId)));
			count = getEntityManager().createQuery(delete).executeUpdate();
			logger.info("**Get All Buyers count {} **",count);
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			return false;
		}
		return true;
	}

	@Override
	public List<BanProductMaster> getBanProductById(Integer banId) {
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<BanProductMaster> query = cb.createQuery(BanProductMaster.class);
		Root<BanProductMaster> root = query.from(BanProductMaster.class);
		TypedQuery<BanProductMaster> tq = null;
		query.select(root);
		try {
			query.where(cb.and(cb.equal(root.get("banId"), banId)));
			tq = getEntityManager().createQuery(query);
		}catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return tq.getResultList();
	}

	public BanProductMaster fetchTargetServiceTypeDetails(ServiceType serviceTypeObj, String banId) {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<BanProductMaster> criteriaQuery = builder.createQuery(BanProductMaster.class);
		//Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<BanProductMaster> banProductMaster = criteriaQuery.from(BanProductMaster.class);
		List<BanProductMaster> methodList = new ArrayList<>();
	try {
		final TypedQuery<BanProductMaster> query = getEntityManager()
				.createQuery(criteriaQuery.select(banProductMaster).where(
						builder.and(
						builder.equal(banProductMaster.get("serviceTypeId"), serviceTypeObj.getServiceTypeId()),
						builder.equal(banProductMaster.get("banId"), banId)
						)));

		methodList = query.getResultList();
		if (!methodList.isEmpty())
			return methodList.get(0);

	} catch (Exception e) {
		logger.error(e.getMessage());
	}
		return methodList.get(0);
	}
}
