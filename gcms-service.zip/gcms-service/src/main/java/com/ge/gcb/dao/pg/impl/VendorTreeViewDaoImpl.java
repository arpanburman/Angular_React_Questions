package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.VendorTreeViewDao;
import com.ge.gcb.entities.pg.VendorTreeView;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class VendorTreeViewDaoImpl extends  JpaCrudRepositoryPgImpl<VendorTreeView, String>  implements VendorTreeViewDao {

	public String getVendorTree() {

		List<VendorTreeView> vendorTreeData= findAll();
		if(vendorTreeData!=null) {
			return vendorTreeData.get(0).getVendorTree();
		}else
		return null;

	}

	
}
