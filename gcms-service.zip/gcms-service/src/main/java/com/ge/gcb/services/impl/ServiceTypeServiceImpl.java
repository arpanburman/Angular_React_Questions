package com.ge.gcb.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.CurrencyDao;
import com.ge.gcb.dao.pg.FocusGroupDao;
import com.ge.gcb.dao.pg.ProductDao;
import com.ge.gcb.dao.pg.ServiceTypeDao;
import com.ge.gcb.dto.OtherServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeBanDto;
import com.ge.gcb.dto.ServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeDwnData;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.entities.pg.FocusGroup;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.services.ServiceTypeService;

@Service
public class ServiceTypeServiceImpl implements ServiceTypeService {
	private static final Logger logger = LogManager.getLogger(ServiceTypeServiceImpl.class);
	
	@Autowired
	FocusGroupDao focusGroupDao;
	
	@Autowired
	CurrencyDao currencyDao;
	
	@Autowired
	ServiceTypeDao serviceTypeDao;
	
	@Autowired
	ProductDao productDao;

	@Override
	public List<Currency> getCurrencyCode() {
		return currencyDao.getCurrencyList();
	}

	@Override
	public List<FocusGroup> getFocusGroup() {
		return focusGroupDao.getFocusGroup();
	}

	@Override
	public ServiceType getServiceType(String suggestedServiceType) {
		// TODO Auto-generated method stub
		return serviceTypeDao.getServiceType(suggestedServiceType);
	}
	

	@Override
	public String insertServiceType(ServiceType serviceTypeDto,String sso) {
		return serviceTypeDao.insertServiceType(serviceTypeDto,sso);
	}

	@Override
	public String updateServiceType(ServiceType serviceTypeDto,String sso) {
		return serviceTypeDao.updateServiceType(serviceTypeDto,sso);
	}

	@Override
	public List<ServiceType> getServiceTypeData() {
		
		return serviceTypeDao.getAllServiceTypeData();
	}

	@Override
	public boolean updateUnspsc(Long productId, String unspsc,String sso) {
		return productDao.updateUnspsc(productId, unspsc,sso);
		
	}

	@Override
	public List<ServiceTypeDwnData> downloadServiceTypeData() {
		return serviceTypeDao.downloadServiceTypeData();
	}

	@Override
	public List<ServiceType> fetchServiceType(ServiceTypeBanDto serviceType) {
		return serviceTypeDao.fetchServiceType(serviceType);
	}

	@Override
	public OtherServiceTypeDto getOtherServiceType(ServiceType serviceType) {
		return serviceTypeDao.getOtherServiceType(serviceType);
	}
	
	@Override
	public List<ServiceType> fetchTargetServiceType(String banId) {
		return serviceTypeDao.getTargetServiceType(banId);
	}
	
	@Override
	public List<ServiceType> getSourceServiceType(ServiceTypeBanDto serviceType, String banId) {
		List<ServiceType> sourceList = serviceTypeDao.fetchServiceType(serviceType);
		List<ServiceType> newSourceList = new ArrayList<>();
		List<ServiceType> targetList = serviceTypeDao.getTargetServiceType(banId);
		for(ServiceType sourceType : sourceList) {
			if(!targetList.contains(sourceType)) {
				newSourceList.add(sourceType);
			}
		}
		return newSourceList;
	}
	
}
