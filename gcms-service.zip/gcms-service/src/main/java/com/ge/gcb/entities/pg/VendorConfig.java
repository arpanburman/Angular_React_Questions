package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="t_vendor_config")
public class VendorConfig {

	@Id
	@Column(name="vendor_config_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long vendorConfigId;
	
	@Column(name="vendor_entity_id")
	private long vendorEntityId;
	
	@Column(name="vendor_code")
	private String vendorCode;
	
	@Column(name="billed_from_location_id")
	private long billedFromLocationId;
	
	@Column(name="billed_to_location_id")
	private long billedToLocationId;
	
	@Column(name="currency_code")
	private String currencyCode;
	
	@Column(name="active")
	private boolean active;
	
	@Column(name="date_format")
	private String dateFormat;
	
	@Column(name="lld_coe_flag")
	private String lldCoeFlag;
	
	@Column(name="exchange_rate_type")
	private String exchangeRateType;
	
	@Column(name="vendor_contact_email")
	private String vendorContactEmail;
	
	@Column(name="payment_approval_email")
	private String paymentApprovalEmail;
	
	@Column(name="expected_feed_date")
	@Convert(converter = DateConverter2.class)
	private String expectedFeedDate;
	
	@Column(name="final_invoice_date")
	@Convert(converter = DateConverter2.class)
	private String finalInvoiceDate;
	
//	@Column(name="reporting_security_dl")
//	private String reportingSecurityDl;
//	
	@Column(name="created")
	@Convert(converter = DateConverter.class)
	private String created;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdated;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendor_entity_id",referencedColumnName="vendor_entity_id",nullable=false, insertable=false, updatable=false) 
	private Vendor vendor;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "billed_from_location_id",referencedColumnName="location_id",nullable=false, insertable=false, updatable=false) 
	private Location locationFromCtry;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "billed_to_location_id",referencedColumnName="location_id",nullable=false, insertable=false, updatable=false) 
	private Location locationToCtry;

	public long getVendorConfigId() {
		return vendorConfigId;
	}

	public void setVendorConfigId(long vendorConfigId) {
		this.vendorConfigId = vendorConfigId;
	}

	public long getVendorEntityId() {
		return vendorEntityId;
	}

	public void setVendorEntityId(long vendorEntityId) {
		this.vendorEntityId = vendorEntityId;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public long getBilledFromLocationId() {
		return billedFromLocationId;
	}

	public void setBilledFromLocationId(long billedFromLocationId) {
		this.billedFromLocationId = billedFromLocationId;
	}

	public long getBilledToLocationId() {
		return billedToLocationId;
	}

	public void setBilledToLocationId(long billedToLocationId) {
		this.billedToLocationId = billedToLocationId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}



	public String getExchangeRateType() {
		return exchangeRateType;
	}

	public void setExchangeRateType(String exchangeRateType) {
		this.exchangeRateType = exchangeRateType;
	}

	public String getVendorContactEmail() {
		return vendorContactEmail;
	}

	public void setVendorContactEmail(String vendorContactEmail) {
		this.vendorContactEmail = vendorContactEmail;
	}

	public String getExpectedFeedDate() {
		return expectedFeedDate;
	}

	public void setExpectedFeedDate(String expectedFeedDate) {
		this.expectedFeedDate = expectedFeedDate;
	}

	public String getFinalInvoiceDate() {
		return finalInvoiceDate;
	}

	public void setFinalInvoiceDate(String finalInvoiceDate) {
		this.finalInvoiceDate = finalInvoiceDate;
	}

//	public String getReportingSecurityDl() {
//		return reportingSecurityDl;
//	}
//
//	public void setReportingSecurityDl(String reportingSecurityDl) {
//		this.reportingSecurityDl = reportingSecurityDl;
//	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getLldCoeFlag() {
		return lldCoeFlag;
	}

	public void setLldCoeFlag(String lldCoeFlag) {
		this.lldCoeFlag = lldCoeFlag;
	}

	public String getPaymentApprovalEmail() {
		return paymentApprovalEmail;
	}

	public void setPaymentApprovalEmail(String paymentApprovalEmail) {
		this.paymentApprovalEmail = paymentApprovalEmail;
	}
	
	
	
}
