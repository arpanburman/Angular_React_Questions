package com.ge.gcb.dao.pg.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BuyerDao;
import com.ge.gcb.dto.BuyerDto;
import com.ge.gcb.dto.BuyerDwnDto;
import com.ge.gcb.entities.pg.Buyer;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class BuyerDaoImpl extends JpaCrudRepositoryPgImpl<Buyer, String> implements BuyerDao{
	
	private static final Logger logger = LogManager.getLogger(BuyerDaoImpl.class);

	@Override
	public List<BuyerDto> getAllBuyers() {
		logger.info("**Get All buyers**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<BuyerDto> criteriaQuery = builder.createQuery(BuyerDto.class);
		Root<Buyer> buyerType = criteriaQuery.from(Buyer.class);
		Root<Location> country = criteriaQuery.from(Location.class);
		List<BuyerDto> buyerLst = null;
		try {
			final TypedQuery<BuyerDto> query = getEntityManager()
					.createQuery(criteriaQuery.multiselect(buyerType.get("erpBuyerLeName"),buyerType.get("erpOuNumber"),
							buyerType.get("erpOuEntityName"),country.get("locationName"),buyerType.get("goldId"),
							buyerType.get("updatedBy"),buyerType.get("lastUpdatedDate"),
							buyerType.<Long>get("buyerLocationId"),buyerType.get("buyerInfo"),buyerType.<Integer>get("buyerId"))
							.where(
									builder.and(builder.equal(buyerType.<Long>get("buyerLocationId"), country.<Long>get("locationId"))))
							.orderBy(builder.asc(buyerType.get("buyerId"))));

			buyerLst = query.getResultList();
			logger.info("**Get All Buyers count {} **",buyerLst.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return buyerLst;
	}

	@Override
	public List<BuyerDwnDto> downloadBuyerData() {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<BuyerDwnDto> criteriaQuery = builder.createQuery(BuyerDwnDto.class);
		Root<Buyer> buyerType = criteriaQuery.from(Buyer.class);
		Root<Location> country = criteriaQuery.from(Location.class);
		List<BuyerDwnDto> buyerLst = null;
		try {
			final TypedQuery<BuyerDwnDto> query = getEntityManager()
					.createQuery(criteriaQuery.multiselect(buyerType.get("erpBuyerLeName"),buyerType.get("erpOuEntityName"),
							buyerType.get("erpOuNumber"),country.get("locationName"),buyerType.get("goldId"),
							buyerType.get("updatedBy"),buyerType.get("lastUpdatedDate"))
							.where(
									builder.and(builder.equal(buyerType.<Long>get("buyerLocationId"), country.<Long>get("locationId"))))
							.orderBy(builder.asc(buyerType.get("buyerId"))));

			buyerLst = query.getResultList();
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return buyerLst;
	}

	@Override
	@Transactional
	public Map<String, Object> upsertBuyer(Buyer buyer, String sso) {
		logger.info("**update Buyer Dao**");
		Map<String, Object> outMap = new HashMap<>();
		try {
			if(!GcbUtil.isEmpty(buyer.getBuyerId())) { 
				buyer.setLastUpdatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
				buyer.setUpdatedBy(sso);
			}
			else {
				buyer.setCreatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
				buyer.setLastUpdatedDate(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
				buyer.setCreatedBy(sso);
				buyer.setUpdatedBy(sso);
			}
			saveOrUpdate(buyer);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_SUCCESS);
			outMap.put(GcbConstants.ERROR, false);
			outMap.put(GcbConstants.PK_ID, buyer.getBuyerId());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
			outMap.put(GcbConstants.MESSAGE, GcbConstants.UPDATE_FAIL);
			outMap.put(GcbConstants.ERROR, true);
		}
		return outMap;
	}

	@Override
	public List<Buyer> checkBuyerExist(Buyer buyer) {
		logger.info("**Get All buyers**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<Buyer> criteriaQuery = builder.createQuery(Buyer.class);
		Root<Buyer> buyerType = criteriaQuery.from(Buyer.class);
		List<Buyer> buyerLst = null;
		try {
			final TypedQuery<Buyer> query = getEntityManager().createQuery(criteriaQuery.select(buyerType)
					.where(builder.and(builder.equal(buyerType.<Long>get("buyerLocationId"), buyer.getBuyerLocationId())),
					builder.and(builder.equal(buyerType.get("erpBuyerLeName"), buyer.getErpBuyerLeName())),
					builder.and(builder.equal(buyerType.get("erpOuEntityName"), buyer.getErpOuEntityName())),
					builder.and(builder.equal(buyerType.get("erpOuNumber"), buyer.getErpOuNumber())),
					builder.and(builder.equal(buyerType.get("goldId"), buyer.getGoldId())),
					builder.and(builder.equal(buyerType.get("buyerInfo"), buyer.getBuyerInfo()))
					));

			buyerLst = query.getResultList();
			logger.info("**Get All Buyers count {} **",buyerLst.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return buyerLst;
	}

}
