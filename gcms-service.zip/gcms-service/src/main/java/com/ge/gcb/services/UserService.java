package com.ge.gcb.services;


import com.ge.gcb.entities.pg.User;

public interface UserService {
	
	public User getUserDetails(String sso);
	
	public User saveUserDetails(User user);
	
	void updateUserStat(String sso);
	
	public boolean isUserExist(String sso);
}
