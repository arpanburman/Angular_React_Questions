package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.BuyerDto;
import com.ge.gcb.dto.BuyerDwnDto;
import com.ge.gcb.entities.pg.Buyer;
import com.ge.gcb.entities.pg.GoldNet;
import com.ge.gcb.services.BuyerService;
import com.ge.gcb.utils.GcbConstants;

import io.swagger.annotations.ApiOperation;

/**
 * @author aburman 188058
 **/


@RequestMapping("/buyer")
@RestController
public class BuyerController {
	
	private static final Logger log = LogManager.getLogger(BuyerController.class);
	
	@Autowired
	BuyerService buyerService;
	
	@Autowired
	private HttpServletRequest request;

	
	/**
	 * @author aburman
	 * @return List of Buyer
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available Buyers", response = List.class, notes="This is a list of all Buyers")
	@GetMapping("/buyer-details")
	public @ResponseBody ResponseEntity<List<BuyerDto>> getBuyerDetails() throws Exception { 
		log.info("********* Get Buyer Controller************");
		List<BuyerDto> buyerList = new ArrayList<>();
		try {
			buyerList = buyerService.getAllBuyers();
		} catch (Exception e) {
			log.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buyerList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(buyerList);
	}
	
	/**
	 * @author aburman
	 * @return particular column List of Buyer export screen
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "Download Buyers Data", response = List.class, notes="This method will Download All the available Buyes data from Table")
	@PostMapping(value ="/dwnBuyerData")
	public @ResponseBody  ResponseEntity<List<BuyerDwnDto>> downloadServiceTypeData() {

		log.info("***Controller Method getVendor Download Data invoked ***");
		List<BuyerDwnDto> serviceDataLst = null;
		serviceDataLst = buyerService.downloadBuyerData();
		if (!serviceDataLst.isEmpty())
			return ResponseEntity.status(HttpStatus.OK).body(serviceDataLst);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceDataLst);
		
	}
	
	/**
	 * @author aburman
	 * @return Save or Update Buyer after checking buyer availability
	 * @throws Exception
	 */
	@CrossOrigin
	@ApiOperation(value = "Insert and Update Buyers", response = Map.class, notes="This method will update and Insert new Buyers")
	@PostMapping("/buyers")
	public @ResponseBody ResponseEntity<Map<String, Object>> upsertBuyer(@RequestBody Buyer buyer) throws Exception { 
		log.info("********* Save or Update Buyer Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();
		Optional<Buyer> opVendor = Optional.ofNullable(buyer);
		try {
			outMap = buyerService.saveOrUpdateBuyer(opVendor.get(), sso);
			if(outMap.isEmpty()) {
				outMap.put(GcbConstants.MESSAGE, GcbConstants.DUPLICATE_EXCEPTION);
				outMap.put(GcbConstants.ERROR, true);
			}
		} catch (Exception e) {
			log.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(outMap);
		}
		return ResponseEntity.status(HttpStatus.OK).body(outMap);
	}
	

	@CrossOrigin
	@RequestMapping("/goldNet")
	public ResponseEntity<List<GoldNet>> getGoldNet()
	{
		log.info("*******VendorConfigController : getGoldNet()");
		List<GoldNet> goldNetList =new ArrayList<>();
		try {
			goldNetList=buyerService.getGoldNet();
		}catch(Exception e)
		{
			log.error("Error in getVendorConfig() : {}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(goldNetList);	
		}
		 
		return ResponseEntity.status(HttpStatus.OK).body(goldNetList);		
		}

}
