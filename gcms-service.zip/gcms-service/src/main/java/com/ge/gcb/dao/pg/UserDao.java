package com.ge.gcb.dao.pg;

import com.ge.gcb.entities.pg.User;

public interface UserDao {

	 User getUserDetails(String sso);
	
	 void saveUserDetails(User user) throws Exception;
	
}
