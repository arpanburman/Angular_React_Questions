package com.ge.gcb.dto;

public class VendorConfigDto {

	private long vendorConfigId;
	private long vendorEntityId;
	private String vendorLegalEntityName;
	private String vendorCode;
	private String billedFromCountry;
	private String billedToCountry;
	private String currencyCode;
	
	public long getVendorConfigId() {
		return vendorConfigId;
	}
	public void setVendorConfigId(long vendorConfigId) {
		this.vendorConfigId = vendorConfigId;
	}
	public long getVendorEntityId() {
		return vendorEntityId;
	}
	public void setVendorEntityId(long vendorEntityId) {
		this.vendorEntityId = vendorEntityId;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getBilledFromCountry() {
		return billedFromCountry;
	}
	public void setBilledFromCountry(String billedFromCountry) {
		this.billedFromCountry = billedFromCountry;
	}
	public String getBilledToCountry() {
		return billedToCountry;
	}
	public void setBilledToCountry(String billedToCountry) {
		this.billedToCountry = billedToCountry;
	}
	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}
	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}
	
	public VendorConfigDto(long vendorConfigId, long vendorEntityId, String vendorLegalEntityName, String vendorCode,
			String billedFromCountry, String billedToCountry, String currencyCode) {
		super();
		this.vendorConfigId = vendorConfigId;
		this.vendorEntityId = vendorEntityId;
		this.vendorLegalEntityName=vendorLegalEntityName;
		this.vendorCode = vendorCode;
		this.billedFromCountry = billedFromCountry;
		this.billedToCountry = billedToCountry;
		this.currencyCode = currencyCode;
	}
	
	public VendorConfigDto(long vendorConfigId, long vendorEntityId, String vendorCode,String currencyCode) {
		super();
		this.vendorConfigId = vendorConfigId;
		this.vendorEntityId = vendorEntityId;
		this.vendorCode = vendorCode;
		this.currencyCode = currencyCode;
	}
	
	public VendorConfigDto() {
		super();
	}

}
