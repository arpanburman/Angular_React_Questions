package com.ge.gcb.dto;

import java.util.Date;

public class ServiceTypeDto {

	private String productNm;
	private String serviceTypeMessage;
	private String suggestedServiceType;

	
	private String billedFromLocation;
	
	private String billedToLocation;	
	private String serviceTypeName;
	
	private String processName;
		
	private String billingBasis;
	private String legacyServiceTypeName;
	
	private String created;
	
	private String createdBy;
	
	private String lastUpdated;
	
	private String updatedBy;


	public String getProductNm() {
		return productNm;
	}
	public void setProductNm(String productNm) {
		this.productNm = productNm;
	}
	public String getServiceTypeMessage() {
		return serviceTypeMessage;
	}
	public void setServiceTypeMessage(String serviceTypeMessage) {
		this.serviceTypeMessage = serviceTypeMessage;
	}
	public String getSuggestedServiceType() {
		return suggestedServiceType;
	}
	public void setSuggestedServiceType(String suggestedServiceType) {
		this.suggestedServiceType = suggestedServiceType;
	}
	public String getBilledFromLocation() {
		return billedFromLocation;
	}
	public void setBilledFromLocation(String billedFromLocation) {
		this.billedFromLocation = billedFromLocation;
	}
	public String getBilledToLocation() {
		return billedToLocation;
	}
	public void setBilledToLocation(String billedToLocation) {
		this.billedToLocation = billedToLocation;
	}
	public String getServiceTypeName() {
		return serviceTypeName;
	}
	public void setServiceTypeName(String serviceTypeName) {
		this.serviceTypeName = serviceTypeName;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getBillingBasis() {
		return billingBasis;
	}
	public void setBillingBasis(String billingBasis) {
		this.billingBasis = billingBasis;
	}
	
	public String getLegacyServiceTypeName() {
		return legacyServiceTypeName;
	}
	public void setLegacyServiceTypeName(String legacyServiceTypeName) {
		this.legacyServiceTypeName = legacyServiceTypeName;
	}
	
	
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public ServiceTypeDto() {
		super();
	}
	public ServiceTypeDto( String productNm,
			String billedFromLocation, String billedToLocation, String serviceTypeName,String processName,
			 String legacyServiceTypeName, String billingBasis, String createdBy,String created, String updatedBy, String lastUpdated) {
		super();

		this.productNm = productNm;
		this.billedFromLocation = billedFromLocation;
		this.billedToLocation = billedToLocation;
		this.serviceTypeName = serviceTypeName;
		this.processName=processName;
		this.billingBasis = billingBasis;
		this.legacyServiceTypeName=legacyServiceTypeName;
		this.created = created;
		this.createdBy = createdBy;
		this.lastUpdated = lastUpdated;
		this.updatedBy = updatedBy;
	}
	
}
