package com.ge.gcb.services;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.BuyerDto;
import com.ge.gcb.dto.BuyerDwnDto;
import com.ge.gcb.entities.pg.Buyer;
import com.ge.gcb.entities.pg.GoldNet;

public interface BuyerService {

	List<BuyerDto> getAllBuyers();

	List<BuyerDwnDto> downloadBuyerData();

	Map<String, Object> saveOrUpdateBuyer(Buyer buyer, String sso);

	List<GoldNet> getGoldNet();

}
