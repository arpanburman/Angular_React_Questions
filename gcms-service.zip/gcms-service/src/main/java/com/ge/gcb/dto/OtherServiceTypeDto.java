package com.ge.gcb.dto;

public class OtherServiceTypeDto {
	private int productId;
	private long serviceTypeId;
	private String costCenter;
	private String unspsc;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public long getServiceTypeId() {
		return serviceTypeId;
	}
	public void setServiceTypeId(long serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getUnspsc() {
		return unspsc;
	}
	public void setUnspsc(String unspsc) {
		this.unspsc = unspsc;
	}
	public OtherServiceTypeDto(int productId, long serviceTypeId, String costCenter, String unspsc) {
		super();
		this.productId = productId;
		this.serviceTypeId = serviceTypeId;
		this.costCenter = costCenter;
		this.unspsc = unspsc;
	}

	
}
