package com.ge.gcb.dao.pg;

public interface LocationTreeViewDao {

	String getLocation();

}
