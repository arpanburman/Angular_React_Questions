package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.UserStatDao;
import com.ge.gcb.entities.pg.UserStat;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class UserStatDaoImpl extends JpaCrudRepositoryPgImpl<UserStat, String> implements UserStatDao {
	private static final Logger logger = LogManager.getLogger(UserStatDaoImpl.class);

	@Override
	public UserStat checkUserEntry(String sso) {

		return findById(sso);
	}

	@Override
	public int updateUserData(int noOfLogin, String sso) {

		int updateCount =0;	
		try {
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaUpdate<UserStat> update = cb.createCriteriaUpdate(UserStat.class);
		Root<UserStat> e = update.from(UserStat.class);
		List<Predicate> criteria = new ArrayList<Predicate>();
		update.set("lastLogin", new Date());
		update.set("numberOfLogins", noOfLogin);
		criteria.add(cb.equal(e.get("sso"), sso));
		if (criteria.size() != 0)
			update.where(cb.and(criteria.toArray(new Predicate[0])));
		    updateCount = getEntityManager().createQuery(update).executeUpdate();
		}
		catch(Exception e){
			logger.info("updateUserData Method : Error in updating UserStat : Error " , e.getMessage());
			updateCount=0;
   		}
        return updateCount;
	}

	@Override
	public void insertUserData(String sso) {

		logger.info("INSIDE GCB inserUserData Method :");
		try {
			UserStat user = new UserStat();
			user.setSso(sso);
			user.setLastLogin(new Date());
			user.setNumberOfLogins(1);
			save(user);
		} catch (Exception e) {
			logger.info("insertUserData Method : Error in creating UserStat Entry: Error " , e.getMessage());
		}
	}

	
	
	
}
