package com.ge.gcb.services;

import java.util.List;
import java.util.Map;

import org.springframework.cache.annotation.Cacheable;

import com.ge.gcb.dto.BanDto;
import com.ge.gcb.dto.BanDwnDto;
import com.ge.gcb.dto.BanProductDto;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.BillingModel;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.exception.GcbException;

public interface BanService {

	List<BanDto> getAllBans();

	List<BanDwnDto> downloadBanData();

	List<Ban> getBans();

	List<BillingModel> getBillingModel();

	Map<String, Object> saveOrUpdateBan(Ban banData, String sso);

	Ban getBanById(String banId);

	Map<String, Object> upsertBanProductMaster(List<BanProductDto> banProductDataList, String banId, String sso);

	List<BanProductDto> getBanProductById(Integer banId) throws GcbException;

	BanProductDto fetchTargetServiceTypeDetails(ServiceType serviceTypeList, String banId) throws GcbException;
	Map getBillingModelTypes();

	Map getCloneBillingModelTypes(String banId);

	Ban getProdMode(Ban banData);

}
