package com.ge.gcb.dao.pg.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.CurrencyDao;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
@Repository
public class CurrencyDaoImpl  extends JpaCrudRepositoryPgImpl<Currency, String> implements CurrencyDao {
	
	private static final Logger logger = LogManager.getLogger(CurrencyDaoImpl.class);

	/* (non-Javadoc)
	 * @see com.ge.gcb.dao.pg.CurrencyDao#getCurrencyList()
	 */
	@Override
	public List<Currency> getCurrencyList() {
		return findAll();
	}

	
	
}
