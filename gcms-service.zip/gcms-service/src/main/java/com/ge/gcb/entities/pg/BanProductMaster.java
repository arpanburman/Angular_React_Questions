package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_ban_product_master")
public class BanProductMaster {

	@Id	
	@Column(name="ban_id")
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int banId;
	
	@Column(name="service_type_id")
	private Integer serviceTypeId;
	
	@Column(name="bill_routing_id")
	private String billRoutingId;
	
	@Column(name="erp_payment_terms_override_flag")
	private Boolean erpPaymentTermsOverrideFlag;
	
	@Column(name="override_erp_payment_terms")
	private String overrideErpPaymentTerms;
	
	@Column(name="unspsc_override_flag")
	private Boolean unspscOverrideFlag;
	
	@Column(name="override_unspsc")
	private String overrideUnspsc;
	
	@Column(name="cost_center_override_flag")
	private Boolean costCenterOverrideFlag;	
	
	@Column(name="override_offset_cost_center")
	private String overrideOffsetCostCenter;
	
	@Column(name="qst_percent")
	private Integer qstPercent;

	@Column(name="hst_percent")
	private Integer hstPercent;

	@Column(name="pst_percent")
	private Integer pstPercent;

	@Column(name="gst_percent")
	private Integer gstPercent;
	
	@Column(name="vat_percent")
	private Integer vatPercent;

	@Column(name="tp_percent")
	private Integer tpPercent;
	
	@Column(name="erp_awt_group_name_override_flag")
	private Boolean erpAwtGroupNameOverrideFlag;
	
	@Column(name="override_erp_awt_group_name")
	private String overrideErpAwtGroupName;
	
	@Column(name="erp_vat_awt_group_name_override_flag")
	private Boolean vatOverrideFlag;
	
	@Column(name="override_erp_vat_awt_group_name")
	private String overrideVatPercent;
	
	@Column(name="direct_offset_buc_override_flag")
	private Boolean directOffsetBucOverrideFlag;
	
	@Column(name="override_direct_offset_buc")
	private String overrideDirectOffsetBuc;
	
	@Column(name="indirect_offset_buc_override_flag")
	private Boolean indirectOffsetBucOverrideFlag;
	
	@Column(name="override_indirect_offset_buc")
	private String overrideIndirectOffsetBuc;
	/*
	@Column(name="vat_override_flag")
	private boolean vatOverrideFlag;
	
	@Column(name="override_vat_percent")
	private int overrideVatPercent;
	
	@Column(name="wht_override_flag")
	private boolean whtOverrideFlag;
	
	@Column(name="override_wht_percent")
	private int overrideWhtPercent;
	
	@Column(name="tp_override_flag")
	private boolean tpOverrideFlag;
	
	@Column(name="override_tp_percent")
	private int overrideTpPercent;	*/
	
	@Column(name="created")
	@Convert(converter = DateConverter.class)
	private String created;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdated;
	
	@Column(name="updated_by")
	private String updatedBy;

	public int getBanId() {
		return banId;
	}

	public void setBanId(int banId) {
		this.banId = banId;
	}

	public Integer getServiceTypeId() {
		return serviceTypeId;
	}

	public void setServiceTypeId(Integer serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}

	public String getBillRoutingId() {
		return billRoutingId;
	}

	public void setBillRoutingId(String billRoutingId) {
		this.billRoutingId = billRoutingId;
	}

	public Boolean getErpPaymentTermsOverrideFlag() {
		return erpPaymentTermsOverrideFlag;
	}

	public void setErpPaymentTermsOverrideFlag(Boolean erpPaymentTermsOverrideFlag) {
		this.erpPaymentTermsOverrideFlag = erpPaymentTermsOverrideFlag;
	}

	public String getOverrideErpPaymentTerms() {
		return overrideErpPaymentTerms;
	}

	public void setOverrideErpPaymentTerms(String overrideErpPaymentTerms) {
		this.overrideErpPaymentTerms = overrideErpPaymentTerms;
	}

	public Boolean getUnspscOverrideFlag() {
		return unspscOverrideFlag;
	}

	public void setUnspscOverrideFlag(Boolean unspscOverrideFlag) {
		this.unspscOverrideFlag = unspscOverrideFlag;
	}

	public String getOverrideUnspsc() {
		return overrideUnspsc;
	}

	public void setOverrideUnspsc(String overrideUnspsc) {
		this.overrideUnspsc = overrideUnspsc;
	}

	public Boolean getCostCenterOverrideFlag() {
		return costCenterOverrideFlag;
	}

	public void setCostCenterOverrideFlag(Boolean costCenterOverrideFlag) {
		this.costCenterOverrideFlag = costCenterOverrideFlag;
	}

	public String getOverrideOffsetCostCenter() {
		return overrideOffsetCostCenter;
	}

	public void setOverrideOffsetCostCenter(String overrideOffsetCostCenter) {
		this.overrideOffsetCostCenter = overrideOffsetCostCenter;
	}

	public Integer getQstPercent() {
		return qstPercent;
	}

	public void setQstPercent(Integer qstPercent) {
		this.qstPercent = qstPercent;
	}

	public Integer getHstPercent() {
		return hstPercent;
	}

	public void setHstPercent(Integer hstPercent) {
		this.hstPercent = hstPercent;
	}

	public Integer getPstPercent() {
		return pstPercent;
	}

	public void setPstPercent(Integer pstPercent) {
		this.pstPercent = pstPercent;
	}

	public Integer getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(Integer gstPercent) {
		this.gstPercent = gstPercent;
	}

	public Integer getVatPercent() {
		return vatPercent;
	}

	public void setVatPercent(Integer vatPercent) {
		this.vatPercent = vatPercent;
	}

	public Integer getTpPercent() {
		return tpPercent;
	}

	public void setTpPercent(Integer tpPercent) {
		this.tpPercent = tpPercent;
	}

	public Boolean getErpAwtGroupNameOverrideFlag() {
		return erpAwtGroupNameOverrideFlag;
	}

	public void setErpAwtGroupNameOverrideFlag(Boolean erpAwtGroupNameOverrideFlag) {
		this.erpAwtGroupNameOverrideFlag = erpAwtGroupNameOverrideFlag;
	}

	public String getOverrideErpAwtGroupName() {
		return overrideErpAwtGroupName;
	}

	public void setOverrideErpAwtGroupName(String overrideErpAwtGroupName) {
		this.overrideErpAwtGroupName = overrideErpAwtGroupName;
	}

	public Boolean getVatOverrideFlag() {
		return vatOverrideFlag;
	}

	public void setVatOverrideFlag(Boolean vatOverrideFlag) {
		this.vatOverrideFlag = vatOverrideFlag;
	}

	public String getOverrideVatPercent() {
		return overrideVatPercent;
	}

	public void setOverrideVatPercent(String overrideVatPercent) {
		this.overrideVatPercent = overrideVatPercent;
	}

	public Boolean getDirectOffsetBucOverrideFlag() {
		return directOffsetBucOverrideFlag;
	}

	public void setDirectOffsetBucOverrideFlag(Boolean directOffsetBucOverrideFlag) {
		this.directOffsetBucOverrideFlag = directOffsetBucOverrideFlag;
	}

	public String getOverrideDirectOffsetBuc() {
		return overrideDirectOffsetBuc;
	}

	public void setOverrideDirectOffsetBuc(String overrideDirectOffsetBuc) {
		this.overrideDirectOffsetBuc = overrideDirectOffsetBuc;
	}

	public Boolean getIndirectOffsetBucOverrideFlag() {
		return indirectOffsetBucOverrideFlag;
	}

	public void setIndirectOffsetBucOverrideFlag(Boolean indirectOffsetBucOverrideFlag) {
		this.indirectOffsetBucOverrideFlag = indirectOffsetBucOverrideFlag;
	}

	public String getOverrideIndirectOffsetBuc() {
		return overrideIndirectOffsetBuc;
	}

	public void setOverrideIndirectOffsetBuc(String overrideIndirectOffsetBuc) {
		this.overrideIndirectOffsetBuc = overrideIndirectOffsetBuc;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	
	
}