package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.HlVendorDao;
import com.ge.gcb.entities.pg.HlVendor;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class HlVendorDaoImpl extends JpaCrudRepositoryPgImpl<HlVendor, String> implements HlVendorDao {

	private static final Logger logger = LogManager.getLogger(VendorDaoImpl.class);
	
	@Override
	public List<HlVendor> getAllHlVendors() {
		logger.info("**Get All HL vendors**");
		List<HlVendor> vendorHlList = null;
		try {
			vendorHlList = new ArrayList<>();
			vendorHlList = findAll();
			logger.info("**Get All vendors count {} **",vendorHlList.size());
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return vendorHlList;
	}

}
