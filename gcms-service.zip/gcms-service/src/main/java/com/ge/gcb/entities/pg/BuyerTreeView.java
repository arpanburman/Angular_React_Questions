package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="v_buyer_tree_view")
public class BuyerTreeView {

	@Id
	@Column(name="buyer")
	private String buyerTree;

	public String getBuyerTree() {
		return buyerTree;
	}

	public void setBuyerTree(String buyerTree) {
		this.buyerTree = buyerTree;
	}
	
}
