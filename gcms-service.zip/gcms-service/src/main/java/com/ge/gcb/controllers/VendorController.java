	package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.VendorDto;
import com.ge.gcb.entities.pg.HlVendor;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.exception.GcbException;
import com.ge.gcb.services.VendorService;
import com.ge.gcb.utils.GcbConstants;

import io.swagger.annotations.ApiOperation;

/**
 * @author aburman 188058
 **/


@RequestMapping("/vendor")
@RestController
public class VendorController {
	
	private static final Logger LOG = LogManager.getLogger(VendorController.class);
	
	@Autowired
	VendorService vendorService;

	@Autowired
	private HttpServletRequest request;
	/**
	 * @author aburman
	 * @return List of Vendors
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available Vendors", response = List.class, notes="This is a list of all vendors")
	@GetMapping("/vendor-details")
	public @ResponseBody ResponseEntity<List<VendorDto>> getVendorDetails() throws Exception { 
		LOG.info("********* Get Vendor Controller************");
		List<VendorDto> vendorList = new ArrayList<>();
		try {
			vendorList = vendorService.getAllVendors();
			if(vendorList.isEmpty()) {
				throw new GcbException(GcbConstants.EMPTY_RECORDS);
			}
		} catch (Exception e) {
			LOG.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(vendorList);
	}
	
	/**
	 * @author aburman
	 * @return Save or Update Vendor after checking vendor availability
	 * @throws Exception
	 */
	@CrossOrigin
	@ApiOperation(value = "Insert and Update Vendors", response = Map.class, notes="This method will update and Insert new Vendors")
	@PostMapping("/vendors")
	public @ResponseBody ResponseEntity<Map<String, Object>> upsertVendor(@RequestBody Vendor vendor) throws Exception { 
		LOG.info("********* Save or Update Vendor Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();
		Optional<Vendor> opVendor = Optional.ofNullable(vendor);
		try {
			outMap = vendorService.saveOrUpdateVendor(opVendor.get(), sso);
			if(outMap.isEmpty()) {
				outMap.put(GcbConstants.MESSAGE, GcbConstants.DUPLICATE_EXCEPTION);
				outMap.put(GcbConstants.ERROR, true);
			}
		} catch (Exception e) {
			LOG.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(outMap);
		}
		return ResponseEntity.status(HttpStatus.OK).body(outMap);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Download Vendors Data", response = List.class, notes="This method will Download All the available Vendors data from Table")
	@PostMapping(value ="/dwnVendorData")
	public @ResponseBody  ResponseEntity<List<VendorDto>> downloadServiceTypeData() {

		LOG.info("***Controller Method getVendor Download Data invoked ***");
		List<VendorDto> serviceDataLst = null;
		serviceDataLst = vendorService.downloadVendorData();
		if (!serviceDataLst.isEmpty())
			return ResponseEntity.status(HttpStatus.OK).body(serviceDataLst);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceDataLst);
		
	}

	/**
	 * @author aburman
	 * @return List of HL Vendors
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available HL Vendors", response = List.class, notes="This is a list of all HL vendors Name")
	@GetMapping("/hlvendor-details")
	public @ResponseBody ResponseEntity<List<HlVendor>> getHlVendorDetails() throws Exception { 
		LOG.info("********* Get Vendor Controller************");
		List<HlVendor> vendorHlList = new ArrayList<>();
		try {
			vendorHlList = vendorService.getAllHlVendors();
			if(vendorHlList.isEmpty()) {
				throw new GcbException(GcbConstants.EMPTY_RECORDS);
			}
		} catch (Exception e) {
			LOG.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorHlList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(vendorHlList);
	}
	
	@CrossOrigin
	@ApiOperation(value = "View a list of Vendors Names", response = List.class, notes="This is a list of all vendors")
	@GetMapping("/vendor-names")
	public @ResponseBody ResponseEntity<List<VendorDto>> getVendorNames() throws Exception { 
		LOG.info("*********  getVendorNames Controller************");
		List<VendorDto> vendorList = new ArrayList<>();
		try {
			vendorList = vendorService.AllVendorNames();
			if(vendorList.isEmpty()) {
				throw new GcbException(GcbConstants.EMPTY_RECORDS);
			}
		} catch (Exception e) {
			LOG.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(vendorList);
	}
}
