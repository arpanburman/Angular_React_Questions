package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ge.gcb.utils.GcbUtil;

@Converter
public class DateConverter implements AttributeConverter<String, Date> {


@Override
public Date convertToDatabaseColumn(String attribute) {
	 return new Date(attribute);
}

@Override
public String convertToEntityAttribute(Date dbData) {
	  StringBuilder sb =  new  StringBuilder(GcbUtil.convertDateToStringMMDDYYYY(dbData));
	  return sb.toString();
}

}