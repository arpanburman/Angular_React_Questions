package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.CountryDto;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.services.ChargeBackService;
import com.ge.gcb.services.CurrencyService;
import com.ge.gcb.services.LocationService;

@RestController
public class ChargebackController {

	private static final Logger LOG = LogManager.getLogger(ChargebackController.class);

	@Autowired
	LocationService locationService;

	@Autowired
	CurrencyService currencyService;
	
	@Autowired
	ChargeBackService chargeBackService;

	@CrossOrigin
	@RequestMapping("/country")
	public @ResponseBody ResponseEntity<List<CountryDto>> getCountry() throws Exception { 
		List<CountryDto> countryDtoList = new ArrayList<>();
		LOG.info("***Controller ChargebackController : getCountry ***");
		try {
			countryDtoList=locationService.getCountry();
		} catch (Exception e) {
			LOG.error("Error in getCountry : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(countryDtoList);
		}
       return ResponseEntity.status(HttpStatus.OK).body(countryDtoList);
	}

	@CrossOrigin
	@RequestMapping("/currency")
	public @ResponseBody ResponseEntity<List<Currency>> getCurrency() throws Exception { 
		List<Currency> currencyList = new ArrayList<>();
		LOG.info("***Controller ChargebackController : getCurrency ***");
		try {
			currencyList=currencyService.getCurrencyList();
		} catch (Exception e) {
			LOG.error("Error in getCountry : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(currencyList);
		}
       return ResponseEntity.status(HttpStatus.OK).body(currencyList);
	}
	
	@CrossOrigin
	@RequestMapping("/productTree")
	public @ResponseBody ResponseEntity<String> getBillProcessTree() throws Exception {
		String billProcessJson = "";
		LOG.info("***Controller Method getBillProcessTree invoked ***");
		try {
			billProcessJson = chargeBackService.getBillProcessTree();
		} catch (Exception e) {
			LOG.error("Error in getBillProcessTree : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(billProcessJson);
		}
		return ResponseEntity.status(HttpStatus.OK).body(billProcessJson);
	}

	@CrossOrigin
	@RequestMapping(value = "/locationTree")
	public @ResponseBody ResponseEntity<String> getLocationTree() throws Exception {
		String locationJson = "";
		LOG.info("***Controller Method getLocationTree invoked ***");
		try {
			locationJson = chargeBackService.getLocationTree();
		} catch (Exception e) {
			LOG.error("Error in getBillProcessTree : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(locationJson);
		}
		return ResponseEntity.status(HttpStatus.OK).body(locationJson);
	}

	@CrossOrigin
	@RequestMapping(value = "/vendorTree")
	public @ResponseBody ResponseEntity<String> getVendorTree() throws Exception {
		String vendorJson = "";
		LOG.info("***Controller Method getVendorTree invoked ***");
		try {
			vendorJson = chargeBackService.getVendorTree();
		} catch (Exception e) {
			LOG.error("Error in getVendorTree : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vendorJson);
		}
		return ResponseEntity.status(HttpStatus.OK).body(vendorJson);
	}

	@CrossOrigin
	@RequestMapping(value = "/buyerTree")
	public @ResponseBody ResponseEntity<String> getBuyerTree() throws Exception {
		String buyerJson = "";
		LOG.info("***Controller Method getBuyerTree invoked ***");
		try {
			buyerJson = chargeBackService.getBuyerTree();
		} catch (Exception e) {
			LOG.error("Error in getBuyerTree : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buyerJson);
		}
		return ResponseEntity.status(HttpStatus.OK).body(buyerJson);

	}
}
