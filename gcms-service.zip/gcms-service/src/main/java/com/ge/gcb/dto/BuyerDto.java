package com.ge.gcb.dto;

public class BuyerDto {
	
	private String erpBuyerLeName;
	private String erpOuNumber;
	private String erpOuEntityName;
	private String locationName;
	private String goldId;
	private String updatedBy;
	private String lastUpdatedDate;
	private String goldNetName;
	private Long buyerLocationId;
	private String buyerInfo;
	private int buyerId;
	public String getErpBuyerLeName() {
		return erpBuyerLeName;
	}
	public void setErpBuyerLeName(String erpBuyerLeName) {
		this.erpBuyerLeName = erpBuyerLeName;
	}
	public String getErpOuNumber() {
		return erpOuNumber;
	}
	public void setErpOuNumber(String erpOuNumber) {
		this.erpOuNumber = erpOuNumber;
	}
	public String getErpOuEntityName() {
		return erpOuEntityName;
	}
	public void setErpOuEntityName(String erpOuEntityName) {
		this.erpOuEntityName = erpOuEntityName;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getGoldId() {
		return goldId;
	}
	public void setGoldId(String goldId) {
		this.goldId = goldId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getGoldNetName() {
		return goldNetName;
	}
	public void setGoldNetName(String goldNetName) {
		this.goldNetName = goldNetName;
	}
	public Long getBuyerLocationId() {
		return buyerLocationId;
	}
	public void setBuyerLocationId(Long buyerLocationId) {
		this.buyerLocationId = buyerLocationId;
	}
	public String getBuyerInfo() {
		return buyerInfo;
	}
	public void setBuyerInfo(String buyerInfo) {
		this.buyerInfo = buyerInfo;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public BuyerDto(String erpBuyerLeName, String erpOuNumber, String erpOuEntityName, String locationName,
			String goldId, String updatedBy, String lastUpdatedDate,  Long buyerLocationId,
			String buyerInfo, int buyerId) {
		super();
		this.erpBuyerLeName = erpBuyerLeName;
		this.erpOuNumber = erpOuNumber;
		this.erpOuEntityName = erpOuEntityName;
		this.locationName = locationName;
		this.goldId = goldId;
		this.updatedBy = updatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.buyerLocationId = buyerLocationId;
		this.buyerInfo = buyerInfo;
		this.buyerId = buyerId;
	}

	
}
