package com.ge.gcb.dao.pg;

import java.util.List;
import java.util.Map;

import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;

import com.ge.gcb.dto.BanDto;
import com.ge.gcb.dto.BanDwnDto;
import com.ge.gcb.entities.pg.Ban;

@Profile("hazelcast-cache")
public interface BanDao {

	@Cacheable("banDetails")
	List<BanDto> getAllBans();

	List<BanDwnDto> downloadBanData();

	List<Ban> getBans();

	@CachePut(value="banDetails")
	Map<String, Object> updateBan(Ban banData, String sso);

	@CachePut(value="banDetails")
	Map<String, Object> saveBan(Ban banData, String sso);

	Ban getBanById(String banId);

	Ban getBanRecord(Ban banData);
	
	Ban getProdMode(Ban banData);

}
