package com.ge.gcb.dao.pg;

import java.util.List;

import com.ge.gcb.entities.pg.FocusGroup;

public interface FocusGroupDao {

	/**
	 * @return
	 */
	List<FocusGroup> getFocusGroup();	
	
}
