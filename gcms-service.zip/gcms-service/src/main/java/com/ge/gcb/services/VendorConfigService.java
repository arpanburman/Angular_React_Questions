package com.ge.gcb.services;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.VendorConfigDetailsDto;
import com.ge.gcb.dto.VendorConfigDownloadDto;
import com.ge.gcb.dto.VendorConfigDto;

public interface VendorConfigService {

	public List<VendorConfigDto> getVendorConfig();
	
	public List<VendorConfigDetailsDto>  getVendorConfigDetails();
	
	public Map<String, Object> upsertVendorConfig(VendorConfigDetailsDto vendorConfigDetailsDto,String sso);

	public List<VendorConfigDownloadDto> getDwnVendorConfig();
	
	
}
