package com.ge.gcb.dao.pg;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.BuyerDto;
import com.ge.gcb.dto.BuyerDwnDto;
import com.ge.gcb.entities.pg.Buyer;

public interface BuyerDao {

	List<BuyerDto> getAllBuyers();

	List<BuyerDwnDto> downloadBuyerData();

	Map<String, Object> upsertBuyer(Buyer buyer, String sso);

	List<Buyer> checkBuyerExist(Buyer buyer);

}
