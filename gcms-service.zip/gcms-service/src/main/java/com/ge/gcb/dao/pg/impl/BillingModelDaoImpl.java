package com.ge.gcb.dao.pg.impl;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BillingModelDao;
import com.ge.gcb.entities.pg.BillingModel;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class BillingModelDaoImpl extends JpaCrudRepositoryPgImpl<BillingModel, String> implements BillingModelDao{

	/* (non-Javadoc)
	 * @see com.ge.gcb.dao.pg.BillingModelDao#getBillingModel()
	 */
	@Autowired
	private Environment env;
	
	@Override
	public List<BillingModel> getBillingModel() {
		return findAll();
	}

	@Override
	public List<BillingModel> getCloneBillingModel(Long cbId) {
		try {
			String schema_name = env.getProperty("spring.datasource.gcb.schema");
		      
			StoredProcedureQuery query = getEntityManager()
				    .createStoredProcedureQuery(schema_name+".billingModel",BillingModel.class)
				    .registerStoredProcedureParameter(1, 
					        Integer.class, ParameterMode.IN)
				    .setParameter(1, cbId.intValue());
				List<BillingModel> list=(List<BillingModel>) query.getResultList();
			return list;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
	
}
