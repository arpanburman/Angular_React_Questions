package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_billing_model_types")
public class BillingModelType {
	
	@Id
	@Column(name="id")
	private long billingTypeId;
	
	@Column(name="billing_model_description")
	private String billingModelDesc;

	@Column(name="billing_model_type")
	private String billingType;

	public long getBillingTypeId() {
		return billingTypeId;
	}

	public void setBillingTypeId(long billingTypeId) {
		this.billingTypeId = billingTypeId;
	}

	public String getBillingModelDesc() {
		return billingModelDesc;
	}

	public void setBillingModelDesc(String billingModelDesc) {
		this.billingModelDesc = billingModelDesc;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

}
