package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ge.gcb.utils.GcbUtil;

@Converter
public class DateConverter2 implements AttributeConverter<String, Date> {


@Override
public Date convertToDatabaseColumn(String attribute) {
	java.util.Date date;
	 if(GcbUtil.isEmpty(attribute))
	 {  date =null;
		 return date;}
	 else
	 { return new Date(attribute); }
}

@Override
public String convertToEntityAttribute(Date dbData) {
	if(dbData!=null)
	{ StringBuilder sb =  new  StringBuilder(GcbUtil.convertDateToStringNoTimeStamp(dbData));
	  return sb.toString();
	}
	else
	{
		return null;
	}
}

}
