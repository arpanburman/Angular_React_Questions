package com.ge.gcb.dto;

public class BanProductDto {
	private long banId;
	private int serviceTypeId;
	private String overrideErpPmtTerms;
	private String overrideErpAwtGroupName;
	private String overrideDirectOffsetBuc;
	private String overrideIndirectOffsetBuc;
	private String overrideErpVatAwtGroupName;
	private String overrideUnspsc;
	private String overrideOffsetCostCenter;
	private boolean unspscOverrideFlag;
	private boolean costCentreOverrideFlag;
	private boolean erpPmtOverrideFlag;
	private boolean erpAwtGroupNameOverrideFlag;
	private boolean erpVatAwtGroupOverrideFlag;
	private boolean directOffsetBucOverrideFlag;
	private boolean indirectOffsetBucOverrideFlag;
	private Integer qstPercent;
	private Integer hstPercent;
	private Integer pstPercent;
	private Integer gstPercent;
	private Integer vatPercent;
	private Integer tpPercent;
	private String liquidateBillRoutingId;
	public long getBanId() {
		return banId;
	}
	public void setBanId(long banId) {
		this.banId = banId;
	}
	public int getServiceTypeId() {
		return serviceTypeId;
	}
	public void setServiceTypeId(int serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}
	public String getOverrideErpPmtTerms() {
		return overrideErpPmtTerms;
	}
	public void setOverrideErpPmtTerms(String overrideErpPmtTerms) {
		this.overrideErpPmtTerms = overrideErpPmtTerms;
	}
	public String getOverrideErpAwtGroupName() {
		return overrideErpAwtGroupName;
	}
	public void setOverrideErpAwtGroupName(String overrideErpAwtGroupName) {
		this.overrideErpAwtGroupName = overrideErpAwtGroupName;
	}
	public String getOverrideDirectOffsetBuc() {
		return overrideDirectOffsetBuc;
	}
	public void setOverrideDirectOffsetBuc(String overrideDirectOffsetBuc) {
		this.overrideDirectOffsetBuc = overrideDirectOffsetBuc;
	}
	public String getOverrideIndirectOffsetBuc() {
		return overrideIndirectOffsetBuc;
	}
	public void setOverrideIndirectOffsetBuc(String overrideIndirectOffsetBuc) {
		this.overrideIndirectOffsetBuc = overrideIndirectOffsetBuc;
	}
	public String getOverrideErpVatAwtGroupName() {
		return overrideErpVatAwtGroupName;
	}
	public void setOverrideErpVatAwtGroupName(String overrideErpVatAwtGroupName) {
		this.overrideErpVatAwtGroupName = overrideErpVatAwtGroupName;
	}
	public String getOverrideUnspsc() {
		return overrideUnspsc;
	}
	public void setOverrideUnspsc(String overrideUnspsc) {
		this.overrideUnspsc = overrideUnspsc;
	}
	public String getOverrideOffsetCostCenter() {
		return overrideOffsetCostCenter;
	}
	public void setOverrideOffsetCostCenter(String overrideOffsetCostCenter) {
		this.overrideOffsetCostCenter = overrideOffsetCostCenter;
	}
	public boolean isUnspscOverrideFlag() {
		return unspscOverrideFlag;
	}
	public void setUnspscOverrideFlag(boolean unspscOverrideFlag) {
		this.unspscOverrideFlag = unspscOverrideFlag;
	}
	public boolean isCostCentreOverrideFlag() {
		return costCentreOverrideFlag;
	}
	public void setCostCentreOverrideFlag(boolean costCentreOverrideFlag) {
		this.costCentreOverrideFlag = costCentreOverrideFlag;
	}
	public boolean isErpPmtOverrideFlag() {
		return erpPmtOverrideFlag;
	}
	public void setErpPmtOverrideFlag(boolean erpPmtOverrideFlag) {
		this.erpPmtOverrideFlag = erpPmtOverrideFlag;
	}
	public boolean isErpAwtGroupNameOverrideFlag() {
		return erpAwtGroupNameOverrideFlag;
	}
	public void setErpAwtGroupNameOverrideFlag(boolean erpAwtGroupNameOverrideFlag) {
		this.erpAwtGroupNameOverrideFlag = erpAwtGroupNameOverrideFlag;
	}
	public boolean isErpVatAwtGroupOverrideFlag() {
		return erpVatAwtGroupOverrideFlag;
	}
	public void setErpVatAwtGroupOverrideFlag(boolean erpVatAwtGroupOverrideFlag) {
		this.erpVatAwtGroupOverrideFlag = erpVatAwtGroupOverrideFlag;
	}
	public boolean isDirectOffsetBucOverrideFlag() {
		return directOffsetBucOverrideFlag;
	}
	public void setDirectOffsetBucOverrideFlag(boolean directOffsetBucOverrideFlag) {
		this.directOffsetBucOverrideFlag = directOffsetBucOverrideFlag;
	}
	public boolean isIndirectOffsetBucOverrideFlag() {
		return indirectOffsetBucOverrideFlag;
	}
	public void setIndirectOffsetBucOverrideFlag(boolean indirectOffsetBucOverrideFlag) {
		this.indirectOffsetBucOverrideFlag = indirectOffsetBucOverrideFlag;
	}
	public Integer getQstPercent() {
		return qstPercent;
	}
	public void setQstPercent(Integer qstPercent) {
		this.qstPercent = qstPercent;
	}
	public Integer getHstPercent() {
		return hstPercent;
	}
	public void setHstPercent(Integer hstPercent) {
		this.hstPercent = hstPercent;
	}
	public Integer getPstPercent() {
		return pstPercent;
	}
	public void setPstPercent(Integer pstPercent) {
		this.pstPercent = pstPercent;
	}
	public Integer getGstPercent() {
		return gstPercent;
	}
	public void setGstPercent(Integer gstPercent) {
		this.gstPercent = gstPercent;
	}
	public Integer getVatPercent() {
		return vatPercent;
	}
	public void setVatPercent(Integer vatPercent) {
		this.vatPercent = vatPercent;
	}
	public Integer getTpPercent() {
		return tpPercent;
	}
	public void setTpPercent(Integer tpPercent) {
		this.tpPercent = tpPercent;
	}
	public String getLiquidateBillRoutingId() {
		return liquidateBillRoutingId;
	}
	public void setLiquidateBillRoutingId(String liquidateBillRoutingId) {
		this.liquidateBillRoutingId = liquidateBillRoutingId;
	}
	
	
}
