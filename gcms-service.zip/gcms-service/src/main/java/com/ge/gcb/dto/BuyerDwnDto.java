package com.ge.gcb.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BuyerDwnDto {
	
	private String erpBuyerLeName;
	private String erpOuNumber;
	private String erpOuEntityName;
	private String locationName;
	private String goldId;
	private String updatedBy;
	private String lastUpdatedDate;
	public String getErpBuyerLeName() {
		return erpBuyerLeName;
	}
	public void setErpBuyerLeName(String erpBuyerLeName) {
		this.erpBuyerLeName = erpBuyerLeName;
	}
	public String getErpOuNumber() {
		return erpOuNumber;
	}
	public void setErpOuNumber(String erpOuNumber) {
		this.erpOuNumber = erpOuNumber;
	}
	public String getErpOuEntityName() {
		return erpOuEntityName;
	}
	public void setErpOuEntityName(String erpOuEntityName) {
		this.erpOuEntityName = erpOuEntityName;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getGoldId() {
		return goldId;
	}
	public void setGoldId(String goldId) {
		this.goldId = goldId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public BuyerDwnDto(String erpBuyerLeName, String erpOuNumber, String erpOuEntityName, String locationName,
			String goldId, String updatedBy, String lastUpdatedDate) {
		super();
		this.erpBuyerLeName = erpBuyerLeName;
		this.erpOuNumber = erpOuNumber;
		this.erpOuEntityName = erpOuEntityName;
		this.locationName = locationName;
		this.goldId = goldId;
		this.updatedBy = updatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	
}
