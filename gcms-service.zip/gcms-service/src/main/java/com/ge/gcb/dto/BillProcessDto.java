package com.ge.gcb.dto;

public class BillProcessDto {
	
	private int billProcessId;
	private String processName;
	
	public int getBillProcessId() {
		return billProcessId;
	}
	public void setBillProcessId(int billProcessId) {
		this.billProcessId = billProcessId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}

}
