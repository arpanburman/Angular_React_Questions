package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbluserstats")
public class UserStat {

	@Id
	@Column(name="sso")
	private String sso;
	
	@Column(name = "lastlogin")
	private Date lastLogin;
	
	@Column(name = "numberoflogins")
	private Integer numberOfLogins;

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Integer getNumberOfLogins() {
		return numberOfLogins;
	}

	public void setNumberOfLogins(Integer numberOfLogins) {
		this.numberOfLogins = numberOfLogins;
	}
	
	

}

