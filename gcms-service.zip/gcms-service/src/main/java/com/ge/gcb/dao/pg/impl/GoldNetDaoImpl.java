package com.ge.gcb.dao.pg.impl;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.GoldNetDao;
import com.ge.gcb.entities.pg.GoldNet;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class GoldNetDaoImpl extends JpaCrudRepositoryPgImpl<GoldNet, String> implements GoldNetDao{
	
	private static final Logger logger = LogManager.getLogger(GoldNetDaoImpl.class);
	
	@Override
	public List<GoldNet> getGoldNetList() {
		logger.info("**Get All goldNetList**");
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<GoldNet> criteriaQuery = builder.createQuery(GoldNet.class);
		Root<GoldNet> gold = criteriaQuery.from(GoldNet.class);
		Root<Location> country = criteriaQuery.from(Location.class);
		List<GoldNet> goldLst = null;
		try {
			final TypedQuery<GoldNet> query = getEntityManager()
					.createQuery(criteriaQuery.multiselect(gold.get("goldId"),gold.get("goldnetName"),
						country.get("locationCode"))
							.where(
									builder.and(builder.equal(gold.<Long>get("locationId"), country.<Long>get("locationId"))))
							);

			goldLst = query.getResultList();
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return goldLst;
	}

	
}
