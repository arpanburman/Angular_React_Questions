package com.ge.gcb.entities.pg;


/**
 * @author aburman 188058
 * @description: Table use for Vendor Entity (Table Name: t_vendor_entity)
 */

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name="t_vendor_entity")
public class Vendor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vendor_entity_id")
	private int vendorEntityId;
	
	@ApiModelProperty(notes = "The Vendor Name")
	@Column(name="vendor_legal_entity_name")
	private String vendorLegalEntityName; 
	
	@ApiModelProperty(notes = "The Vendor HL ID")
	@Column(name="hl_vendor_id")
	private int hlVendorId; 
	
	@ApiModelProperty(notes = "The Vendor is Active or Not")
	@Column(name="active")
	private boolean active;
	
	@ApiModelProperty(notes = "The Vendor Created Date")
	@Column(name="created", updatable=false)
	@Convert(converter = DateConverter.class)
	private String createdDate;
	
	@ApiModelProperty(notes = "The Vendor Created By")
	@Column(name="created_by", updatable=false)
	private String createdBy;
	
	@ApiModelProperty(notes = "The Vendor Data Last updated Date")
	@Column(name="last_updated")
	@Convert(converter = DateConverter.class)
	private String lastUpdatedDate;
	
	@ApiModelProperty(notes = "The Vendor Data Updated By")
	@Column(name="updated_by")
	private String updatedBy;

	public int getVendorEntityId() {
		return vendorEntityId;
	}

	public void setVendorEntityId(int vendorEntityId) {
		this.vendorEntityId = vendorEntityId;
	}

	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}

	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getHlVendorId() {
		return hlVendorId;
	}

	public void setHlVendorId(int hlVendorId) {
		this.hlVendorId = hlVendorId;
	}


}
