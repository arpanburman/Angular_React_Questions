package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_ban_focus_group")
public class BanFocusGroup {
	
	@Column(name="focus_group_id")
	private long focusGroupId;
	
	@Column(name="ban_id")
	private long banId;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="u_id")
	private int uId;

	public Long getFocusGroupId() {
		return focusGroupId;
	}

	public void setFocusGroupId(Long fgId) {
		this.focusGroupId = fgId;
	}

	public long getBanId() {
		return banId;
	}

	public void setBanId(long banId) {
		this.banId = banId;
	}

	public Integer getuId() {
		return uId;
	}

	public void setuId(Integer uId) {
		this.uId = uId;
	}

	
	
}
