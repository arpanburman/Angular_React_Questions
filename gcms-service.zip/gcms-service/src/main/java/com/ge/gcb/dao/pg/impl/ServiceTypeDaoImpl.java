package com.ge.gcb.dao.pg.impl;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.ServiceTypeDao;
import com.ge.gcb.dto.OtherServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeBanDto;
import com.ge.gcb.dto.ServiceTypeDto;
import com.ge.gcb.dto.ServiceTypeDwnData;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.BanProductMaster;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Repository
public class ServiceTypeDaoImpl extends JpaCrudRepositoryPgImpl<ServiceType, Long> implements ServiceTypeDao {
	private static final Logger logger = LogManager.getLogger(ServiceTypeDaoImpl.class);

	@Override
	public ServiceType getServiceType(String suggestedServiceType) {
		try {
			CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
			CriteriaQuery<ServiceType> criteriaQuery = builder.createQuery(ServiceType.class);
			Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);

			final TypedQuery<ServiceType> query = getEntityManager()
					.createQuery(criteriaQuery.select(serviceType).where(
							builder.and(builder.equal(serviceType.get("serviceTypeName"), suggestedServiceType))));

			List<ServiceType> methodList = query.getResultList();
			if (!methodList.isEmpty())
				return methodList.get(0);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<ServiceType> getAllServiceTypeData() {
		//List<ServiceType> serviceTypeLst  = findAll();
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<ServiceType> criteriaQuery = builder.createQuery(ServiceType.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<Product> product = criteriaQuery.from(Product.class);
		Root<Location> countryFrom = criteriaQuery.from(Location.class);
		Root<Location> countryTo = criteriaQuery.from(Location.class);
		Root<BillProcess>billProcess=criteriaQuery.from(BillProcess.class);


		final TypedQuery<ServiceType> query = getEntityManager()
				.createQuery(criteriaQuery.multiselect(serviceType.<Long>get("serviceTypeId"),serviceType.<Long>get("productId"),
						billProcess.get("processName"),product.get("productName"),serviceType.<Long>get("billedFromLocationId"),countryFrom.get("locationName"),
						countryTo.get("locationName"),serviceType.<Long>get("billedToLocationId"),serviceType.get("serviceTypeName"),serviceType.get("legacyServiceTypeName"),
						serviceType.get("billingBasis"),serviceType.get("costCenter"),product.get("unspsc"),serviceType.get("createdBy"),serviceType.<String>get("created"),serviceType.get("updatedBy"),serviceType.<String>get("lastUpdated"))
						.where(
								builder.and(builder.equal(serviceType.get("productId"), product.get("productId")),
										builder.equal(billProcess.get("billProcessId"), product.get("billProcessId")),
										builder.equal(serviceType.get("billedFromLocationId"), countryFrom.get("locationId")),
										builder.equal(serviceType.get("billedToLocationId"), countryTo.get("locationId"))
										))
						.orderBy(builder.asc(serviceType.get("serviceTypeName"))));

		List<ServiceType> serviceTypeLst = query.getResultList();
		return serviceTypeLst;
	}

	
	@Override
	@Transactional
	public String insertServiceType(ServiceType serviceType,String sso) {
		serviceType.setCreatedBy(sso);
		serviceType.setCreated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
		serviceType.setUpdatedBy(sso);
		serviceType.setLastUpdated(GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
		serviceType.setLegacyServiceTypeName(serviceType.getLegacyServiceTypeName().toUpperCase().trim());
		serviceType.setCostCenter(serviceType.getCostCenter().toUpperCase().trim());
		save(serviceType);
		return "Service Type was successfully created";
	}

	@Transactional
	@Override
	public String updateServiceType(ServiceType serviceTypeDto,String sso) {
		

//		logger.info("**update Service Type Dao**");
//		long millis = System.currentTimeMillis();
//		String message="";
//		Date date = new Date(millis);
//		try {
//			serviceTypeDto.setLastUpdated(date);
//			serviceTypeDto.setUpdatedBy(sso);
//			saveOrUpdate(serviceTypeDto);
//			message="Record Updated Successfully with Service Type Id :"+serviceTypeDto.getServiceTypeId();
//		} catch (Exception e) {
//			logger.error("Error : {}", e.getMessage());
//			message="Update Fail";
//		}
//		return message;		
		
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<ServiceType> updateQuery = builder.createCriteriaUpdate(ServiceType.class);
		Root<ServiceType> serviceType = updateQuery.from(ServiceType.class);
		//updateQuery.set("serviceTypeName", serviceTypeDto.getServiceTypeName());
		updateQuery.set("productId", serviceTypeDto.getProductId());
		updateQuery.set("billedFromLocationId", serviceTypeDto.getBilledFromLocationId());
		updateQuery.set("billedToLocationId", serviceTypeDto.getBilledToLocationId());
		updateQuery.set("billingBasis", serviceTypeDto.getBillingBasis());
		updateQuery.set("legacyServiceTypeName", serviceTypeDto.getLegacyServiceTypeName().toUpperCase().trim());
		updateQuery.set("costCenter", serviceTypeDto.getCostCenter().toUpperCase().trim());
		updateQuery.set("lastUpdated", GcbUtil.convertDateToStringMMDDYYYY(new java.util.Date()));
		updateQuery.set("updatedBy", sso);
		updateQuery.where(
				builder.and(builder.equal(serviceType.get("serviceTypeId"), serviceTypeDto.getServiceTypeId())));

		int count = getEntityManager().createQuery(updateQuery).executeUpdate();
		
		return "Service Type was successfully updated";
	}

	@Override
	public List<ServiceTypeDwnData> downloadServiceTypeData() {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<ServiceTypeDwnData> criteriaQuery = builder.createQuery(ServiceTypeDwnData.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<Product> product = criteriaQuery.from(Product.class);
		Root<BillProcess>billProcess=criteriaQuery.from(BillProcess.class);
		Root<Location> country = criteriaQuery.from(Location.class);

		final TypedQuery<ServiceTypeDwnData> query = getEntityManager()
				.createQuery(criteriaQuery.multiselect(product.get("productName"),
						serviceType.get("serviceTypeName"),
						serviceType.get("legacyServiceTypeName"),
						country.get("locationName"),
						country.get("locationName"),
						serviceType.get("costCenter"),
						serviceType.get("updatedBy"),
						serviceType.<String>get("lastUpdated"))
						.where(
								builder.and(builder.equal(serviceType.get("productId"), product.get("productId")),
										builder.equal(billProcess.get("billProcessId"), product.get("billProcessId")),
										builder.equal(serviceType.get("billedFromLocationId"), country.get("locationId"))))
						.orderBy(builder.asc(serviceType.get("serviceTypeName"))));

		List<ServiceTypeDwnData> serviceTypeLst = query.getResultList();
		return serviceTypeLst;
	}

	@Override
	public List<ServiceType> fetchServiceType(ServiceTypeBanDto serviceTypeDto) {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<ServiceType> criteriaQuery = builder.createQuery(ServiceType.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		List<ServiceType> methodList = null;
	try {
		if(GcbConstants.GOTEMS == serviceTypeDto.getBillProcessId()) {
			final TypedQuery<ServiceType> query = getEntityManager()
					.createQuery(criteriaQuery.select(serviceType).where(
							builder.and(
							builder.equal(serviceType.get("billedToLocationId"), serviceTypeDto.getBilledToLocationId()),
							builder.equal(serviceType.get("billedFromLocationId"), serviceTypeDto.getBilledFromLocationId())
							)));
			methodList = query.getResultList();
		}
		else if(GcbConstants.TELECOM == serviceTypeDto.getBillProcessId()) {
			Root<Product> productType = criteriaQuery.from(Product.class);
			final TypedQuery<ServiceType> query = getEntityManager()
					.createQuery(criteriaQuery.select(serviceType).where(
							builder.and(
							builder.equal(productType.get("productId"), serviceType.get("productId")),
							builder.equal(serviceType.get("billedToLocationId"), serviceTypeDto.getBilledToLocationId()),
							builder.equal(serviceType.get("billedFromLocationId"), serviceTypeDto.getBilledFromLocationId()),
							builder.equal(productType.get("billProcessId"), serviceTypeDto.getBillProcessId())
							)));
			methodList = query.getResultList();
		}else {
			final TypedQuery<ServiceType> query = getEntityManager()
					.createQuery(criteriaQuery.select(serviceType).where(
							builder.and(
							builder.equal(serviceType.get("billedToLocationId"), serviceTypeDto.getBilledToLocationId()),
							builder.equal(serviceType.get("billedFromLocationId"), serviceTypeDto.getBilledFromLocationId())
							)));
			methodList = query.getResultList();
		}
		if (!methodList.isEmpty())
			return methodList;

	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	return methodList;
	}

	@Override
	public OtherServiceTypeDto getOtherServiceType(ServiceType serviceTypeObj) {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<OtherServiceTypeDto> criteriaQuery = builder.createQuery(OtherServiceTypeDto.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<Product> product = criteriaQuery.from(Product.class);
		List<OtherServiceTypeDto> methodList = null;
	try {
		final TypedQuery<OtherServiceTypeDto> query = getEntityManager()
				.createQuery(criteriaQuery.multiselect(product.get("productId"),serviceType.get("serviceTypeId"),
						serviceType.get("costCenter"), product.get("unspsc"))
						.where(
						builder.and(builder.equal(serviceType.get("productId"),product.get("productId")),
						builder.equal(serviceType.get("serviceTypeId"), serviceTypeObj.getServiceTypeId())
						)));

		methodList = query.getResultList();
		if (!methodList.isEmpty())
			return methodList.get(0);

	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	return methodList.get(0);
	}
	
	@Override
	public List<ServiceType> getTargetServiceType(String banId) {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<ServiceType> criteriaQuery = builder.createQuery(ServiceType.class);
		Root<ServiceType> serviceType = criteriaQuery.from(ServiceType.class);
		Root<BanProductMaster> banProductMaster = criteriaQuery.from(BanProductMaster.class);
		Root<Ban> ban = criteriaQuery.from(Ban.class);
		List<ServiceType> methodList = null;
	try {
		final TypedQuery<ServiceType> query = getEntityManager()
				.createQuery(criteriaQuery.select(serviceType).where(
						builder.and(
						builder.equal(banProductMaster.get("serviceTypeId"), serviceType.get("serviceTypeId")),
						builder.equal(ban.get("banId"), banProductMaster.get("banId")),
						builder.equal(ban.get("banId"), banId)
						)));

		methodList = query.getResultList();
		if (!methodList.isEmpty())
			return methodList;

	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	return methodList;
	}

}
