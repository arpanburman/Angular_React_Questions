package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="t_goldnet")
public class GoldNet {
	
	@Id
	@Column(name="	gold_id")
	private String 	goldId;
	
	@Column(name="goldnet_name")
	private String goldnetName;
	
	@Column(name="location_id")
	private Long locationId;
	
	@Transient
	private String countryCode;

	public String getGoldId() {
		return goldId;
	}

	public void setGoldId(String goldId) {
		this.goldId = goldId;
	}

	public String getGoldnetName() {
		return goldnetName;
	}

	public void setGoldnetName(String goldnetName) {
		this.goldnetName = goldnetName;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public GoldNet(String goldId, String goldnetName, String countryCode) {
		super();
		this.goldId = goldId;
		this.goldnetName = goldnetName;
		this.countryCode = countryCode;
	}

	
	
}
