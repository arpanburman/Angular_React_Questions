package com.ge.gcb.services.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.BillProcessDao;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.services.BillProcessService;

@Service
public class BillProcessServiceImpl implements BillProcessService {
	private static final Logger logger = LogManager.getLogger(BillProcessServiceImpl.class);
	
	@Autowired
	BillProcessDao billProcessDao;

	@Override
	public List<BillProcess> getBillProcess() {
		return billProcessDao.getBillProcess();
	}
	
}
