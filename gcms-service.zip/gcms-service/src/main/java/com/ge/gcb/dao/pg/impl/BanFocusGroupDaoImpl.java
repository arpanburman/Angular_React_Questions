package com.ge.gcb.dao.pg.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.BanFocusGroupDao;
import com.ge.gcb.entities.pg.BanFocusGroup;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
@Repository
public class BanFocusGroupDaoImpl  extends JpaCrudRepositoryPgImpl<BanFocusGroup, Integer> implements BanFocusGroupDao {
	
	private static final Logger logger = LogManager.getLogger(BanFocusGroupDaoImpl.class);

	@Override
	@Transactional
	public void insertFocusGroup(List focusGroup, long banId) {

		List<BanFocusGroup> list=new ArrayList<BanFocusGroup>();
		for(int i=0;i<focusGroup.size();i++) {
			Long fgId=Long.parseLong(focusGroup.get(i).toString());
			BanFocusGroup gfg=new BanFocusGroup();
			gfg.setFocusGroupId(fgId);
			gfg.setBanId(banId);
			list.add(gfg);			
		}
		saveAll(list);
	}

	@Override
	@Transactional
	public void deleteFocusGroupData(long banId) {
		   CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();	 // create delete
	        CriteriaDelete<BanFocusGroup> delete = builder.createCriteriaDelete(BanFocusGroup.class);

	        // set the root class
	        Root e = delete.from(BanFocusGroup.class);

	        // set where clause
	        delete.where(builder.equal(e.get("banId"), banId));

	        // perform delete
	        getEntityManager().createQuery(delete).executeUpdate();
	}

	@Override
	public List<Long> getBanFocusGroupById(String banId) {
		long ban=Long.parseLong(banId);
//		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
//		CriteriaQuery<BanFocusGroup> criteriaQuery = builder.createQuery(BanFocusGroup.class);
//		Root<BanFocusGroup> focusGroup = criteriaQuery.from(BanFocusGroup.class);
//		//long cbIdL = cbId!=null || !cbId.equalsIgnoreCase("null")? Long.parseLong(cbId):0;
//		final TypedQuery<BanFocusGroup> query = getEntityManager()
//				.createQuery(criteriaQuery.select(focusGroup)
//						.where(
//								builder.equal(focusGroup.get("banId"), ban)));
//
//		List<BanFocusGroup> focusGroupLst = query.getResultList();
//		return focusGroupLst;	
//		
		

		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		Root<BanFocusGroup> focusGroup = query.from(BanFocusGroup.class);
		query.select(focusGroup.<Long>get("focusGroupId"))
		.where(
				builder.equal(focusGroup.get("banId"), ban));
		TypedQuery<Long> typedQuery = getEntityManager().createQuery(query);
		List<Long> fg = typedQuery.getResultList();		
		return fg;
		
	}

	
}
