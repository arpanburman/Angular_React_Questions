package com.ge.gcb.dto;

public class ServiceTypeDwnData {
	
	private String productName;
	private String serviceTypeName;
	private String legacyServiceTypeName;
	private String billedFromLocation;
	private String billedToLocation;
	private String costCenter;
	private String updatedBy;
	private String lastUpdated;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getServiceTypeName() {
		return serviceTypeName;
	}
	public void setServiceTypeName(String serviceTypeName) {
		this.serviceTypeName = serviceTypeName;
	}
	public String getLegacyServiceTypeName() {
		return legacyServiceTypeName;
	}
	public void setLegacyServiceTypeName(String legacyServiceTypeName) {
		this.legacyServiceTypeName = legacyServiceTypeName;
	}
	public String getBilledFromLocation() {
		return billedFromLocation;
	}
	public void setBilledFromLocation(String billedFromLocation) {
		this.billedFromLocation = billedFromLocation;
	}
	public String getBilledToLocation() {
		return billedToLocation;
	}
	public void setBilledToLocation(String billedToLocation) {
		this.billedToLocation = billedToLocation;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public ServiceTypeDwnData(String productName, String serviceTypeName, String legacyServiceTypeName,
			String billedFromLocation, String billedToLocation, String costCenter, String updatedBy,
			String lastUpdated) {
		super();
		this.productName = productName;
		this.serviceTypeName = serviceTypeName;
		this.legacyServiceTypeName = legacyServiceTypeName;
		this.billedFromLocation = billedFromLocation;
		this.billedToLocation = billedToLocation;
		this.costCenter = costCenter;
		this.updatedBy = updatedBy;
		this.lastUpdated = lastUpdated;
	}
	
	

}
