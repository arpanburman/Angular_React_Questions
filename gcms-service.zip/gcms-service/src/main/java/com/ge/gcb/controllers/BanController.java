package com.ge.gcb.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.BanDto;
import com.ge.gcb.dto.BanDwnDto;
import com.ge.gcb.dto.BanProductDto;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.BanProductMaster;
import com.ge.gcb.entities.pg.BillingModel;
import com.ge.gcb.entities.pg.ServiceType;
import com.ge.gcb.exception.GcbException;
import com.ge.gcb.services.BanService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

import io.swagger.annotations.ApiOperation;

@RequestMapping("/ban")
@RestController
public class BanController {
	
private static final Logger log = LogManager.getLogger(BanController.class);
	
	@Autowired
	BanService banService;
	
	@Autowired
	private HttpServletRequest request;

	/**
	 * @author aburman
	 * @return List of Buyer
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available Ban", response = List.class, notes="This is a list of all Bans")
	@GetMapping("/ban-details")
	public @ResponseBody ResponseEntity<List<BanDto>> getBanDetails() throws Exception { 
		log.info("********* Get Ban Controller************");
		List<BanDto> banList = new ArrayList<>();
		try {
			long start = System.currentTimeMillis();
			banList = banService.getAllBans();
			long end = System.currentTimeMillis();
			log.info("Took : " + ((end - start) / 1000+" sec."));
		} catch (Exception e) {
			log.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(banList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(banList);
	}
	
	/**
	 * @author aburman
	 * @return particular column List of Ban export screen
	 * @throws Exception
	 */
	
	@CrossOrigin
	@ApiOperation(value = "Download Ban Data", response = List.class, notes="This method will Download All the available Ban data from Table")
	@PostMapping(value ="/dwnBanData")
	public @ResponseBody  ResponseEntity<List<BanDwnDto>> downloadServiceTypeData() {

		log.info("***Controller Method Ban Download Data invoked ***");
		List<BanDwnDto> serviceDataLst = null;
		serviceDataLst = banService.downloadBanData();
		if (!serviceDataLst.isEmpty())
			return ResponseEntity.status(HttpStatus.OK).body(serviceDataLst);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(serviceDataLst);
		
	}
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available Ban", response = List.class, notes="This is a list of all Bans")
	@GetMapping("/bans")
	public @ResponseBody ResponseEntity<List<Ban>> getBans() throws Exception { 
		log.info("********* Get Ban Controller************");
		List<Ban> banList = new ArrayList<>();
		try {
			banList = banService.getBans();
		} catch (Exception e) {
			log.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(banList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(banList);
	}
	
	@CrossOrigin
	@ApiOperation(value = "View a list of available Billing Details", response = List.class, notes="This is a list of all Billing Details")
	@GetMapping("/billingModel-details")
	public @ResponseBody ResponseEntity<List<BillingModel>> getBillingModel() throws Exception { 
		log.info("********* Get Billing Model Controller************");
		List<BillingModel> billingModelList = new ArrayList<>();
		try {
			billingModelList = banService.getBillingModel();
		} catch (Exception e) {
			log.error("Error : {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(billingModelList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(billingModelList);
	}
	
	@CrossOrigin
	@PostMapping("/bans")
	public @ResponseBody ResponseEntity<String> upsertBan(@RequestBody Ban banData) throws Exception { 
		log.info("********* Save or Update Ban Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();		
		try {
			outMap = banService.saveOrUpdateBan(banData,sso);
			if(outMap.isEmpty()) {
				outMap.put(GcbConstants.MESSAGE, GcbConstants.DUPLICATE_EXCEPTION);
				outMap.put(GcbConstants.ERROR, true);
				
			}
		} catch (Exception e) {
			log.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(GcbUtil.convertMapToJson(outMap));
		}
		return ResponseEntity.status(HttpStatus.OK).body(GcbUtil.convertMapToJson(outMap));
	}
	
	@CrossOrigin
	@GetMapping(value = "/banById/{banId}")
	public @ResponseBody Ban getBanById(@PathVariable("banId") String banId)  {		
		log.info("INSIDE GCMS BAN by BanId Controller Method :");
		return banService.getBanById(banId);
	}
	
	@CrossOrigin
	@PostMapping(value = "/banProductById")
	public @ResponseBody List<BanProductDto> getBanProductById(@RequestBody BanProductMaster banProductData) throws GcbException {		
		log.info("INSIDE GCMS BAN Product by BanId Controller Method :");
		return banService.getBanProductById(Integer.parseInt(banProductData.getBanId()+GcbConstants.EMPTY_STR));
	}
	
	@CrossOrigin
	@PostMapping("/banProducts/{banId}")
	public @ResponseBody ResponseEntity<String> upsertBanProductMaster(@RequestBody List<BanProductDto> banProductDataList,@PathVariable("banId") String banId) throws GcbException { 
		log.info("********* Save or Update Ban Product Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();		
		try {
			outMap = banService.upsertBanProductMaster(banProductDataList,banId,sso);
			if(outMap.isEmpty()) {
				outMap.put(GcbConstants.MESSAGE, GcbConstants.DUPLICATE_EXCEPTION);
				outMap.put(GcbConstants.ERROR, true);
				
			}
		} catch (Exception e) {
			log.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(GcbUtil.convertMapToJson(outMap));
		}
		return ResponseEntity.status(HttpStatus.OK).body(GcbUtil.convertMapToJson(outMap));
	}
	
	@CrossOrigin
	@ApiOperation(value = "Get Target Service Type details", notes="This method will fetch Target Service Type details on Ban screen")
	@PostMapping("/TargetServiceType-details/{banId}")
	public @ResponseBody ResponseEntity<BanProductDto> getTaregtServiceTypeDetails(@RequestBody ServiceType serviceTypeList, @PathVariable("banId") String banId) throws Exception { 
		log.info("********* Fetch Target Service type Details Controller************");
		BanProductDto serviceTypeDetList = new BanProductDto();
		try {
			serviceTypeDetList = banService.fetchTargetServiceTypeDetails(serviceTypeList,banId);
		} catch (Exception e) {
			log.error("Error in fetchServiecType : {}", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(serviceTypeDetList);
		}
		return ResponseEntity.status(HttpStatus.OK).body(serviceTypeDetList);
	}
	@CrossOrigin
	@RequestMapping("/billingModelTypes")
	public @ResponseBody ResponseEntity<String> getBillingModelTypes() {

		log.info("***Controller Method getBillingModel invoked ***");
		Map outputMap = new HashMap<>();
		Map respMap = banService.getBillingModelTypes();
		outputMap.put("response", respMap);
		String response = GcbUtil.convertMapToJson(outputMap);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	@CrossOrigin
	@GetMapping("/billingModelTypes/{banId}")
	public @ResponseBody ResponseEntity<String> getCloneBillingModelTypes(@PathVariable("banId") String banId) {

		log.info("***Controller Method getBillingModel invoked ***");
		Map outputMap = new HashMap<>();
		Map respMap = banService.getCloneBillingModelTypes(banId);
		outputMap.put("response", respMap);
		String response = GcbUtil.convertMapToJson(outputMap);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	@CrossOrigin
	@PostMapping("/banMode")
	public @ResponseBody ResponseEntity<String> getProdMode(@RequestBody Ban banData) throws Exception { 
		log.info("********* changeMode Ban Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();		
		try {
			Ban ban = banService.getProdMode(banData);
			if(ban!=null) {
				outMap.put(GcbConstants.MESSAGE, "All other records having the same BAN as "+ban.getVendorBan()+" and for this same vendor, but with different Process and Status values will be set to Test.");
				outMap.put(GcbConstants.status, "Success");
				
			}
		} catch (Exception e) {
			log.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(GcbUtil.convertMapToJson(outMap));
		}
		return ResponseEntity.status(HttpStatus.OK).body(GcbUtil.convertMapToJson(outMap));
	}
}
