package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_bill_process")
public class BillProcess {

	@Id
	@Column(name="bill_process_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int billProcessId;
	
	@Column(name="process_name")
	private String processName;
	
	@Column(name="services_per_ban")
	private String servicesPerBan;

	public int getBillProcessId() {
		return billProcessId;
	}

	public void setBillProcessId(int billProcessId) {
		this.billProcessId = billProcessId;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getServicesPerBan() {
		return servicesPerBan;
	}

	public void setServicesPerBan(String servicesPerBan) {
		this.servicesPerBan = servicesPerBan;
	}
	
	

}