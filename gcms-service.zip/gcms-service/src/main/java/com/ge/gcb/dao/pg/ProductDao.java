package com.ge.gcb.dao.pg;

import java.util.List;
import java.util.Map;

import com.ge.gcb.dto.ProductDto;
import com.ge.gcb.entities.pg.Product;

public interface ProductDao {

	List<ProductDto> getProductDetails();

	List<Product> getProduct();

	boolean updateUnspsc(Long productId, String unspsc,String sso);
	
	Product getProductById(String productId);

	Map<String, Object> updateProduct(Product product, String sso);

	Map<String, Object> saveProduct(Product product, String sso);

	Product getProduct(String productCode,String productName);
	
}
