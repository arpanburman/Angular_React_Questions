package com.ge.gcb.services;

public interface ChargeBackService {
	
	public String getLocationTree();
	public String getBillProcessTree();
	public String getVendorTree();
	public String getBuyerTree();
	
}
