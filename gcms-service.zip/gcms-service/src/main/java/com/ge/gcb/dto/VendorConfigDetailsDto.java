package com.ge.gcb.dto;

public class VendorConfigDetailsDto {

	private long vendorConfigId;
	private long vendorEntityId;
	private String vendorLegalEntityName;
	private String vendorCode;
	private String billedFromCountry;
	private String billedFromCountryCode;
	private long billedFromLocationId;
	private String billedToCountry;
	private String billedToCountryCode;
	private long billedToLocationId;
	private String currencyCode;
	private boolean active;
	private String dateFormat;
	private String lldCoeFlag;
	private String exchangeRateType;
	private String vendorContactEmail;
	private String paymentApprovalEmail;
	private String expectedFeedDate;
	private String finalInvoiceDate;
	//private String reportingSecurityDl;
	private String created;
	private String createdBy;
	private String lastUpdated;
	private String updatedBy;
	
	public long getVendorConfigId() {
		return vendorConfigId;
	}
	public void setVendorConfigId(long vendorConfigId) {
		this.vendorConfigId = vendorConfigId;
	}
	public long getVendorEntityId() {
		return vendorEntityId;
	}
	public void setVendorEntityId(long vendorEntityId) {
		this.vendorEntityId = vendorEntityId;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getBilledFromCountry() {
		return billedFromCountry;
	}
	public void setBilledFromCountry(String billedFromCountry) {
		this.billedFromCountry = billedFromCountry;
	}
	public String getBilledToCountry() {
		return billedToCountry;
	}
	public void setBilledToCountry(String billedToCountry) {
		this.billedToCountry = billedToCountry;
	}
	public String getVendorLegalEntityName() {
		return vendorLegalEntityName;
	}
	public void setVendorLegalEntityName(String vendorLegalEntityName) {
		this.vendorLegalEntityName = vendorLegalEntityName;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getExchangeRateType() {
		return exchangeRateType;
	}
	public void setExchangeRateType(String exchangeRateType) {
		this.exchangeRateType = exchangeRateType;
	}
	public String getVendorContactEmail() {
		return vendorContactEmail;
	}
	public void setVendorContactEmail(String vendorContactEmail) {
		this.vendorContactEmail = vendorContactEmail;
	}
	public String getExpectedFeedDate() {
		return expectedFeedDate;
	}
	public void setExpectedFeedDate(String expectedFeedDate) {
		this.expectedFeedDate = expectedFeedDate;
	}
	public String getFinalInvoiceDate() {
		return finalInvoiceDate;
	}
	public void setFinalInvoiceDate(String finalInvoiceDate) {
		this.finalInvoiceDate = finalInvoiceDate;
	}
//	public String getReportingSecurityDl() {
//		return reportingSecurityDl;
//	}
//	public void setReportingSecurityDl(String reportingSecurityDl) {
//		this.reportingSecurityDl = reportingSecurityDl;
//	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public long getBilledFromLocationId() {
		return billedFromLocationId;
	}
	public void setBilledFromLocationId(long billedFromLocationId) {
		this.billedFromLocationId = billedFromLocationId;
	}
	public long getBilledToLocationId() {
		return billedToLocationId;
	}
	public void setBilledToLocationId(long billedToLocationId) {
		this.billedToLocationId = billedToLocationId;
	}
	public String getLldCoeFlag() {
		return lldCoeFlag;
	}
	public void setLldCoeFlag(String lldCoeFlag) {
		this.lldCoeFlag = lldCoeFlag;
	}
	public String getPaymentApprovalEmail() {
		return paymentApprovalEmail;
	}
	public void setPaymentApprovalEmail(String paymentApprovalEmail) {
		this.paymentApprovalEmail = paymentApprovalEmail;
	}
	
	public VendorConfigDetailsDto(long vendorConfigId, long vendorEntityId, String vendorLegalEntityName,
			String vendorCode, String billedFromCountry, String billedFromCountryCode, long billedFromLocationId,
			String billedToCountry, String billedToCountryCode, long billedToLocationId, String currencyCode,
			boolean active, String dateFormat, String lldCoeFlag, String exchangeRateType, String vendorContactEmail,
			String paymentApprovalEmail, String expectedFeedDate, String finalInvoiceDate,/* String reportingSecurityDl,*/
			String created, String createdBy, String lastUpdated, String updatedBy) {
		super();
		this.vendorConfigId = vendorConfigId;
		this.vendorEntityId = vendorEntityId;
		this.vendorLegalEntityName = vendorLegalEntityName;
		this.vendorCode = vendorCode;
		this.billedFromCountry = billedFromCountry;
		this.billedFromLocationId = billedFromLocationId;
		this.billedToCountry = billedToCountry;
		this.billedToLocationId = billedToLocationId;
		this.billedFromCountryCode = billedFromCountryCode;
		this.billedToCountryCode = billedToCountryCode;
		this.currencyCode = currencyCode;
		this.active = active;
		this.dateFormat = dateFormat;
		this.lldCoeFlag = lldCoeFlag;
		this.exchangeRateType = exchangeRateType;
		this.vendorContactEmail = vendorContactEmail;
		this.paymentApprovalEmail = paymentApprovalEmail;
		this.expectedFeedDate = expectedFeedDate;
		this.finalInvoiceDate = finalInvoiceDate;
		//this.reportingSecurityDl = reportingSecurityDl;
		this.created = created;
		this.createdBy = createdBy;
		this.lastUpdated = lastUpdated;
		this.updatedBy = updatedBy;
	}
	public VendorConfigDetailsDto(String vendorCode, String billedFromCountry,
			String billedToCountry, String currencyCode,long vendorConfigId) {
		super();
		this.vendorCode = vendorCode;
		this.billedFromCountry = billedFromCountry;
		this.billedToCountry = billedToCountry;
		this.currencyCode = currencyCode;
		this.vendorConfigId=vendorConfigId;
	}
	public VendorConfigDetailsDto()
	{}
	public String getBilledFromCountryCode() {
		return billedFromCountryCode;
	}
	public void setBilledFromCountryCode(String billedFromCountryCode) {
		this.billedFromCountryCode = billedFromCountryCode;
	}
	public String getBilledToCountryCode() {
		return billedToCountryCode;
	}
	public void setBilledToCountryCode(String billedToCountryCode) {
		this.billedToCountryCode = billedToCountryCode;
	}

}
