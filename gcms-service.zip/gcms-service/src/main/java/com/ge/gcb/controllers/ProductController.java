package com.ge.gcb.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.gcb.dto.ProductDto;
import com.ge.gcb.entities.pg.BillProcess;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.entities.pg.Unspsc;
import com.ge.gcb.entities.pg.Vendor;
import com.ge.gcb.services.BillProcessService;
import com.ge.gcb.services.ProductService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@RestController
public class ProductController {
	
	private static final Logger logger = LogManager.getLogger(ProductController.class);
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	BillProcessService billProcessService;
	
	@Autowired
	ProductService productService;

	@CrossOrigin
	@GetMapping(value = "/billProcess")
	public @ResponseBody List<BillProcess> getBillProcess()  {		
		logger.info("INSIDE GCMS billProcess Controller Method :");
		return billProcessService.getBillProcess();
	}
	
	@CrossOrigin
	@GetMapping(value = "/unspsc")
	public @ResponseBody List<Unspsc> getUnspsc()  {		
		logger.info("INSIDE GCMS UNSPSC Controller Method :");
		return productService.getUnspsc();
	}
	
	@CrossOrigin
	@GetMapping(value = "/product")
	public @ResponseBody List<Product> getProduct()  {		
		logger.info("INSIDE GCMS product Controller Method :");
		return productService.getProduct();
	}
	
	@CrossOrigin
	@GetMapping(value = "/product-details")
	public @ResponseBody List<ProductDto> getProductDetails()  {		
		logger.info("INSIDE GCMS product Controller Method :");
		return productService.getProductDetails();
	}
	
	@CrossOrigin
	@GetMapping(value = "/product/{productId}")
	public @ResponseBody Product getProductById(@PathVariable("productId") String productId)  {		
		logger.info("INSIDE GCMS product Controller Method :");
		return productService.getProductById(productId);
	}
	
	@CrossOrigin
	@PostMapping("/product")
	public @ResponseBody ResponseEntity<String> upsertProduct(@RequestBody Product productData) throws Exception { 
		logger.info("********* Save or Update Product Controller************");
		String sso = request.getHeader("sm_user") != null ? request.getHeader("sm_user") : "999999999";
		Map<String, Object> outMap = new HashMap<>();
		Optional<Product> product = Optional.ofNullable(productData);
		try {
			outMap = productService.saveOrUpdateProduct(product.get(),sso);
			if(outMap.isEmpty()) {
				outMap.put(GcbConstants.MESSAGE, GcbConstants.DUPLICATE_EXCEPTION);
				outMap.put(GcbConstants.ERROR, true);
				
			}
		} catch (Exception e) {
			logger.error("Error in upsertVendor : {}", e);
			outMap.put(GcbConstants.MESSAGE, GcbConstants.METHOD_EXCEPTION);
			outMap.put(GcbConstants.ERROR, true);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(GcbUtil.convertMapToJson(outMap));
		}
		return ResponseEntity.status(HttpStatus.OK).body(GcbUtil.convertMapToJson(outMap));
	}
	

           
}