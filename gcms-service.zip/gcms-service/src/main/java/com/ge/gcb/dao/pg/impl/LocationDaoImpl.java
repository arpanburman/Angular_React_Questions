package com.ge.gcb.dao.pg.impl;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.LocationDao;
import com.ge.gcb.dto.CountryDto;
import com.ge.gcb.entities.pg.Location;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;
import com.ge.gcb.utils.GcbConstants;

@Repository
public class LocationDaoImpl extends JpaCrudRepositoryPgImpl<Location, Long> implements LocationDao   {

	private static final Logger logger = LogManager.getLogger(LocationDaoImpl.class);
	
	@Override
	public List<CountryDto>  getCountry() {
		logger.info("LocationDaoImpl : getCountry()");
		
		CriteriaBuilder cBuilder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<CountryDto> cQuery = cBuilder.createQuery(CountryDto.class);
		Root<Location> locRoot= cQuery.from(Location.class);
		
		final TypedQuery<CountryDto> tq = getEntityManager().createQuery(
				cQuery
				.multiselect(locRoot.<Long>get("locationId"),locRoot.<Long>get("locationName"),locRoot.<Long>get("locationCode"))
				.where(cBuilder.and(cBuilder.equal(locRoot.get("locationType"),GcbConstants.GET_COUNTRY)))
				.orderBy(
						cBuilder.asc(
								 locRoot.get("locationName")
								    )
						)
				);
			
		return tq.getResultList();
		
	}

}
