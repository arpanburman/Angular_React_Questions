package com.ge.gcb.dao.pg;

public interface BuyerTreeViewDao {

	public String getBuyerTree();
}
