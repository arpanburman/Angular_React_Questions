package com.ge.gcb.dto;

public class ServiceTypeBanDto {
	private long billedToLocationId;
	private long billedFromLocationId;
	private long billProcessId;
	public long getBilledToLocationId() {
		return billedToLocationId;
	}
	public void setBilledToLocationId(long billedToLocationId) {
		this.billedToLocationId = billedToLocationId;
	}
	public long getBilledFromLocationId() {
		return billedFromLocationId;
	}
	public void setBilledFromLocationId(long billedFromLocationId) {
		this.billedFromLocationId = billedFromLocationId;
	}
	public long getBillProcessId() {
		return billProcessId;
	}
	public void setBillProcessId(long billProcessId) {
		this.billProcessId = billProcessId;
	}
	
}
