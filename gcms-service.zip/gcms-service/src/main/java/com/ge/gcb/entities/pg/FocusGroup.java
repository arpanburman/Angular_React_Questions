package com.ge.gcb.entities.pg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_focus_group")
public class FocusGroup {

	@Id
	@Column(name="focus_group_id")
	private int focusGroupId	;
	
	@Column(name="focus_group_name")
	private String focusGroupName;

	public int getFocusGroupId() {
		return focusGroupId;
	}

	public void setFocusGroupId(int focusGroupId) {
		this.focusGroupId = focusGroupId;
	}

	public String getFocusGroupName() {
		return focusGroupName;
	}

	public void setFocusGroupName(String focusGroupName) {
		this.focusGroupName = focusGroupName;
	}

	
}