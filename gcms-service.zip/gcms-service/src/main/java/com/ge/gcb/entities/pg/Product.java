package com.ge.gcb.entities.pg;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_product")
public class Product {

	@Id	
	@Column(name="product_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int productId;
	
	@Column(name="bill_process_id")
	private int billProcessId;
	
	@Column(name="product_name")
	private String productName;
	
	@Column(name="product_code")
	private String productCode;
	
	@Column(name="unspsc")
	private String unspsc;
	
	@Convert(converter = DateConverter.class)
    @Column(name="created")
	private String created;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Convert(converter = DateConverter.class)
   @Column(name="last_updated")
	private String lastUpdated;
	
	@Column(name="updated_by")
	private String updatedBy;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getBillProcessId() {
		return billProcessId;
	}

	public void setBillProcessId(int billProcessId) {
		this.billProcessId = billProcessId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	

	public String getUnspsc() {
		return unspsc;
	}

	public void setUnspsc(String unspsc) {
		this.unspsc = unspsc;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
}