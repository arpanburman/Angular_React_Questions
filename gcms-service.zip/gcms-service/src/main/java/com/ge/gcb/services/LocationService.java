package com.ge.gcb.services;

import java.util.List;

import com.ge.gcb.dto.CountryDto;

public interface LocationService {

	public List<CountryDto> getCountry();
	
}
