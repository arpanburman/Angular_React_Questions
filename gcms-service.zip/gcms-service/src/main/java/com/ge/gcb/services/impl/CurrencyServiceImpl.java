package com.ge.gcb.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.CurrencyDao;
import com.ge.gcb.entities.pg.Currency;
import com.ge.gcb.services.CurrencyService;

@Service
public class CurrencyServiceImpl implements CurrencyService {

	
	@Autowired
	CurrencyDao currencyDao;
	
	@Override
	public List<Currency> getCurrencyList() {
		// TODO Auto-generated method stub
		return currencyDao.getCurrencyList();
	}

}
