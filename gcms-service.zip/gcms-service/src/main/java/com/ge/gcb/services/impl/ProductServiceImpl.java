package com.ge.gcb.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.ProductDao;
import com.ge.gcb.dao.pg.UnspscDao;
import com.ge.gcb.dto.ProductDto;
import com.ge.gcb.entities.pg.Product;
import com.ge.gcb.entities.pg.Unspsc;
import com.ge.gcb.services.ProductService;
import com.ge.gcb.utils.GcbConstants;
import com.ge.gcb.utils.GcbUtil;

@Service
public class ProductServiceImpl implements ProductService {
	private static final Logger logger = LogManager.getLogger(ProductServiceImpl.class);
	
	@Autowired
	ProductDao productDao;
	
	@Autowired
	UnspscDao unspscDao;

	@Override
	public List<ProductDto> getProductDetails() {
		return productDao.getProductDetails();
	}

	@Override
	public List<Product> getProduct() {
		return productDao.getProduct();
	}
	
	@Override
	public Product getProductById(String productId) {
		return productDao.getProductById(productId);
	}

	@Override
	public Map<String, Object> saveOrUpdateProduct(Product product,String sso) {
		logger.info("****Save or Update Product Service ****");
		Map<String, Object> outMap = new HashMap<>();
		Product productObj=productDao.getProduct(product.getProductCode(),product.getProductName());

		try {
			if(productObj==null && GcbUtil.isEmpty(product.getProductId())) {
				outMap=productDao.saveProduct(product,sso);
			}
			else if(productObj!=null && productObj.getProductId()==product.getProductId()) {
				outMap=productDao.updateProduct(product,sso);
			}
			else
			{
				outMap.put(GcbConstants.ERROR, true);
				outMap.put("statusMessage","Product Code Or Product Name cannot be modified ");
			}
			
			
		} catch (Exception e) {
			logger.error("Error : {}", e.getMessage());
		}
		return outMap;
	}
	
	@Override
	public List<Unspsc> getUnspsc() {
		return unspscDao.getUnspsc();
	}
	
}
