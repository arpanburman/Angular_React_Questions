package com.ge.gcb.dao.pg.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ge.gcb.dao.pg.UserDao;
import com.ge.gcb.entities.pg.Ban;
import com.ge.gcb.entities.pg.User;
import com.ge.gcb.entities.pg.UserRole;
import com.ge.gcb.repository.JpaCrudRepositoryPgImpl;

@Repository
public class UserDaoImpl extends JpaCrudRepositoryPgImpl<User, String> implements UserDao {
	private static final Logger logger = LogManager.getLogger(UserDaoImpl.class);

	@Override
	public User getUserDetails(String sso) {
		logger.info("INSIDE GCB UserDaoImpl Method :");
		try {
		CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
		CriteriaQuery<User> criteriaQuery = builder.createQuery(User.class);
		Root<User> user = criteriaQuery.from(User.class);
		Root<UserRole> userRole = criteriaQuery.from(UserRole.class);

		final TypedQuery<User> query = getEntityManager().createQuery(
				criteriaQuery.multiselect(user.get("sso"), user.get("firstName"), user.get("lastName"), user.get("emailId"), user.get("role"), user.get("createdDate"),
						userRole.get("roleName")).where(
						builder.and(builder.and(builder.equal(user.get("sso"), sso),
								builder.equal(user.get("role"),userRole.get("roleId"))))));
		List<User> methodList = query.getResultList();
		if(!methodList.isEmpty()) {
			return methodList.get(0);
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	@Transactional
	public void saveUserDetails(User user) throws Exception{
		logger.info("INSIDE GCB UserDaoImpl Method :");
		 save(user);
	}
	
	
}
