package com.ge.gcb.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.gcb.dao.pg.BuyerDao;
import com.ge.gcb.dao.pg.GoldNetDao;
import com.ge.gcb.dto.BuyerDto;
import com.ge.gcb.dto.BuyerDwnDto;
import com.ge.gcb.entities.pg.Buyer;
import com.ge.gcb.entities.pg.GoldNet;
import com.ge.gcb.services.BuyerService;
import com.ge.gcb.utils.GcbConstants;

@Service
public class BuyerServiceImpl implements BuyerService{
	
	private static final Logger logger = LogManager.getLogger(BuyerServiceImpl.class);

	@Autowired
	BuyerDao buyerDao;
	
	@Autowired
	GoldNetDao goldNetDao;

	@Override
	public List<BuyerDto> getAllBuyers() {
		logger.info("****Get Buyer Service ****");
		return buyerDao.getAllBuyers();
	}

	@Override
	public List<BuyerDwnDto> downloadBuyerData() {
		return buyerDao.downloadBuyerData();
	}

	@SuppressWarnings("unused")
	@Override
	public Map<String, Object> saveOrUpdateBuyer(Buyer buyer, String sso) {
		logger.info("****Save or Update Vendor Service ****");
		Map<String, Object> outMap = new HashMap<>();
		List<Buyer> buyerObjList = new ArrayList<Buyer>();
		buyerObjList =  buyerDao.checkBuyerExist(buyer);
		try {
			if(buyerObjList.size()>0) {
				outMap.put(GcbConstants.ERROR, false);
				outMap.put(GcbConstants.MESSAGE, "Buyer already exists for the provided combination");
			}else {
				if(0 != buyer.getBuyerId()) {
					outMap=buyerDao.upsertBuyer(buyer,sso);
					outMap.put(GcbConstants.MESSAGE, "Buyer : "+buyer.getErpBuyerLeName()+" was successfully updated.");
					logger.info("****Update Vendor Service ****");
				}
				else{
					outMap=buyerDao.upsertBuyer(buyer,sso);
					outMap.put(GcbConstants.MESSAGE, "Buyer : "+buyer.getErpBuyerLeName()+" was successfully created.");
					logger.info("****Save Vendor Service ****");
				}
			}
		} catch (Exception e) {
			outMap.put(GcbConstants.MESSAGE, "Buyer cannot be saved due to an error.");
			outMap.put(GcbConstants.ERROR, true);
			logger.error("Error : {}", e.getMessage());
		}
		return outMap;
	}

	@Override
	public List<GoldNet> getGoldNet() {
		return goldNetDao.getGoldNetList();
	}

	

}
